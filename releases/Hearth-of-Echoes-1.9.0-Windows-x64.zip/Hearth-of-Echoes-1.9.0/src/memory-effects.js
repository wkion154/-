import {particle} from './korean.js';
export const memoryKinds={support:'받은 위로',reconcile:'화해',building:'마을의 변화',expedition:'원정',arrival:'첫 만남',legacy:'지난 터전',rescue:'도움받은 순간',bond:'사람 사이의 약속',loss:'떠나보낸 사람',bias:'생각이 달라진 순간'};
export function memoryWeight(g,m){const importance=m.importance||(['rescue','loss','bond'].includes(m.kind)?3:1);return importance/(1+Math.max(0,g.time-m.time)/(importance===3?18000:importance===2?3600:900));}
export function meaningfulMemory(g,a,b){return (a.memories||[]).filter(m=>m.other===b.id&&['support','reconcile','rescue','bond'].includes(m.kind)&&memoryWeight(g,m)>.15).sort((x,y)=>memoryWeight(g,y)-memoryWeight(g,x))[0]||null;}
export function keepMemory(g,r,kind,other,text,importance=1){
 r.memories??=[];if(r.memories.some(m=>m.kind===kind&&m.other===other&&m.text===text&&g.time-m.time<120))return;
 r.memories.unshift({time:g.time,kind,other,text,importance});while(r.memories.length>20){let at=1;for(let i=2;i<r.memories.length;i++)if(memoryWeight(g,r.memories[i])<memoryWeight(g,r.memories[at]))at=i;r.memories.splice(at,1);}
}
export function recordRescue(g,helper,recipient,reason){
 if(helper.id===recipient.id)return;const text=`${particle(helper.name,'이','가')} ${reason} 도와주었다.`;if(recipient.memories?.some(m=>m.kind==='rescue'&&m.other===helper.id&&g.time-m.time<300))return;
 keepMemory(g,recipient,'rescue',helper.id,text,3);keepMemory(g,helper,'rescue',recipient.id,`${particle(recipient.name,'을','를')} ${reason} 도왔다.`,2);
}
