export const genderDefs={unspecified:'미설정',woman:'여성',man:'남성',nonbinary:'논바이너리'};
export const attractionDefs={unspecified:'아직 정하지 않음',women:'여성에게 끌림',men:'남성에게 끌림',all:'성별에 관계없이 끌림',none:'연애에 관심 없음'};
export const outlookDefs={open:'개인으로 판단함',guardedMen:'남성에게 경계심이 있음',guardedWomen:'여성에게 경계심이 있음'};
export const identityOf=r=>r.identity||{gender:'unspecified',attraction:'unspecified',outlook:'open'};
export function validIdentity(v){return !!v&&Object.keys(v).length===3&&Object.hasOwn(genderDefs,v.gender)&&Object.hasOwn(attractionDefs,v.attraction)&&Object.hasOwn(outlookDefs,v.outlook);}
export function seededIdentity(seed,id){let n=(seed^Math.imul(id+1,0x9e3779b1))>>>0;n=Math.imul(n^(n>>>16),0x85ebca6b)>>>0;n=Math.imul(n^(n>>>13),0xc2b2ae35)>>>0;n=(n^(n>>>16))>>>0;return {gender:['woman','man','nonbinary'][n%11===0?2:n%2],attraction:n%7===0?'none':n%5===0?'all':n%2?'women':'men',outlook:'open'};}
export function attractedTo(a,b){const i=identityOf(a),j=identityOf(b);return a.age>=18&&b.age>=18&&i.attraction!=='unspecified'&&j.gender!=='unspecified'&&(i.attraction==='all'||i.attraction==='women'&&j.gender==='woman'||i.attraction==='men'&&j.gender==='man');}
export function relatives(g,a,b){
 const ancestors=id=>{const seen=new Set(),todo=[id];while(todo.length){const n=todo.pop();if(seen.has(n))continue;seen.add(n);for(const p of g.residents[n]?.guardians||[])todo.push(p);}return seen;};
 const aa=ancestors(a.id),bb=ancestors(b.id);return [...aa].some(id=>bb.has(id));
}
export const romanceCompatible=(g,a,b)=>!!a&&!!b&&a.id!==b.id&&a.alive&&b.alive&&!relatives(g,a,b)&&attractedTo(a,b)&&attractedTo(b,a);
export function prejudiceToward(a,b){const i=identityOf(a),j=identityOf(b);return i.outlook==='guardedMen'&&j.gender==='man'||i.outlook==='guardedWomen'&&j.gender==='woman';}
