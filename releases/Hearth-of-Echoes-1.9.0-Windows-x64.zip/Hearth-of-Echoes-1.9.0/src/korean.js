export function particle(word,withFinal,withoutFinal){const c=String(word).charCodeAt(String(word).length-1);return word+((c>=0xac00&&c<=0xd7a3&&(c-0xac00)%28)?withFinal:withoutFinal);}
