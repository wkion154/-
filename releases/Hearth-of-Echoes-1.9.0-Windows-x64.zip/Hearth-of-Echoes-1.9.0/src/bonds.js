import {particle} from './korean.js';
import {identityOf,romanceCompatible,relatives,prejudiceToward,validIdentity} from './identity.js';
import {keepMemory,meaningfulMemory} from './memory-effects.js';
const pairKey=(a,b)=>[a,b].sort((x,y)=>x-y).join(':');
const home=(g,r)=>r?.alive&&!g.expedition?.team.includes(r.id);
const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,n));
export const bondStages={friends:'알아가는 사이',interest:'마음이 기우는 사이',partners:'연인',exes:'헤어진 사이',bereaved:'기억에 남은 연인'};
export function bondDefaults(){return {enabled:true,pairs:{},lastEvent:-600,log:[],contactAt:{}};}
export function bondState(g){return g.social?.bonds||{enabled:true,pairs:{},lastEvent:-600,log:[],contactAt:{}};}
export const pairBond=(g,a,b)=>bondState(g).pairs[pairKey(a,b)]||null;
function ensure(g,a,b){g.social.bonds??=bondDefaults();const pairs=g.social.bonds.pairs,key=pairKey(a,b);if(!pairs[key]&&Object.keys(pairs).length>=512){const old=Object.entries(pairs).filter(([,p])=>p.stage!=='partners').sort((x,y)=>(+!!g.residents[x[1].a]?.alive+ +!!g.residents[x[1].b]?.alive)-(+!!g.residents[y[1].a]?.alive+ +!!g.residents[y[1].b]?.alive)||x[1].lastChange-y[1].lastChange)[0];if(old)delete pairs[old[0]];}return pairs[key]??={a:Math.min(a,b),b:Math.max(a,b),stage:'friends',affection:0,tension:0,lastChange:g.time,lastChoice:-1200,contacts:0,declinedUntil:0};}

export function partnerOf(g,id){const p=Object.values(bondState(g).pairs).find(p=>p.stage==='partners'&&(p.a===id||p.b===id)&&g.residents[p.a]?.alive&&g.residents[p.b]?.alive);return p?g.residents[p.a===id?p.b:p.a]:null;}
export function bondRequestReason(g,who,other,kind){
 if(!Number.isInteger(who)||!Number.isInteger(other)||!['together','confess','boundary','breakup','reunite','bias','jealousy'].includes(kind))return '두 주민과 대화 종류를 확인하세요.';
 const a=g.residents[who],b=g.residents[other];if(!a||!b||who===other||!home(g,a)||!home(g,b))return '거점에 있는 두 주민을 골라 주세요.';
 if(a.age<18||b.age<18)return '관계 이야기는 성인 주민끼리 진행합니다.';
 if(g.event||g.crisis.ready||g.gameOver||g.ending&&!g.crisis.sandbox)return '현재 중요한 선택을 먼저 마쳐 주세요.';
 if(g.social.request)return '진행 중인 대화가 끝나기를 기다려 주세요.';
 if(a.needs.fatigue>=80||b.needs.fatigue>=80||a.stress>=80||b.stress>=80)return '지금은 회복할 여유가 먼저 필요합니다.';
 if(g.frontier?.raid.phase==='battle'&&[who,other].some(id=>g.frontier.raid.participants.includes(id)))return '방어를 마친 뒤 두 사람이 이야기할 수 있습니다.';
 const p=pairBond(g,who,other),relation=g.relationships[pairKey(who,other)]||0;
 if(p&&g.time-p.lastChoice<300)return '이 두 사람에게 생각할 시간을 주세요(게임 시간 5분).';
 if(kind==='confess'){
  if(!romanceCompatible(g,a,b))return relatives(g,a,b)?'가족 사이에는 연애 관계를 만들지 않습니다.':'두 사람의 성별·연애 선호가 서로 맞아야 합니다.';
  if(partnerOf(g,who)||partnerOf(g,other))return '현재 연인 관계를 먼저 정리해야 합니다.';
  if((p?.declinedUntil||0)>g.time)return '거절한 마음과 거리를 존중할 시간이 필요합니다.';
  if(relation<25||!p||p.affection<30||p.contacts<3)return '신뢰 25·호감 30·함께한 시간 3회가 필요합니다.';
 }
 if(['boundary','breakup','jealousy'].includes(kind)&&p?.stage!=='partners')return '현재 연인인 두 사람의 이야기입니다.';
 if(kind==='reunite'&&(p?.stage!=='exes'||!romanceCompatible(g,a,b)||partnerOf(g,who)||partnerOf(g,other)||relation<20||g.time-p.lastChoice<1200||p.declinedUntil>g.time))return '서로의 선호·신뢰 20과 이별 뒤 20분의 시간이 필요합니다.';
 if(kind==='bias'&&!prejudiceToward(a,b))return '이 주민이 상대 성별에 경계심을 가진 경우에 이야기합니다.';
 return '';
}
export function noteBondContact(g,a,b,hooks,{manual=false}={}){
 if(a.age<18||b.age<18||relatives(g,a,b))return;g.social.bonds??=bondDefaults();const key=pairKey(a.id,b.id),last=g.social.bonds.contactAt[key]??-1000;if(g.time-last<180)return;
 g.social.bonds.contactAt[key]=g.time;const p=ensure(g,a.id,b.id);p.contacts++;if(p.contacts===1){for(const [x,y] of [[a,b],[b,a]])if(prejudiceToward(x,y)){hooks.changeRelationship(g,x.id,y.id,-2);keepMemory(g,x,'bias',y.id,`${particle(y.name,'을','를')} 성별 때문에 경계하며 첫 만남에서 거리를 두었다.`,2);}}const relation=hooks.relationship(g,a.id,b.id),trust=meaningfulMemory(g,a,b)||meaningfulMemory(g,b,a);
 if(relation>=10&&a.stress<65&&b.stress<65&&romanceCompatible(g,a,b)&&(!partnerOf(g,a.id)||partnerOf(g,a.id)?.id===b.id)&&(!partnerOf(g,b.id)||partnerOf(g,b.id)?.id===a.id)){p.affection=clamp(p.affection+(manual?6:trust?3:1));if(p.affection>=25&&p.stage==='friends'&&g.time>=p.declinedUntil)p.stage='interest';}
 if(p.stage==='partners')p.tension=clamp(p.tension-(manual?8:2));
 const witness=partnerOf(g,a.id);if(witness&&witness.id!==b.id&&home(g,witness)&&a.motion&&witness.motion&&Math.hypot(a.motion.x-witness.motion.x,a.motion.y-witness.motion.y)<=3){const old=pairBond(g,a.id,witness.id);old.tension=clamp(old.tension+3);old.rival=b.id;old.jealousWho=witness.id;}
 if(manual){p.lastChange=g.time;keepMemory(g,a,'bond',b.id,`${particle(b.name,'과','와')} 서두르지 않고 함께 시간을 보냈다.`,2);keepMemory(g,b,'bond',a.id,`${particle(a.name,'과','와')} 서두르지 않고 함께 시간을 보냈다.`,2);}
}
function announce(g,hooks,a,b,text){const s=g.social.bonds;s.log.unshift({time:g.time,who:a.id,other:b.id,text});s.log=s.log.slice(0,24);hooks.log(g,text,'story');for(const [r,o] of [[a,b],[b,a]]){keepMemory(g,r,'bond',o.id,text,3);hooks.memory?.(g,r,text);}}
export function startBondEvent(g,who,other,kind){
 if(!['confess','boundary','breakup','reunite','bias','jealousy'].includes(kind)||bondRequestReason(g,who,other,kind))return false;ensure(g,who,other);g.social.bonds.lastEvent=g.time;g.event={kind:'bond',who,other,subtype:kind};g.eventCount++;return true;
}
export function bondEventView(g){
 const e=g.event,a=g.residents[e.who],b=g.residents[e.other],p=pairBond(g,a.id,b.id),names=`${a.name} · ${b.name}`;
 const defs={
  confess:['조심스럽게 꺼낸 마음',`${particle(a.name,'이','가')} ${b.name}에게 조금 다른 마음이 생겼다고 말했다. ${b.name}도 먼저 서로의 뜻을 확인하고 싶어 한다.`,['두 사람의 뜻대로 천천히 만나 본다','아직은 동료로 지낸다','거리를 두고 각자의 마음을 정리한다']],
  boundary:['가까운 사이에도 필요한 여유',`${names}. 함께 지내는 것은 좋지만 혼자 쉴 시간과 일을 나눌 기준도 필요하다.`,['서로의 휴식과 일을 존중하기로 한다','오늘은 함께 쉬고 다시 이야기한다','당분간 각자의 시간을 갖는다']],
  jealousy:['질투보다 먼저 물어볼 것',`${particle(a.name,'은','는')} ${particle(b.name,'이','가')} ${g.residents[p?.rival]?.name||'다른 동료'}와 가까이 이야기하는 모습을 보고 혼자 서운해졌다. 잘못한 사람이 있다고 단정할 일은 아니다.`,['추측 대신 솔직히 이야기한다','감정을 가라앉힐 시간을 갖는다','서로를 탓하며 말을 끝낸다']],
  breakup:['다른 길을 고르는 두 사람',`${names}. 함께한 기억을 지우지 않아도 관계를 끝낼 수 있다. 두 사람의 뜻과 앞으로의 거리를 정한다.`,['서로의 뜻을 존중하고 헤어진다','결정을 미루고 경계를 다시 이야기한다','상처 주는 말을 남기고 헤어진다']],
  reunite:['한 번 더 이야기를 시작할까',`${names}. 헤어진 뒤 시간이 흘렀다. 달라진 마음을 확인하고, 다시 만나더라도 예전의 문제를 반복하지 않기로 한다.`,['서로 동의하고 천천히 다시 만난다','좋은 동료로 남는다','아직은 거리를 유지한다']],
  bias:['한 사람을 다시 바라보기',`${particle(a.name,'은','는')} 지나온 경험 때문에 ${b.name}의 성별을 경계하고 있었다. 함께한 일을 돌아보며, 한 사람을 성별만으로 판단했던 자신의 태도를 이야기한다.`,['상대에게 사과하고 경험을 다시 돌아본다','경계가 있음을 인정하되 예의와 협업을 지킨다','편견을 고집하며 거리를 둔다']],
 };
 const d=defs[e.subtype];if(!d)return null;return {title:d[0],text:d[1],options:d[2].map((label,i)=>({label,available:true,cost:{},effects:({confess:['연인 관계 · 호감 +10 · 관계 +6','동료 관계 · 거절 뒤 휴지기','동료 관계 · 관계 -3'],boundary:['긴장 -20 · 관계 +3','긴장 -10 · 스트레스 -4','긴장 -8 · 관계 -1'],jealousy:['긴장 -20 · 관계 +4','긴장 -8','긴장 +15 · 관계 -5'],breakup:['이별 · 관계 -3','연인 유지 · 긴장 -5','이별 · 관계 -12 · 스트레스 +8'],reunite:['연인 관계 · 관계 +4','이별 관계 유지 · 관계 +2','거리 유지'],bias:['개인으로 판단 · 관계 +4','경계 유지 · 관계 +1','경계 유지 · 관계 -4']})[e.subtype][i]}))};
}
export function resolveBondEvent(g,index,hooks){
 const e=g.event;if(e?.kind!=='bond'||![0,1,2].includes(index)||!bondEventView(g))return false;const a=g.residents[e.who],b=g.residents[e.other],p=ensure(g,a.id,b.id);let relation=0,text='';
 if(e.subtype==='confess'||e.subtype==='reunite'){
  if(index===0){if(!romanceCompatible(g,a,b)||partnerOf(g,a.id)||partnerOf(g,b.id))return false;p.stage='partners';p.affection=clamp(p.affection+10);p.tension=5;p.declines=0;relation=e.subtype==='confess'?6:4;text=`${particle(a.name,'과','와')} ${particle(b.name,'이','가')} 서로의 뜻을 확인하고 만나기로 했다.`;}
  else{if(e.subtype==='confess')p.stage='friends';p.declinedUntil=g.time+1800;p.declines=(p.declines||0)+1;relation=index===1?(e.subtype==='reunite'?2:0):-3;text=`${particle(a.name,'과','와')} ${particle(b.name,'이','가')} ${index===1?'동료로 지내기로':'당분간 거리를 두기로'} 했다.`;}
 }else if(e.subtype==='breakup'){
  if(index===1){p.tension=clamp(p.tension-5);text=`${particle(a.name,'과','와')} ${particle(b.name,'이','가')} 이별 결정을 미루고 경계를 다시 이야기했다.`;}
  else{p.stage='exes';p.declinedUntil=g.time+1200;p.tension=index===2?45:15;relation=index===2?-12:-3;if(index===2)for(const r of [a,b])r.stress=clamp(r.stress+8);text=`${particle(a.name,'과','와')} ${particle(b.name,'이','가')} ${index===2?'상처를 남기며':'서로를 존중하며'} 헤어졌다.`;}
 }else if(e.subtype==='bias'){
  relation=[4,1,-4][index];if(index===0){a.identity={...identityOf(a),outlook:'open'};keepMemory(g,a,'bias',b.id,`${particle(b.name,'과','와')} 함께한 일을 돌아보고 성별만으로 판단하던 경계심을 내려놓았다.`,3);}text=`${particle(a.name,'이','가')} ${particle(b.name,'을','를')} 대하는 태도를 ${index===0?'다시 돌아보았다':index===1?'예의와 협업의 경계로 정리했다':'바꾸지 않았다'}.`;
 }else{p.tension=clamp(p.tension+([e.subtype==='boundary'?-20:-20,-(e.subtype==='boundary'?10:8),e.subtype==='boundary'?-8:15][index]));relation=e.subtype==='boundary'?[3,0,-1][index]:[4,0,-5][index];if(e.subtype==='boundary'&&index===1)for(const r of [a,b])r.stress=clamp(r.stress-4);text=`${particle(a.name,'과','와')} ${particle(b.name,'이','가')} ${e.subtype==='jealousy'?'서운했던 마음':'함께 지낼 거리'}를 ${index===2?'날카롭게':'차분히'} 이야기했다.`;}
 hooks.changeRelationship(g,a.id,b.id,relation);p.lastChoice=g.time;p.lastChange=g.time;delete p.rival;delete p.jealousWho;announce(g,hooks,a,b,text);g.event=null;g.lastEvent=g.time;return true;
}
export function advanceBonds(g,hooks){
 const s=g.social.bonds;if(!s)return;
 for(const [key,at] of Object.entries(s.contactAt))if(g.time-at>3600)delete s.contactAt[key];
 for(const p of Object.values(s.pairs)){
  const a=g.residents[p.a],b=g.residents[p.b];if(!a.alive||!b.alive){if(p.stage==='partners'){p.stage='bereaved';p.lastChange=g.time;const survivor=a.alive?a:b,departed=a.alive?b:a;if(survivor.alive){keepMemory(g,survivor,'loss',departed.id,`${particle(departed.name,'과','와')} 함께했던 약속과 시간을 기억한다.`,3);hooks.log(g,`${particle(survivor.name,'이','가')} 떠난 ${particle(departed.name,'을','를')} 기억했다.`,'story');}}continue;}
  if(p.stage==='partners'&&g.time%180===0){const apart=!!g.expedition?.team.includes(a.id)!==!!g.expedition?.team.includes(b.id);p.tension=clamp(p.tension+(apart&&Math.max(a.stress,b.stress)>55?2:Math.max(a.stress,b.stress)>70?3:-1));}
  if(s.enabled===false||g.social.request||g.event||g.crisis.ready||g.lifeQueue.length||g.time-s.lastEvent<600||g.time-p.lastChoice<900||!home(g,a)||!home(g,b)||g.time<900)continue;
  if((prejudiceToward(a,b)||prejudiceToward(b,a))&&p.contacts>=3&&hooks.relationship(g,a.id,b.id)>=10){g.event={kind:'bond',who:prejudiceToward(a,b)?a.id:b.id,other:prejudiceToward(a,b)?b.id:a.id,subtype:'bias'};g.eventCount++;s.lastEvent=g.time;return;}
  if(p.stage==='interest'&&!p.declines&&p.affection>=30&&p.contacts>=3&&hooks.relationship(g,a.id,b.id)>=25&&!bondRequestReason(g,a.id,b.id,'confess')){g.event={kind:'bond',who:a.id,other:b.id,subtype:'confess'};g.eventCount++;s.lastEvent=g.time;return;}
  if(p.stage==='partners'&&p.tension>=30){g.event={kind:'bond',who:p.jealousWho??a.id,other:p.jealousWho===b.id?a.id:b.id,subtype:p.rival!==undefined?'jealousy':'boundary'};g.eventCount++;s.lastEvent=g.time;return;}
 }
}
export function bondComfort(g,r,people){const near=people.filter(o=>o.id!==r.id&&o.alive&&r.motion&&o.motion&&Math.hypot(r.motion.x-o.motion.x,r.motion.y-o.motion.y)<=3);let value=0;for(const o of near){const p=pairBond(g,r.id,o.id);if(p?.stage==='partners'&&p.tension<30)value=Math.max(value,.08);else if(meaningfulMemory(g,r,o)&&(g.relationships[pairKey(r.id,o.id)]||0)>=15)value=Math.max(value,.03);}return value;}
export function bondFearRelief(g,r,party){return party.some(o=>o.id!==r.id&&(g.relationships[pairKey(r.id,o.id)]||0)>=15&&meaningfulMemory(g,r,o))?.05:0;}
export function validateBonds(g){
 const s=g.social.bonds;if(s===undefined)return true;const int=(n,a=0,b=Number.MAX_SAFE_INTEGER)=>Number.isInteger(n)&&n>=a&&n<=b,validId=id=>int(id,0,g.residents.length-1),dict=o=>!!o&&typeof o==='object'&&!Array.isArray(o);
 if(!dict(s)||(s.enabled!==undefined&&typeof s.enabled!=='boolean')||!dict(s.pairs)||Object.keys(s.pairs).length>512||!int(s.lastEvent,-600,g.time)||!Array.isArray(s.log)||s.log.length>24||!dict(s.contactAt)||Object.keys(s.contactAt).length>g.residents.length**2)return false;
 for(const [k,p] of Object.entries(s.pairs)){if(!p||!validId(p.a)||!validId(p.b)||p.a>=p.b||k!==pairKey(p.a,p.b)||!Object.hasOwn(bondStages,p.stage)||!int(p.affection,0,100)||!int(p.tension,0,100)||!int(p.contacts)||p.declines!==undefined&&!int(p.declines,0,1000000)||!int(p.lastChange,0,g.time)||!int(p.lastChoice,-1200,g.time)||!int(p.declinedUntil,0,g.time+1800)||(p.rival!==undefined&&(!validId(p.rival)||[p.a,p.b].includes(p.rival))||p.jealousWho!==undefined&&![p.a,p.b].includes(p.jealousWho))||p.stage==='partners'&&(g.residents[p.a].age<18||g.residents[p.b].age<18||relatives(g,g.residents[p.a],g.residents[p.b])))return false;}
 const paired=new Set();for(const p of Object.values(s.pairs).filter(p=>p.stage==='partners'))for(const id of [p.a,p.b]){if(paired.has(id))return false;paired.add(id);}
 if(Object.entries(s.contactAt).some(([k,n])=>!/^\d+:\d+$/.test(k)||k.split(':').some(id=>!validId(+id))||!int(n,0,g.time)))return false;
 return s.log.every(e=>e&&int(e.time,0,g.time)&&validId(e.who)&&validId(e.other)&&typeof e.text==='string'&&e.text.length<=1000);
}
export function validBondEvent(g,e){
 if(e?.kind!=='bond'||!['confess','boundary','jealousy','breakup','reunite','bias'].includes(e.subtype)||!Number.isInteger(e.who)||!Number.isInteger(e.other)||e.who===e.other)return false;
 const a=g.residents[e.who],b=g.residents[e.other],p=pairBond(g,e.who,e.other);if(!a?.alive||!b?.alive||a.age<18||b.age<18||!p)return false;
 if(e.subtype==='confess'||e.subtype==='reunite')return romanceCompatible(g,a,b)&&!partnerOf(g,a.id)&&!partnerOf(g,b.id)&&(e.subtype==='reunite'?p.stage==='exes':['friends','interest'].includes(p.stage));
 if(e.subtype==='bias')return prejudiceToward(a,b);
 return p.stage==='partners'&&(e.subtype!=='jealousy'||Number.isInteger(p.rival)&&p.jealousWho===a.id);
}
