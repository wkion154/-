import {researchDefs} from './development-data.js';
import {buildingDefs} from './town.js';
import {personaDefs} from './expansion-data.js';
import {backgrounds} from './founders.js';
import {facilities} from './settlement.js';
import {equipment,combatClasses} from './combat.js';
const resources={food:'식량 · 주민의 식사, 원정 보급과 방문자 맞이에 사용합니다. 숫자는 지금 쓸 수 있는 양입니다.',wood:'자재 · 건설·확장·제작에 사용합니다. 예약한 재료는 이미 사용 가능량에서 제외됩니다. 공사 취소 시 쓰지 않은 양만 반환합니다.',medicine:'의약품 · 거점 치료와 원정 구급약에 사용합니다. 출정 시 구급약은 별도로 챙기며 남은 약은 반환합니다.',records:'공동체 기록 · 높은 단계 시설, 위기 조사와 지식 관련 행동에 사용합니다.'};
export const traitDescriptions={다정함:'곁에 있는 사람의 마음을 살피는 성향입니다. 상황 대화의 말투와 표현에 반영됩니다.',용감함:'두려움 속에서도 앞으로 나아가려는 성향입니다. 상황 대화에 반영되며, 직접적인 공격력 보너스는 없습니다.',호기심:'다른 방법과 새로운 지식을 궁금해합니다. 상황 대화와 배움 속도 +15%에 반영됩니다.',신중함:'준비와 여유를 먼저 확인하려는 성향입니다. 상황 대화에 반영되며, 명중률 보너스는 없습니다.',끈기:'조금씩 계속해 나가려는 성향입니다. 상황 대화와 배움 속도 +8%에 반영됩니다.',낙천적:'작은 희망과 좋은 가능성을 찾는 성향입니다. 상황 대화에 반영되며, 자동 철수 기준은 같습니다.'};
const actions={upgrade:'피난처 확장 · 자재를 쓰기 전에 비용·단계·수용 인원과 효과를 확인합니다.',depart:'원정 출발 · 두 명 또는 세 명을 보냅니다. 출정자는 거점 일을 하지 않습니다. 출발 확인에서 잔류자와 보급을 살펴보세요.',construction:'건설·길 · 시설 선택 → 지도 위치·입구 → 예약 → 건설 담당 이동 → 완공 순서입니다.',armory:'장비·유물 · 제작 뒤 완성된 장비를 주민에게 착용해야 효과가 납니다.',social:'대화·기억 · 실제 위로·화해·완공·귀환의 기록을 봅니다. 직접 요청한 대화는 이동과 시간이 필요합니다.',crisis:'위기 대비 · 창고에 가진 물자가 아니라 실제로 투입한 준비가 대응 점수에 반영됩니다.',pause:'일시정지 / 재개 · 지도 관찰과 지시를 위해 멈출 수 있습니다. Space 단축키도 사용할 수 있습니다.', 'map-expand':'지도 크게 보기 · 접기 버튼이나 Esc로 돌아옵니다. 이 버튼 자체는 시간을 멈추지 않습니다.', 'map-reset':'전체 보기 · 배율과 지도 위치를 처음 상태로 되돌립니다.', 'map-zoom-in':'지도 확대 · 지도 위에서 휠로 마우스 위치를 중심으로 확대·축소할 수도 있습니다.', 'map-zoom-out':'지도 축소 · 지도 밖에서는 휠이 문서 스크롤로 동작합니다.'};
const roles={농사:'농사 · 밭이나 채집 장소로 이동해 식량을 확보합니다.',건설:'건설 · 예약 공사·제작을 우선하고 없으면 자재를 수집합니다.',치료:'치료 · 의약품을 사용해 거점의 부상자를 돌봅니다.',휴식:'휴식 · 피로·스트레스와 체력을 회복합니다.',배움:'배움 · 교육 진행도가 차면 숙련이 성장합니다.',가르침:'가르침 · 함께 배우는 주민의 교육을 돕습니다.'};
function describe(el,g,r){
 if(el.dataset.acceptQuest)return '수락 비용·기한 없음. 최대 세 개를 진행하며 탐사·방어는 수락 후부터 집계합니다.';
 if(el.dataset.claimQuest)return '조건을 갖추면 납품 비용과 실제 보상을 확인하고 한 번 수령합니다.';
 if(el.dataset.frontierTab)return '이 탭에서는 시간이 멈춥니다. 게임으로 돌아가 배속을 누르면 진행합니다.';
 if(el.dataset.help)return el.dataset.help;
 if(el.dataset.resource)return resources[el.dataset.resource]+(el.dataset.resource==='records'&&g.campaign.mode==='settlement'?' 배움·가르침 담당이 실제 학습하며 분당 최대 0.5의 기록을 남깁니다.':'');
 if(el.dataset.job)return roles[el.dataset.job];
 if(el.dataset.facility){const id=el.dataset.facility,level=g.facilities[id];return `${facilities[id]?.name} · ${facilities[id]?.bonus(level)} → ${facilities[id]?.bonus(level+1)}. 건설 담당이 개선 작업을 완성해야 적용됩니다.`;}
 if(el.dataset.craft){const item=equipment[el.dataset.craft];return `${item.name} · ${item.description||'원정에서 착용해 활용합니다.'} ${g.town.legacy?'제작 후 착용하세요.':'예약 작업이 완성된 뒤 착용하세요.'}`;}
 if(el.dataset.placeKind)return `${buildingDefs[el.dataset.placeKind]?.name} · 위치와 입구를 확인한 뒤 작업을 예약합니다.`;
 if(el.dataset.team!==undefined){const person=g.residents[+el.dataset.team];return `${person.name} · ${person.job} / ${combatClasses[person.combatClass]?.name||person.combatClass}. 출정하면 거점 업무를 쉽니다. 체력 45 이상·스트레스/피로/허기 85 미만의 현역 성인이 필요합니다.`;}
 return actions[el.dataset.action];
}
function blocked(el,g){
 if(!el.disabled)return '';
 if(el.dataset.acceptQuest)return '장기 정착 방식에서 중요한 선택을 마치고, 의뢰 자리를 비워 주세요(최대 3개).';
 if(el.dataset.claimQuest)return '목표 진행·납품 자원을 확인하고 중요한 선택을 먼저 마쳐 주세요.';
 if(el.dataset.action==='prepare-raid')return '장기 정착에서 침입 300초 전부터 최대 두 번, 자재 15·식량 5가 필요합니다.';
 if(el.dataset.research){if(g.campaign.mode!=='settlement')return '장기 정착 방식으로 먼저 전환하세요.';if(!g.facilities.school)return '배움터를 먼저 지어야 합니다.';const required=researchDefs[el.dataset.research]?.requires?.filter(k=>!g.development.research.includes(k));if(required?.length)return '선행 연구: '+required.map(k=>researchDefs[k].name).join(' · ');if(g.development.activeResearch)return '진행 중인 연구를 완료하거나 중단하세요.';return '완료한 연구이거나 예약할 재료가 부족합니다.';}
 if(el.dataset.specialize)return '필요 연구·시설·재료·시설 작업 대기 여부를 확인하세요.';
 if(el.dataset.project)return '필요한 연구·시설·재료를 갖추고 다른 사업을 먼저 완료하세요.';
 if(el.dataset.mastery)return '성인의 분야 능력 6 이상, 거점에서 전문 분야가 미선택이어야 합니다.';
 if(g.event||g.crisis.ready)return '현재 선택을 먼저 마쳐 주세요.';
 if(el.dataset.craft){const item=equipment[el.dataset.craft];if(!['shield','kit'].includes(el.dataset.craft)&&!g.facilities.workshop)return '작업장을 먼저 지어야 합니다.';const missing=Object.entries(item.cost||{}).filter(([key,n])=>g[key]<n);if(missing.length)return '부족한 재료: '+missing.map(([key,n])=>`${{wood:'자재',medicine:'의약품',records:'기록',food:'식량'}[key]} ${g[key].toFixed(1)} / ${n}`).join(', ');if(g.town.queue.length>=3)return '작업 대기열이 가득 찼습니다(최대 3건).';}
 if(el.dataset.placeKind){const kind=el.dataset.placeKind,required=buildingDefs[kind].research;if(required&&!g.development.research.includes(required))return researchDefs[required].name+' 연구를 먼저 완료하세요.';return g.facilities[kind]?'이미 건설했습니다. 지도에서 선택해 개선할 수 있습니다.':'이미 건설을 예약했습니다.';}
 if(el.dataset.facility&&g.town.queue.some(q=>q.kind===el.dataset.facility))return '이 시설의 작업이 이미 예약되어 있습니다.';
 if(el.dataset.facility)return g.facilities[el.dataset.facility]>=3?'최대 단계입니다.':'재료·진행 중 시설 작업·대기열을 확인하세요.';
 if(el.dataset.rollFounder!==undefined)return '잠근 주민입니다. 잠금을 풀면 다시 뽑을 수 있습니다. 계승자는 능력을 유지합니다.';
 if(el.dataset.team!==undefined)return '거점의 현역 성인만 출정할 수 있습니다. 체력 45 이상, 스트레스·피로·허기 85 미만인지 확인하세요.';
 if(el.dataset.action==='upgrade')return g.level>=4?'피난처는 최대 4단계입니다.':`자재 ${25*g.level}이 필요합니다. 현재 ${g.wood.toFixed(1)}입니다.`;
 if(el.dataset.action==='depart'&&g.frontier.raid.phase==='battle')return '마을 자동 방어가 진행 중입니다. 30초 방어가 끝난 뒤 출정할 수 있습니다.';
 if(el.dataset.action==='depart')return g.expedition?'이미 원정 중입니다.':'출정 가능한 두 명 또는 세 명과 식량을 확인하세요.';
 return el.title||'현재 조건으로 사용할 수 없습니다. 표시된 재료·인원·진행 상태를 확인하세요.';
}
export function decorateHelp(root,g,selected){
 let disabledIndex=0;
 root.querySelectorAll('[data-resource],[data-job],[data-facility],[data-craft],[data-place-kind],[data-team],[data-help],button[data-action],button:disabled,[data-research],[data-project],[data-specialize],[data-mastery],[data-accept-quest],[data-claim-quest],[data-frontier-tab]').forEach(el=>{const text=describe(el,g,g.residents[selected]),reason=blocked(el,g);if(!text&&!reason)return;el.dataset.tooltip=[text,reason?'사용 불가: '+reason:''].filter(Boolean).join('\n');el.removeAttribute('title');if(el.disabled&&!el.parentElement.classList.contains('disabled-action')){const wrap=document.createElement('span');wrap.className='disabled-action';wrap.id='disabled-help-'+disabledIndex++;wrap.tabIndex=0;wrap.dataset.tooltip=el.dataset.tooltip;wrap.setAttribute('aria-label',el.dataset.tooltip);el.replaceWith(wrap);wrap.append(el);}});
 root.querySelectorAll('[data-job]').forEach(el=>el.dataset.related=el.dataset.job==='농사'?'food':el.dataset.job==='치료'?'medicine':el.dataset.job==='건설'?'wood':'records');
 root.querySelectorAll('[data-craft],[data-facility],[data-place-kind],[data-action=upgrade]').forEach(el=>el.dataset.related='wood');
 root.querySelectorAll('[data-facility=farm],[data-place-kind=farm]').forEach(el=>el.dataset.related='wood food');
 root.querySelectorAll('[data-facility=clinic],[data-place-kind=clinic]').forEach(el=>el.dataset.related='wood medicine');
 root.querySelectorAll('[data-action=depart]').forEach(el=>el.dataset.related='food');
}
export function installTooltips(){let timer=null,current=null,pointer={x:0,y:0};const hide=()=>{clearTimeout(timer);document.querySelector('#game-tooltip')?.remove();current?.removeAttribute('aria-describedby');current=null;};
 const show=(target,immediate=false)=>{if(current&&target?.dataset.tooltip===current.dataset.tooltip){current=target;return;}hide();if(!target)return;current=target;timer=setTimeout(()=>{if(!target.isConnected){target=document.elementFromPoint(pointer.x,pointer.y)?.closest('[data-tooltip]');if(!target)return;current=target;}const tip=document.createElement('div');tip.id='game-tooltip';tip.role='tooltip';tip.textContent=target.dataset.tooltip;document.body.append(tip);target.setAttribute('aria-describedby',tip.id);const box=target.getBoundingClientRect(),rect=tip.getBoundingClientRect();tip.style.left=Math.max(8,Math.min(innerWidth-rect.width-8,box.left))+'px';tip.style.top=(box.bottom+rect.height+10<innerHeight?box.bottom+8:Math.max(8,box.top-rect.height-8))+'px';},immediate?0:400);};
 document.addEventListener('pointermove',e=>{pointer={x:e.clientX,y:e.clientY};});document.addEventListener('pointerover',e=>{const target=e.target.closest('[data-tooltip]');if(target!==current)show(target);const trigger=e.target.closest('[data-related]'),related=trigger?.dataset.related;document.querySelectorAll('.resident.selected').forEach(el=>el.classList.toggle('linked-target',Boolean(trigger?.dataset.job||trigger?.dataset.craft)));document.querySelectorAll('.team button.active').forEach(el=>el.classList.toggle('linked-target',trigger?.dataset.action==='depart'));document.querySelectorAll('.resource').forEach(el=>el.classList.toggle('linked-resource',Boolean(related?.split(' ').includes(el.dataset.resource))));});
 document.addEventListener('pointerout',e=>{if(!current?.contains(e.relatedTarget))hide();});document.addEventListener('focusin',e=>{const target=e.target;if(target.classList.contains('disabled-action'))setTimeout(()=>{if(document.activeElement===target)show(target.closest('[data-tooltip]'),true);},75);else show(target.closest('[data-tooltip]'),true);});document.addEventListener('focusout',hide);document.addEventListener('pointerdown',hide);document.addEventListener('keydown',e=>{if(e.key==='Escape')hide();});document.addEventListener('scroll',hide,true);return hide;
}
export function traitHelp(r){return [traitDescriptions[r.trait]||'성격에 맞는 말투와 관심 주제로 이야기합니다.',personaDefs[r.trait]?`장기 정착에서 피로 ${personaDefs[r.trait].fatigue}부터 자율 휴식, 외로움 ${personaDefs[r.trait].social}부터 교류를 찾습니다.`:'',r.background?backgrounds[r.background].bonus:''].filter(Boolean).join(' ');}
