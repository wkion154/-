export const appearanceChoices={
 hair:['단정한 짧은 머리','옆으로 넘긴 머리','단발','곱슬머리','묶은 머리','아주 짧은 머리','긴 생머리','가운데 가르마','양 갈래','삭발','땋은 머리','높은 묶음 머리'],
 skin:['#efd2ae','#dfb58d','#c9936b','#aa7657','#82553e','#634331'],
 hairColor:['#39463d','#715344','#a0794e','#332d31','#bead7b','#bfc4b3'],
 coat:['#a4b47b','#be956f','#7daba8','#b6a887','#a18ba9','#8e9bb9','#c19b8d','#8ca174'],
 face:['미소','주근깨','눈썹 짙음','턱수염'],accessory:['없음','둥근 안경','머리띠','귀걸이'],
};
export function defaultAppearance(id=0){return {hair:id%6,skin:id%6,hairColor:id%6,coat:id%8,face:id%4,accessory:0};}
export function validAppearance(a){return !!a&&typeof a==='object'&&[6,7].includes(Object.keys(a).length)&&Object.keys(a).every(k=>k==='details'||Object.hasOwn(appearanceChoices,k))&&Object.entries(appearanceChoices).every(([key,values])=>Number.isInteger(a[key])&&a[key]>=0&&a[key]<values.length)&&(a.details===undefined||a.details&&Object.keys(a.details).length===Object.keys(detailChoices).length&&Object.entries(detailChoices).every(([k,v])=>Number.isInteger(a.details[k])&&a.details[k]>=0&&a.details[k]<v.length));}
export function appearance(r){return validAppearance(r.appearance)?r.appearance:defaultAppearance(r.id);}
const hairPaths=[
 'M9 30Q6 8 30 8Q56 8 53 31L42 25 39 16Q23 30 9 30Z',
 'M8 31Q4 7 31 6Q58 7 53 32L45 26 43 16Q25 33 8 31Z',
 'M7 48V26Q6 6 30 7Q55 6 55 27V49L45 45 45 25Q30 17 16 26V46Z',
 'M9 31Q0 26 8 18Q3 6 17 9Q22-1 31 7Q44 0 47 12Q61 10 55 23Q60 34 49 33L43 22 18 22Z',
 'M8 30Q6 8 30 8Q50 7 53 27Q65 22 62 41L51 40 46 25 40 17Q25 30 8 30Z',
 'M10 28Q9 10 30 10Q51 10 52 29L46 24Q30 16 15 25Z',
];
hairPaths.push('M7 60V27Q5 4 31 6Q58 5 56 28V61L46 56V26Q27 15 16 28V58Z','M8 30Q4 6 31 7Q58 6 54 31L45 27 32 14 18 28Z','M10 27Q7 7 30 8Q53 7 52 27L44 21 31 16 17 26ZM9 25Q-2 28 3 54L15 50 16 26ZM49 25Q63 28 59 54L47 50 46 26Z','M11 26Q12 11 31 11Q50 11 52 27Q33 15 11 26Z','M8 30Q4 7 31 7Q56 7 53 30L43 22 30 17 17 28ZM47 31L59 39 48 47 59 55 47 64 43 56 50 48 42 40Z','M17 13Q12-1 29 0Q47-1 44 15ZM8 30Q5 10 30 10Q55 9 53 31L43 24 32 17 18 28Z');
function legacyHeadShapes(r){
 const a=appearance(r),skin=appearanceChoices.skin[a.skin],hair=appearanceChoices.hairColor[a.hairColor];
 const shapes=[{d:'M25 51H38V64H25Z',fill:skin},{d:'M10 31C10 3 52 3 52 31C52 64 10 64 10 31Z',fill:skin},{d:hairPaths[a.hair],fill:hair},
 {d:'M22 34a1.9 1.9 0 1 0 .1 0M39 34a1.9 1.9 0 1 0 .1 0',fill:'#304138'},
 {d:'M25 46Q31 50 37 45',stroke:'#9b6c56'}];
 if(a.face===1)shapes.push({d:'M16 40h1m3 1h1m21-1h1m-5 1h1',stroke:'#a57052'});
 if(a.face===2)shapes.push({d:'M18 28h9m9 0h9',stroke:hair,width:3});
 if(a.face===3)shapes.push({d:'M14 43Q30 58 49 42Q48 61 31 62Q15 60 14 43Z',fill:hair});
 if(a.accessory===1)shapes.push({d:'M16 34a8 7 0 1 0 16 0a8 7 0 1 0-16 0M33 34a8 7 0 1 0 16 0a8 7 0 1 0-16 0M31 34h3',stroke:'#4e6254',width:2});
 if(a.accessory===2)shapes.push({d:'M9 25Q30 15 53 25',stroke:'#c9b177',width:5});
 if(a.accessory===3)shapes.push({d:'M51 42a3 4 0 1 0 .1 0',stroke:'#dfcf8b',width:2});
 return shapes;
}
export function headSVG(r){return headShapes(r).map(s=>`<path d="${s.d}" fill="${s.fill||'none'}" ${s.stroke?`stroke="${s.stroke}" stroke-width="${s.width||1.5}" stroke-linecap="round"`:''}/>`).join('');}
export function portraitSVG(r){return `<svg class="resident-avatar" viewBox="0 0 64 84" aria-hidden="true"><path d="M6 84V69Q31 51 58 69V84Z" fill="${appearanceChoices.coat[appearance(r).coat]}"/><g transform="translate(0 63) scale(1 .55)">${clothingSVG(r)}</g><g>${headSVG(r)}</g><path d="M28 63v21h7V63" fill="#ded2aa" opacity=".6"/></svg>`;}
export function drawHead(c,r){for(const s of headShapes(r)){const path=new Path2D(s.d);if(s.fill){c.fillStyle=s.fill;c.fill(path);}if(s.stroke){c.strokeStyle=s.stroke;c.lineWidth=s.width||1.5;c.lineCap='round';c.stroke(path);}}}

export const detailChoices={shape:['둥근 얼굴','갸름한 얼굴','각진 얼굴','통통한 볼'],brows:['보통','일자','처진 눈썹','굵은 눈썹','올라간 눈썹'],eyes:['동그란 눈','가느다란 눈','웃는 눈','처진 눈','또렷한 눈'],nose:['작은 코','둥근 코','곧은 코','넓은 코'],mouth:['잔잔한 미소','일자 입','작은 미소','활짝 웃음','도톰한 입'],beard:['없음','턱수염','콧수염','짧은 수염','구레나룻'],makeup:['없음','볼 화장','옅은 눈화장','입술색','눈·입 화장'],marks:['없음','주근깨','눈가 흉터','볼의 점','코 위 흉터'],outfit:['기본 튜닉','조끼','앞치마','여행 망토','긴 외투','덧댄 작업복'],trim:['기본 천','목도리','목깃','가로띠','가죽 끈']};
export function legacyDetails(a){return {shape:0,brows:a.face===2?3:0,eyes:0,nose:0,mouth:0,beard:a.face===3?1:0,makeup:0,marks:a.face===1?1:0,outfit:0,trim:0};}
export const detailsOf=r=>appearance(r).details||legacyDetails(appearance(r));
export function headShapes(r){
 const a=appearance(r);if(!a.details)return legacyHeadShapes(r);const d=a.details,skin=appearanceChoices.skin[a.skin],hair=appearanceChoices.hairColor[a.hairColor],shapes=legacyHeadShapes({...r,appearance:{...a,details:undefined,face:0}});shapes.splice(3,2);
 shapes[1]={d:['M10 31C10 3 52 3 52 31C52 64 10 64 10 31Z','M13 30Q12 7 31 9Q50 7 50 30Q48 56 31 61Q14 55 13 30Z','M10 30Q9 9 31 9Q52 9 52 30L49 50 39 59H23L12 48Z','M7 32Q8 8 31 10Q55 8 55 32Q55 59 31 60Q6 58 7 32Z'][d.shape],fill:skin};
 shapes.push({d:['M22 34a1.9 1.9 0 1 0 .1 0M39 34a1.9 1.9 0 1 0 .1 0','M19 34h6m11 0h6','M18 35q4-6 8 0m9 0q4-6 8 0','M18 33l8 3m9 0 8-3','M19 34a3 3 0 1 0 .1 0M38 34a3 3 0 1 0 .1 0'][d.eyes],stroke:'#304138',fill:[0,4].includes(d.eyes)?'#304138':undefined,width:1.6});
 const brows=['','M18 28h9m9 0h9','M18 27l9 3m9 0 9-3','M18 28h9m9 0h9','M18 30l9-4m9 0 9 4'][d.brows];if(brows)shapes.push({d:brows,stroke:hair,width:d.brows===3?3:1.5});
 const nose=['','M29 38q3 4 6 0','M32 33v8h-4','M28 38q4 5 8 0'][d.nose];if(nose)shapes.push({d:nose,stroke:'#9b6c56'});
 shapes.push({d:['M25 46Q31 50 37 45','M25 47h12','M28 47q3 2 6 0','M24 44q7 11 15 0Z','M25 47q7-5 13 0q-7 4-13 0'][d.mouth],stroke:d.makeup>=3?'#9e5f61':'#9b6c56',fill:d.mouth===3?'#f3e0bd':undefined,width:d.makeup>=3?2.5:1.5});
 if(d.beard)shapes.push({d:['','M14 43Q30 58 49 42Q48 61 31 62Q15 60 14 43Z','M24 44q7-7 15 0l-7-1Z','M17 48Q31 59 47 47L42 57 31 61 21 56Z','M11 34h5v15l-5-3ZM47 34h5v12l-5 3Z'][d.beard],fill:hair});
 if(d.makeup===1)shapes.push({d:'M14 41h8m17 0h8',stroke:'#cb8e7d',width:4});if([2,4].includes(d.makeup))shapes.push({d:'M17 31q5-3 10 0m7 0q5-3 10 0',stroke:'#88728a',width:2});
 if(d.marks)shapes.push({d:['','M16 40h1m3 1h1m21-1h1m-5 1h1','M43 28l-5 13','M43 43h.2','M24 38l13-3'][d.marks],stroke:d.marks===3?'#634b3b':'#ad795b',width:d.marks===3?2:1.5});return shapes;
}
export function clothingShapes(r){
 const d=detailsOf(r),color=appearanceChoices.coat[appearance(r).coat],shapes=[];
 if(d.outfit===1)shapes.push({d:'M12 4L24 0 28 38H7ZM40 0L53 5 58 38H36Z',fill:'#4d6050'});
 if(d.outfit===2)shapes.push({d:'M19 0H45V36H14L17 11Z',fill:'#d1c3a0'});
 if(d.outfit===3)shapes.push({d:'M2 37L12 2 32 0 53 3 63 38 42 31 32 10 21 32Z',fill:'#5d7470'});
 if(d.outfit===4)shapes.push({d:'M11 2L25 0 29 40H4ZM40 0L53 3 62 40H36Z',fill:color},{d:'M24 2l-4 13 9 8m11-21 5 13-9 8',stroke:'#d1c3a0',width:3});
 if(d.outfit===5)shapes.push({d:'M9 15H26V29H7ZM40 20H57V32H39Z',fill:'#b69d77'},{d:'M11 17l12 10m19-5 12 8',stroke:'#6c6c51',width:2});
 const trim=['','M16 0Q31 12 49 0L45 9 39 12 38 31H31V12L19 9Z','M18 0L31 10 44 0 40 13H23Z','M7 23H58V29H7Z','M18 0L44 37H38L12 2Z'][d.trim];if(trim)shapes.push({d:trim,fill:d.trim===4?'#786047':'#d1c09a'});return shapes;
}
export const clothingSVG=r=>clothingShapes(r).map(s=>`<path d="${s.d}" fill="${s.fill||'none'}" ${s.stroke?`stroke="${s.stroke}" stroke-width="${s.width||1.5}"`:''}/>`).join('');
export function drawClothing(c,r){for(const s of clothingShapes(r)){const p=new Path2D(s.d);if(s.fill){c.fillStyle=s.fill;c.fill(p);}if(s.stroke){c.strokeStyle=s.stroke;c.lineWidth=s.width||1.5;c.stroke(p);}}}
