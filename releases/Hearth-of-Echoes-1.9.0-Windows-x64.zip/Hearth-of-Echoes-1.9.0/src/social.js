import {particle} from './korean.js';
import {composeDialogue,trackDialogue,validDialogueId} from './dialogue-lines.js';
import {bondDefaults,noteBondContact,startBondEvent,bondRequestReason,advanceBonds,validateBonds} from './bonds.js';
import {keepMemory,memoryKinds} from './memory-effects.js';
import {bonus as effectBonus,preferredTopic} from './expansion-effects.js';
import {areas} from './areas.js';
import {fieldSkill,fieldFactor,abilitiesActive,practice} from './abilities.js';
import {hasSpec} from './development-data.js';
import {topics,voices} from './social-content.js';
import {effectiveRole} from './settlement.js';
import {journeyFrozen} from './journey.js';
import {buildingDefs} from './town.js';
const clamp=n=>Math.max(0,Math.min(100,n));
const home=(g,r)=>r?.alive&&!g.expedition?.team.includes(r.id)&&!(g.frontier?.raid.phase==='battle'&&g.frontier.raid.participants.includes(r.id));
const distance=(a,b)=>a.motion&&b.motion?Math.hypot(a.motion.x-b.motion.x,a.motion.y-b.motion.y):Infinity;
export function socialDefaults(g){return {serial:0,bonds:bondDefaults(),dialogue:{recent:[]},feed:[],recent:[],cooldowns:{},budgets:{},request:null,followups:[],knownBuildings:g.town.buildings.map(b=>b.id),debriefs:[],visitor:null,visitorDone:false};}
export function atmosphere(g){const people=g.residents.filter(r=>r.alive),stress=people.reduce((n,r)=>n+r.stress,0)/Math.max(1,people.length);return g.food<15?'끼니가 걱정되는 날':stress>=55?'서로에게 여유가 필요한 날':g.expedition?'돌아올 발걸음을 기다리는 날':stress<25?'작은 안도감이 머무는 날':'각자의 하루를 이어가는 날';}
export function rememberFact(g,r,kind,other,text){keepMemory(g,r,kind,other,text,['rescue','bond','loss'].includes(kind)?3:['support','reconcile'].includes(kind)?2:1);}
function addScene(g,who,other,topic,lines,effect=null,memory=null){const s=g.social;s.feed.unshift({id:++s.serial,time:g.time,who,other,topic,lines,effect,...(memory?{memory}:{})});s.feed=s.feed.slice(0,48);}
function allowedEffect(g,a,b){const s=g.social,key=[a.id,b.id].sort((x,y)=>x-y).join(':');if((s.cooldowns[key]??-9999)+120>g.time)return false;return [a,b].every(r=>{const budget=s.budgets[r.id];return !budget||g.time-budget.start>=300||budget.count<3;});}
function spendEffect(g,a,b){const s=g.social;s.cooldowns[[a.id,b.id].sort((x,y)=>x-y).join(':')]=g.time;for(const r of [a,b]){let budget=s.budgets[r.id];if(!budget||g.time-budget.start>=300)budget=s.budgets[r.id]={start:g.time,count:0};budget.count++;}}
function emit(g,a,b,topic,hooks,{place='',manual=false,relationshipTime=false}={}){
 const s=g.social,def=topics[topic],busy=b&&(b.needs.fatigue>=80||b.stress>=80),dialogue=composeDialogue(g,a,b,topic,{place,busy,manual});if(!dialogue)return false;trackDialogue(g,dialogue,a,b);const lines=dialogue.lines;let effect=null;
 if(b){
  if(def.effect&&!busy&&allowedEffect(g,a,b)){
   const before={stress:b.stress,relation:hooks.relationship(g,a.id,b.id)};
   const socialEffect=abilitiesActive(g)?(.65+fieldSkill(g,a,'social')*.1)*fieldFactor(g,a,'social')*(hasSpec(g,'lounge','hearth')?1.2:1)*(1+effectBonus(g,'social')):1;b.stress=clamp(b.stress-(topic==='conflict'?2:4)*socialEffect);practice(g,a,'social',8);b.needs.loneliness=clamp(b.needs.loneliness-3);
   hooks.changeRelationship(g,a.id,b.id,topic==='conflict'?4:2);spendEffect(g,a,b);g.metrics.comfort++;
   effect=`${b.name} 스트레스 ${before.stress.toFixed(1)} → ${b.stress.toFixed(1)} · 관계 ${before.relation} → ${hooks.relationship(g,a.id,b.id)}`;
   for(const [r,other] of [[a,b],[b,a]])rememberFact(g,r,topic==='conflict'?'reconcile':'support',other.id,`${particle(other.name,'과','와')} ${def.name}에 마음을 나누었다.`);
   if(manual&&!s.followups.some(f=>f.who===a.id&&f.other===b.id))s.followups.push({who:a.id,other:b.id,due:g.time+120});
  }
 }
 if(b&&!busy)noteBondContact(g,a,b,hooks,{manual:relationshipTime});
 addScene(g,a.id,b?.id??null,topic,lines,effect,dialogue.memory);
 if(effect)hooks.log(g,`${a.name} · ${b.name} / ${def.name} · ${effect}`,'story');
 return true;
}
export function requestConversation(g,who,other,kind='listen'){
 const a=g.residents[who],b=g.residents[other];if(journeyFrozen(g)||g.event||!Number.isInteger(who)||!Number.isInteger(other)||kind==='reconcile'&&(g.relationships[[who,other].sort((a,b)=>a-b).join(':')]||0)>=0||g.social.request||!home(g,a)||!home(g,b)||who===other||a.age<6||b.age<6||!['listen','encourage','reconcile','together','confess','boundary','breakup','reunite','bias'].includes(kind)||!allowedEffect(g,a,b))return false;
 if(!['listen','encourage','reconcile'].includes(kind)&&bondRequestReason(g,who,other,kind))return false;
 g.social.request={who,other,kind,started:g.time,until:g.time+90,progress:0};return true;
}
export function advanceSocial(g,hooks){
 const s=g.social;
 // Compact per-pair state is bounded by the population, independent of elapsed time.
 for(const [key,t] of Object.entries(s.cooldowns))if(g.time-t>600)delete s.cooldowns[key];
 if(s.request){const q=s.request,a=g.residents[q.who],b=g.residents[q.other];
  if(!home(g,a)||!home(g,b)||q.until<g.time){s.request=null;hooks.log(g,`대화 요청을 마치지 못했다. ${q.until<g.time?'만날 장소까지 제시간에 도착하지 못했다.':'원정·마을 방어 등으로 두 사람이 함께할 수 없게 되었다.'}`,'story');}
  else if(a.motion?.arrived&&b.motion?.arrived&&distance(a,b)<=2){q.progress++;if(q.progress>=8){s.request=null;if(['confess','boundary','breakup','reunite','bias'].includes(q.kind)){if(startBondEvent(g,a.id,b.id,q.kind))spendEffect(g,a,b);else hooks.log(g,`${particle(a.name,'과','와')} ${particle(b.name,'이','가')} 지금은 관계 이야기를 미뤘다. ${bondRequestReason(g,a.id,b.id,q.kind)}`,'story');}else if(q.kind==='together'){emit(g,a,b,'friend',hooks,{manual:true,relationshipTime:true});spendEffect(g,a,b);}else emit(g,a,b,q.kind==='reconcile'?'conflict':q.kind==='encourage'?'stress':b.injury>.2||b.hp<90?'injury':'stress',hooks,{manual:true});}}
 }
 // Completed buildings are facts only for people physically at home at completion.
 for(const building of g.town.buildings){if(s.knownBuildings.includes(building.id))continue;s.knownBuildings.push(building.id);
  const witnesses=g.residents.filter(r=>home(g,r));for(const r of witnesses)rememberFact(g,r,'building',null,`${particle(buildingDefs[building.kind].name,'이','가')} 완성되던 날을 보았다.`);
  if(witnesses.length)emit(g,witnesses[0],null,'construction',hooks,{place:buildingDefs[building.kind].name});
 }
 // Do not retain demolished IDs indefinitely.
 s.knownBuildings=s.knownBuildings.filter(id=>g.town.buildings.some(b=>b.id===id));
 const follow=s.followups.find(f=>f.due<=g.time&&home(g,g.residents[f.who])&&home(g,g.residents[f.other])&&distance(g.residents[f.who],g.residents[f.other])<=3);
 if(follow){emit(g,g.residents[follow.who],g.residents[follow.other],'memory',hooks);s.followups=s.followups.filter(f=>f!==follow);}
 s.followups=s.followups.filter(f=>g.time-f.due<600&&g.residents[f.who].alive&&g.residents[f.other].alive).slice(-12);
 if(!s.visitorDone&&!s.visitor&&g.time>=480&&g.time%60===0){s.visitor={seed:(g.seed^0x735A21)>>>0,at:g.time};hooks.log(g,'길가에 생존자 한 명이 도착했다. 사람들 메뉴에서 합류 조건을 살펴볼 수 있다.','story');}
 advanceBonds(g,hooks);
 if(g.time%24||s.request||g.event)return;
 const people=g.residents.filter(r=>home(g,r)&&r.age>=6);if(!people.length)return;
 const a=people[Math.floor(g.time/24)%people.length],near=people.filter(r=>r!==a&&distance(a,r)<=3&&r.motion?.arrived&&a.motion?.arrived);
 const b=near.sort((x,y)=>(x.stress>=45?-10:0)-(y.stress>=45?-10:0)||distance(a,x)-distance(a,y)||x.id-y.id)[0];
 let topic=g.food<15?'hunger':a.guardians.some(id=>!g.residents[id].alive)?'grief':effectiveRole(a)==='배움'||effectiveRole(a)==='가르침'?'learning':g.expedition?'waiting':g.town.roads.length&&g.time%72===0?'roads':a.needs.fatigue>65||effectiveRole(a)==='휴식'?'rest':g.time%60>40?'night':'work';
 if(b&&a.stress<75&&a.needs.fatigue<80){if(hooks.relationship(g,a.id,b.id)<-10)topic='conflict';else if(b.injury>.2||b.hp<90)topic='injury';else if(b.stress>=45)topic='stress';else if(a.memories?.some(m=>m.kind==='support'&&m.other===b.id))topic='memory';else if(a.guardians.includes(b.id)||b.guardians.includes(a.id))topic='family';else if(hooks.relationship(g,a.id,b.id)>=15)topic='friend';}
 if(abilitiesActive(g)&&!['conflict','injury','stress','grief','hunger','memory'].includes(topic)){const extra=preferredTopic(g,a,b);if(extra)topic=extra;}
 if(topic==='memory'&&s.feed.slice(0,5).some(e=>e.topic==='memory'))topic='friend';
 // A subject also rests for three minutes; avoid changing synonyms every few seconds.
 if(s.feed.some(e=>e.who===a.id&&e.topic===topic&&g.time-e.time<180))return;
 emit(g,a,b,topic,hooks);
}
export function recordDebrief(g,e,reason){
 const notes=e.team.map(id=>{const r=g.residents[id];const text=`${e.target}에서 ${e.node}개 지점을 지나 돌아왔다. ${reason}. 체력 ${Math.floor(r.hp)}, 스트레스 ${Math.floor(r.stress)}.`;rememberFact(g,r,'expedition',null,text);return {who:id,text};});
 g.social.debriefs.unshift({time:g.time,target:e.target,reason,nodes:e.node,notes});g.social.debriefs=g.social.debriefs.slice(0,8);
 const speaker=g.residents[e.team[0]],line=speaker.injury>0||speaker.hp<60?'돌아온 지금은 먼저 몸을 돌보고 싶어.':e.node>=5?'끝까지 다녀왔네. 다음에도 돌아올 길을 기억하자.':'이번엔 여기까지였어. 돌아온 만큼 다음을 준비할 수 있어.';
 addScene(g,speaker.id,null,'return',[line]);
}
export function validateSocial(g,{int,finite,validId}){
 const s=g.social,maybe=id=>id===null||validId(id),text=v=>typeof v==='string'&&v.length<=1000,dict=v=>v&&typeof v==='object'&&!Array.isArray(v);
 if(!dict(s)||!int(s.serial)||!Array.isArray(s.feed)||s.feed.length>48||!Array.isArray(s.recent)||s.recent.length>64||!s.recent.every(v=>{if(typeof v!=='string'||!/^[a-z]+:\d+:\d+$/.test(v))return false;const [topic,who,index]=v.split(':');return Object.hasOwn(topics,topic)&&validId(+who)&&int(+index,0,topics[topic].lines.length-1);})||!dict(s.cooldowns)||!dict(s.budgets)||typeof s.visitorDone!=='boolean')return false;
 if(s.feed.some(e=>!e||!int(e.id,1,s.serial)||!finite(e.time,0,g.time)||!validId(e.who)||!maybe(e.other)||!(Object.hasOwn(topics,e.topic)||e.topic==='return')||!Array.isArray(e.lines)||e.lines.length<1||e.lines.length>2||!e.lines.every(text)||e.effect!==null&&!text(e.effect))||new Set(s.feed.map(e=>e.id)).size!==s.feed.length)return false;
 if(Object.entries(s.cooldowns).length>g.residents.length**2||Object.entries(s.cooldowns).some(([k,v])=>!/^\d+:\d+$/.test(k)||!k.split(':').every(x=>validId(+x))||!finite(v,0,g.time))||Object.entries(s.budgets).length>g.residents.length||Object.entries(s.budgets).some(([k,v])=>!/^\d+$/.test(k)||!validId(+k)||!v||!finite(v.start,0,g.time)||!int(v.count,0,3)))return false;
 if(!Array.isArray(s.knownBuildings)||s.knownBuildings.length>448||s.knownBuildings.some(id=>typeof id!=='string'||!/^[a-zA-Z0-9_-]{1,64}$/.test(id))||!Array.isArray(s.followups)||s.followups.length>12||s.followups.some(f=>!f||!validId(f.who)||!validId(f.other)||f.who===f.other||!finite(f.due,0,g.time+120)))return false;
 if(s.request!==null&&(!dict(s.request)||!validId(s.request.who)||!validId(s.request.other)||s.request.who===s.request.other||!['listen','encourage','reconcile','together','confess','boundary','breakup','reunite','bias'].includes(s.request.kind)||!finite(s.request.started,0,g.time)||s.request.until!==s.request.started+90||!int(s.request.progress,0,7)))return false;
 if(s.visitor!==null&&(!s.visitor||!int(s.visitor.seed,0,4294967295)||!finite(s.visitor.at,0,g.time)||s.visitorDone))return false;
 if(s.request&&!['listen','encourage','reconcile'].includes(s.request.kind)&&[s.request.who,s.request.other].some(id=>g.residents[id].age<18))return false;
 if(!Array.isArray(s.debriefs)||s.debriefs.length>8||s.debriefs.some(d=>!d||!finite(d.time,0,g.time)||!Object.hasOwn(areas,d.target)||!text(d.reason)||!int(d.nodes,0,5)||!Array.isArray(d.notes)||![2,3].includes(d.notes.length)||d.notes.some(n=>!n||!validId(n.who)||!text(n.text))))return false;
 if(!validateBonds(g))return false;
 if(s.dialogue!==undefined&&(!s.dialogue||!Array.isArray(s.dialogue.recent)||s.dialogue.recent.length>96||s.dialogue.recent.some(e=>!e||typeof e.id!=='string'||!validDialogueId(e.id)||!validId(e.who)||!maybe(e.other)||!finite(e.at,0,g.time))))return false;
 if(s.feed.some(e=>e.memory!==undefined&&(!e.memory||!Object.hasOwn(memoryKinds,e.memory.kind)||!finite(e.memory.time,0,g.time)||!text(e.memory.text))))return false;
 return g.residents.every(r=>Array.isArray(r.memories)&&r.memories.length<=20&&r.memories.every(m=>m&&finite(m.time,0,g.time)&&Object.hasOwn(memoryKinds,m.kind)&&maybe(m.other)&&text(m.text)&&(m.importance===undefined||int(m.importance,1,3))));
}
