import {particle} from './korean.js';
export {particle} from './korean.js';
import {topics} from './social-content.js';
import {meaningfulMemory} from './memory-effects.js';
import {effectiveRole} from './settlement.js';
const styles={다정함:'warm',이타적:'warm',장난기:'light',낙천적:'light',무뚝뚝함:'dry',회의적:'dry',독립적:'dry',감상적:'quiet',내성적:'quiet',경건함:'quiet',신중함:'careful',꼼꼼함:'careful',실용적:'careful',끈기:'careful',용감함:'bold',성급함:'bold',야심적:'bold',호기심:'curious'};
// Each reply was written for its opening. Style chooses an exchange, never an unrelated suffix.
const rows=`
encourage|careful|오늘 할 일은 하나씩 하자. 급한 것부터 정해 볼까?|좋아. 내 쪽은 정리해 둘게.
encourage|dry|오늘은 어땠어?|별일 없었어. 이렇게 잠깐 쉬는 것도 좋네.
encourage|warm|오늘도 같이 있어서 좋네. 잠깐 이야기할래?|응. 네 쪽 이야기도 듣고 싶었어.
encourage|light|오늘 하루 점수를 매기면 몇 점쯤이야?|밥 먹기 전에는 말 안 하려고. 조금 있다 다시 물어봐.
encourage|quiet|오늘은 좀 어땠는지 궁금했어.|그냥 평소 같았어. 그래도 물어봐 주니 좋네.
encourage|bold|오늘도 같이 해 보자. 어려운 건 나눠 맡으면 되지.|그래. 막히면 바로 말할게.
encourage|curious|오늘 새로 알게 된 거 있어?|가만히 생각해 보니까 하나쯤은 있네. 들어 볼래?
work|careful|오늘 할 일부터 나눠 놓을까? 그래야 덜 헤맬 것 같아.|좋아. 나는 하던 것부터 마저 끝낼게.
work|dry|손 좀 풀고 해야겠다. 아까부터 뻣뻣하네.|도구는 내가 보고 있을게. 잠깐 쉬어.
work|light|이거 다 끝내면 오늘은 내가 먼저 밥 먹는다?|그럼 나도 서둘러야겠네. 내 몫은 남겨 둬.
work|warm|아까 힘든 일 혼자 하던데, 다음엔 불러.|알았어. 혼자 해 보겠다고 좀 고집부렸네.
work|bold|이것만 마무리하고 같이 쉬자.|그래. 끝나는 대로 알려 줘.
work|quiet|별일 없이 일하는 날도 꽤 괜찮네.|응. 오늘은 이 정도면 좋겠다.
work|curious|아까는 어떻게 그렇게 빨리 끝냈어?|손을 바꿔 잡아 봤어. 다음에 보여 줄게.
farm|careful|먹을 건 오늘 쓸 만큼 따로 빼 뒀어.|잘했네. 원정 보급이랑 섞이지 않게 해 두자.
farm|dry|풀 뽑는 건 끝이 없네.|그쪽 끝나면 이쪽도 좀 봐 줘. 나는 물 가져올게.
farm|light|먹는 건 금방인데 모으는 건 한참이야.|그러니까 저녁은 꼭 천천히 먹자.
farm|warm|괜찮아 보이는 건 네 몫으로 남겨 둘게.|고마워. 나는 다음에 물 길어 올게.
farm|bold|손 닿는 데부터 모으자. 오늘 끼니는 챙겨야지.|응. 너무 멀리 가지는 말고.
farm|quiet|오늘은 흙 냄새가 좀 다르네.|조금 쉬었다가 다시 해. 계속 숙이고 있었잖아.
farm|curious|이 잎은 어제보다 많이 폈다. 봤어?|아직. 끝나고 같이 보자.
build|careful|여기 정리하고 나면 공구부터 제자리에 둘게.|좋아. 다음 사람이 찾기 쉽게 해 두자.
build|dry|망치 어디 갔지? 아까 여기 뒀는데.|상자 옆에 있어. 내가 옮겨 놨어, 미안.
build|light|이번엔 손가락 안 찍고 끝냈다.|그건 꽤 큰 성과인데. 다음에도 부탁해.
build|warm|무거운 건 같이 들자. 혼자 들다가 다쳐.|응. 반대쪽 좀 잡아 줄래?
build|bold|이쪽부터 끝내자. 벌여 놓은 일부터 줄이고.|좋아. 다른 건 내가 정리해 둘게.
build|quiet|새로 놓은 나무 냄새가 좋네.|다 만들고 나면 잠깐 앉아 보자.
build|curious|도구 자리를 바꾸면 덜 돌아다녀도 되지 않을까?|한번 옮겨 보자. 불편하면 다시 놓으면 되지.
learning|curious|어제 안 풀리던 게 오늘은 좀 알 것 같아.|어느 부분? 나도 같이 봐도 돼?
learning|careful|잊기 전에 적어 두려고. 또 헷갈리더라.|나중에 찾을 수 있게 제목도 붙여 줘.
learning|dry|아는 줄 알았는데, 다시 보니 아니었네.|그럴 때 있지. 같이 처음부터 보자.
learning|light|오늘 머리는 여기까지만 쓰려고.|그럼 나도 쉬어야겠다. 나만 더 못 외웠거든.
learning|warm|모르는 건 다시 물어봐도 돼.|고마워. 아까 설명한 데부터 한번 더 부탁해.
learning|bold|한 번 더 해 볼게. 이번엔 될 것 같아.|옆에서 보고 있을게. 막히면 말해.
learning|quiet|혼자 볼 때보다 같이 보니까 덜 막막하네.|나도 그래. 급하게 끝낼 필요는 없지.
rest|quiet|잠깐만 이렇게 앉아 있을래.|응. 말 안 해도 괜찮아.
rest|dry|오늘은 손 하나 까딱하기 싫다.|그럼 지금은 쉬어. 남은 건 나중에 하자.
rest|careful|좀 쉬고 나서 돌아갈게. 이 상태로 하면 실수하겠어.|잘 생각했어. 급한 일은 내가 볼게.
rest|light|쉬는 데도 연습이 필요한가 봐. 자꾸 일 생각나.|그럼 하늘 보기부터 하자. 그건 잘할 수 있지?
rest|warm|여기 자리 있어. 같이 쉴래?|좋아. 잠깐 앉았다가 갈게.
rest|bold|오늘은 여기까지. 더 하면 내일 못 움직이겠어.|그래. 내일 일은 내일 하자.
rest|curious|아무것도 안 하니까 오히려 머리가 좀 돌아가네.|생각난 건 적어 두고, 지금은 좀 쉬어.
stress|warm|아까부터 표정이 안 좋던데. 무슨 일 있어?|말해도 될까? 혼자 생각하니까 자꾸 꼬여.
stress|careful|급한 일 아니면 잠깐 쉬자. 지금은 너무 몰린 것 같아.|응. 하나씩 정리하고 다시 해 볼게.
stress|dry|오늘 많이 버겁지?|응. 알아봐 주는 것만으로도 좀 낫네.
stress|quiet|지금은 그냥 옆에 있어 줄까?|그렇게 해 줘. 아직 말은 잘 안 나와.
stress|light|오늘은 웃기려고 안 할게. 같이 바람이나 쐴까?|그래. 잠깐 걷고 싶었어.
stress|bold|혼자 다 맡지 마. 뭘 나누면 돼?|일단 내 얘기부터 좀 들어 줘.
stress|curious|언제부터 마음이 무거웠어?|아까 일 끝나고부터. 잘 설명할 수 있을지 모르겠네.
injury|warm|아픈데 괜찮은 척 안 해도 돼. 앉아 있어.|응. 사실 계속 욱신거렸어.
injury|careful|상처 한번 더 보자. 아까보다 심해진 건 아니지?|움직일 때만 좀 아파. 조심할게.
injury|dry|무리하지 마. 또 다치면 더 오래 쉰다.|알았어. 오늘은 말 들을게.
injury|quiet|돌아와서 다행이야. 지금은 쉬자.|응. 여기 앉아 있으니까 좀 실감 나네.
injury|light|오늘 무거운 거 드는 건 내 차례다. 너는 쉬어.|고맙다. 다음엔 내가 갚을게.
injury|bold|다음 길은 나중에 생각해. 지금은 몸부터야.|알았어. 일단 좀 낫고 나서.
injury|curious|어디 움직일 때 제일 아파?|이쪽. 한번만 좀 봐 줄래?
conflict|careful|아까 네 말을 끝까지 안 들었어. 다시 말해 줄래?|이번에는 내 얘기도 듣겠다는 거지?
conflict|dry|아까 말은 심했어. 미안.|나도 날카로웠어. 다음엔 그렇게 말하지 말자.
conflict|warm|서운한 걸 그냥 넘기고 싶지는 않아.|응. 나도 계속 마음에 걸렸어.
conflict|quiet|아까 일, 아직 생각하고 있었어.|나도. 조용할 때 다시 이야기하자.
conflict|bold|서로 목소리부터 낮추자. 해결은 해야지.|좋아. 누가 맞는지부터 따지지는 말자.
conflict|light|이번엔 농담 안 할게. 진짜로 미안했어.|알겠어. 나도 좀 차분하게 말할게.
conflict|curious|내가 뭘 잘못 알아들었는지 확인하고 싶어.|그럼 처음부터 얘기해 볼게.
friend|light|너 없었으면 오늘 엄청 심심했겠다.|그럼 내일도 내 옆자리 비워 둬.
friend|warm|네가 옆에 있으니까 마음이 좀 놓여.|나도 그래. 말 안 해도 편하네.
friend|dry|오늘도 수고했다.|너도. 밥은 같이 먹자.
friend|quiet|이렇게 별일 없는 날이 오래 갔으면 좋겠다.|응. 오늘 같은 날은 좀 기억해 두자.
friend|careful|내일도 같이 할 거면 시간 맞춰 두자.|좋아. 밥 먹고 나서 여기서 보자.
friend|bold|다음에도 같이 가자. 네가 있으면 든든해.|그래. 준비는 같이 하자.
friend|curious|우리 처음 만났을 때 기억나?|기억나지. 그때는 이렇게 같이 살 줄 몰랐네.
hunger|careful|남은 식량부터 확인하자. 다음 끼니는 챙겨야 해.|원정 준비보다 그게 먼저겠다.
hunger|dry|먹을 게 얼마 안 남았네.|오늘은 채집하는 손이 더 필요하겠어.
hunger|warm|네 몫까지 덜지는 마. 같이 나눠 먹자.|알았어. 나만 참으면 될 줄 알았네.
hunger|light|배에서 자꾸 소리 나네. 못 들은 척해 줘.|나도 방금 그랬어. 같이 먹을 것부터 찾자.
hunger|bold|오늘은 먹을 것부터 모으자.|응. 다른 일은 급한 것만 하자.
hunger|quiet|빈 그릇 보니까 괜히 마음이 급해지네.|서두르다 다치지는 말고. 같이 해 보자.
night|quiet|바람 소리 들려? 낮에는 몰랐는데.|응. 불 곁에서는 더 잘 들리네.
night|light|오늘 일은 여기서 마감. 이제 아무도 안 부른다?|급한 일 아니면 나도 못 들은 척할게.
night|warm|추우면 좀 더 가까이 앉아.|고마워. 여기 있으니까 따뜻하네.
night|dry|늦었다. 들어가자.|불씨만 확인하고 갈게.
night|careful|자기 전에 불만 한 번 더 볼게.|내가 물건은 정리해 둘게.
night|bold|오늘도 무사히 끝났네.|그러게. 내일도 이랬으면 좋겠다.
waiting|careful|돌아오면 바로 쉴 수 있게 자리부터 비워 둘까?|좋아. 치료할 것도 확인해 둘게.
waiting|quiet|자꾸 길 쪽을 보게 되네.|나도 그래. 그래도 여기 일은 해 둬야지.
waiting|warm|돌아오면 먼저 밥부터 챙겨 주고 싶어.|응. 얼굴 한번 보고 나면 마음이 놓이겠지.
waiting|dry|아직 소식 없지?|응. 조금만 더 기다려 보자.
waiting|light|다녀오면 얘깃거리 좀 가져오겠지?|별일 없었다는 얘기면 더 좋겠다.
waiting|bold|우리는 여기 지키고 있자.|그래. 돌아올 곳은 있어야지.
roads|careful|입구까지 막히지 않게 길을 남겨 두자.|응. 짐 들고 돌아올 때도 편해야지.
roads|dry|전보다 걷기는 편하네.|이쪽으로 놓길 잘했지.
roads|light|이제 길 잃었다는 핑계는 못 대겠다.|너는 마을 안에서도 그 핑계였잖아.
roads|warm|돌아올 때 이 길 보면 좀 안심되겠지?|응. 누가 기다리고 있는 길이니까.
roads|quiet|발자국이 한쪽으로 모이네.|그러게. 조금씩 마을 같아져.
roads|curious|여기서 꺾으면 덜 돌아가도 되지 않을까?|입구만 안 막히면 괜찮겠네. 같이 보자.
family|warm|돌보는 것도 혼자 다 하지는 마.|고마워. 잠깐 맡기고 쉬어도 될까?
family|quiet|작은 발소리 들릴 때마다 돌아보게 돼.|나도 그래. 어느새 이렇게 익숙해졌네.
family|light|오늘은 질문을 열 번도 넘게 받았어.|내일은 내가 몇 개 나눠 받을게.
family|careful|배우는 속도는 좀 기다려 주자.|응. 우리도 처음에는 서툴렀지.
family|dry|오늘은 네가 먼저 쉬어. 내가 볼게.|고맙다. 조금만 쉬고 올게.
family|curious|같은 걸 봐도 전혀 다른 질문을 하더라.|그러니까. 나도 다시 생각하게 돼.
grief|quiet|습관처럼 이름을 부르려다가 멈췄어.|그럴 때 있지. 오늘은 그냥 같이 있자.
grief|warm|그 사람 얘기, 하고 싶으면 들어 줄게.|응. 오늘은 조금 말하고 싶어.
grief|dry|오늘 많이 생각나지?|응. 별것 아닌 일이 자꾸 생각나.
grief|careful|하던 일은 나눠서 하자. 혼자 다 맡지 말고.|알았어. 아직 빈자리가 크게 느껴져.
grief|light|그때 했던 농담이 오늘 문득 생각났어.|나도 기억나. 같이 웃었던 건 남아 있네.
grief|bold|급하게 괜찮아지려고 하지는 마.|응. 조금씩 해 볼게.
construction|careful|{place}까지 드나드는 길은 비워 뒀어.|잘됐네. 짐 들고 오갈 때도 편하겠다.
construction|light|어제는 없던 {place}, 벌써 익숙한 척하고 있네.|이제 우리 집이니까. 좀 자랑해도 되지.
construction|warm|{place}도 생겼네. 여기서 같이 오래 지냈으면 좋겠다.|응. 하나씩 만들어 가는 게 좋네.
construction|dry|{place}, 다 됐다.|수고했어. 이제 공구는 내려놓자.
construction|quiet|이제 {place}도 있네. 처음 왔을 때랑 많이 달라.|그러게. 그때는 텐트부터 펼쳤는데.
construction|bold|{place}까지 끝냈다. 다음엔 좀 쉬자.|좋아. 오늘은 충분히 했어.
`;
export const exchanges=rows.trim().split('\n').map((row,i)=>{const [topic,style,line,reply]=row.split('|');return {id:'pair'+i,topic,style,line,reply};});
export function dialogueStyle(r){return styles[r.trait]||'careful';}

function placeText(line,place){return line.replaceAll('{place}가',particle(place,'이','가')).replaceAll('{place}를',particle(place,'을','를')).replaceAll('{place}',place);}
export function composeDialogue(g,a,b,topic,{place='이곳',busy=false,manual=false}={}){
 const history=g.social.dialogue?.recent||[],style=dialogueStyle(a),role=effectiveRole(a),key=manual&&b&&b.stress<30&&topic==='stress'?'encourage':topic==='work'?(role==='농사'?'farm':role==='건설'?'build':'work'):topic;
 let candidates=exchanges.filter(d=>d.topic===key),memory=b?meaningfulMemory(g,a,b):null;
 if(topic==='memory'&&b){if(!memory)return null;candidates=[{id:'memory-'+memory.kind,style,line:memory.kind==='rescue'&&memory.text.startsWith(b.name)?'그때 도와준 거, 아직 기억하고 있어. 돌아오고 나서야 마음이 놓이더라.':'그날 같이 있었던 일은 아직도 생각나.',reply:'나도 기억나. 다음에도 서로 챙기자.'}];}
 const def=topics[topic],map=[0,1,2,3,0,2];if(def&&key!=='encourage'&&(topic!=='memory'||memory?.kind==='support'))candidates.push(...def.lines.map((line,i)=>({id:'base-'+topic+i,style:'base',line,reply:def.responses[map[i]%def.responses.length]})));
 if(!candidates.length)return null;
 if(!b){const solo=soloLines[key];if(solo)candidates=solo.map((line,i)=>({id:'solo'+key+i,style,line,reply:null}));else candidates=candidates.filter(d=>!/[네너]가|너는|네가|고마워|부탁해|같이/.test(d.line));if(!candidates.length)return null;}
 const eligible=candidates.filter(d=>!history.some(h=>h.id===d.id&&g.time-h.at<720));if(!eligible.length&&!manual)return null;
 const pool=eligible.length?eligible:candidates,preferred=pool.filter(d=>d.style===style),authored=pool.filter(d=>d.style!=='base'),choices=preferred.length?preferred:authored.length?authored:pool,pick=choices[(g.social.serial+a.id)%choices.length];
 let reply=pick.reply;if(busy)reply=dialogueStyle(b)==='dry'?'미안. 지금은 좀 쉬고 싶어.':dialogueStyle(b)==='light'?'오늘은 받아칠 기운도 없네. 조금 쉬고 얘기하자.':'지금은 이야기를 듣기에도 벅차네. 좀 쉰 다음에 다시 얘기해도 될까?';
 if(b&&dialogueStyle(b)==='dry')reply=reply?.replace('고마워.','고맙다.').replace(/^응\./,'그래.');
 if(!b)reply=null;
 return {id:pick.id,lines:[placeText(pick.line,place),...(reply?[placeText(reply,place)]:[])],memory:memory?{kind:memory.kind,time:memory.time,text:memory.text}:null};
}
export function trackDialogue(g,d,a,b){g.social.dialogue??={recent:[]};g.social.dialogue.recent.push({id:d.id,who:a.id,other:b?.id??null,at:g.time});g.social.dialogue.recent=g.social.dialogue.recent.slice(-96);}
export const soloLines={
 farm:['오늘 먹을 건 챙겨 놔야지.','손 좀 털고 다시 하자.','괜찮아 보이는 것부터 모아 두자.','벌써 배고파지네. 조금만 더 하고 쉬자.'],
 build:['공구부터 정리하자. 또 찾으러 다니겠네.','이쪽 마무리하고 손 좀 풀어야겠다.','하나씩 하자. 벌여 놓은 것부터.','끝나면 잠깐 앉아 있어야겠어.'],
 work:['오늘은 여기까지만 마무리하자.','도구 놓은 자리를 또 잊었네.','급하게 하면 꼭 다시 하게 되더라.','잠깐 숨 좀 돌리자.'],
 learning:['잊기 전에 적어 둬야겠다.','이건 다시 봐도 헷갈리네.','조금씩은 익숙해지고 있겠지.','여기까지만 보고 눈 좀 쉬자.'],
 rest:['잠깐만 이렇게 앉아 있자.','오늘은 좀 쉬어도 되겠지.','쉬고 나서 다시 생각하자.','괜히 일거리 찾지 말고 좀 쉬자.'],
 night:['바람이 좀 차네.','불씨만 보고 들어가야겠다.','오늘도 끝났구나.','조용하니까 별생각이 다 나네.'],
 waiting:['돌아오면 먼저 상태부터 봐야지.','자꾸 길 쪽을 보게 되네.','무사히만 돌아와 줬으면.','기다리는 동안 여기 일은 해 놓자.'],
 hunger:['남은 먹을 것부터 확인하자.','오늘은 채집을 더 해야겠네.','급해도 다치지는 말자.','빈 그릇 보니까 마음이 급해지네.'],
 grief:['습관처럼 이름을 부를 뻔했네.','오늘따라 빈자리가 크게 느껴진다.','그때 한 말이 아직도 생각나네.','금방 괜찮아지지는 않겠지.'],
 construction:['{place}까지 끝났네.','이제 {place}도 있구나.','{place}, 우리 손으로 지었네.','{place}부터 잘 써야지.'],
};

export function validDialogueId(id){return exchanges.some(e=>e.id===id)||Object.entries(topics).some(([key,d])=>d.lines.some((_,i)=>id==='base-'+key+i))||Object.entries(soloLines).some(([key,lines])=>lines.some((_,i)=>id==='solo'+key+i))||['support','reconcile','rescue','bond'].some(kind=>id==='memory-'+kind);}
