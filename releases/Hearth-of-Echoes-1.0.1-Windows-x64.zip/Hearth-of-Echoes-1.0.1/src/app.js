import {tutorialPages,tutorialContents,applyTutorialSetup,tutorialHomeResident} from './tutorial.js';
import {areas,areaUnlocked} from './areas.js';
import {readPreferences,capturePresentation,presentationChanges,tutorialSteps} from './presentation.js';
import {Soundscape} from './audio.js';
import {settingsContents} from './settings-view.js';
import {
  createGame,tick,day,depart,retreat,decide,upgrade,away,serialize,restore,
  eventView,connections,world,journeySummary,nextJourney,living,capacity,
  lifeStage,availableRoles,setJob,canExpedition,needsDecision,familyLinks,
  familyReadiness,welcomeChild,assignMentor,retireResident,YEAR_SECONDS,setCombatClass,craftEquipment,equipResident,activateRelic,chooseRoute,upgradeFacility,setAutonomy,setPersonalGoal,contributeCrisis,beginCrisis,resolveCrisis,continueSettlement,
} from './game.js';
import {battlePanel,loadoutPanel,formationView,armoryContents,relicLabel} from './combat-view.js';
import {crisisStrip,crisisContents,endingContents} from './journey-view.js';
import {journeyFrozen,eligibleHeirs,endingTypes} from './journey.js';
import {needsPanel,goalPanel,facilitiesContents} from './settlement-view.js';
import {activityLabel} from './settlement.js';
import {combatClasses,equipment} from './combat.js';
import {drawWorld,colors} from './scene.js';

// Keep the storage key stable; restore() migrates older snapshots in memory.
const KEY='hearth-save-v1';
const PREFERENCE_KEY='hearth-preferences-v1';
const preferences=readPreferences(readStorage(PREFERENCE_KEY),globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
const audio=new Soundscape();
let presented=null,feedback={},feedbackUntil=0,lastSpeed=1,lastFrame=0;
let hasSaved=Boolean(readStorage(KEY));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function readStorage(key){try{return localStorage.getItem(key);}catch{return null;}}
function freshGame(){return createGame(globalThis.crypto?.getRandomValues(new Uint32Array(1))[0]??(Date.now()>>>0));}
let g,loadWarning='',pendingImport=null;
try{const raw=localStorage.getItem(KEY);g=raw?restore(raw):freshGame();}
catch{g=freshGame();loadWarning='저장을 읽지 못했습니다. 기존 파일은 자동으로 덮어쓰지 않습니다. 이전 저장을 복구하거나 새 여정을 수동 저장하세요.';}
let selected=living(g)[0]?.id??0,team=[0,1,2],policy='신중',target='숲';
let view=g.expedition?'expedition':'settlement';
let modal=readStorage('hearth-intro')?null:'help',heirId=0,guardians=[],familyMode='adoption';
let tutorialPage=0;
let dirty=false,lastPersist=Date.now(),positions=[];
function save(manual=false){
  try{
    const previous=localStorage.getItem(KEY);
    if(previous){try{restore(previous);localStorage.setItem(KEY+'-backup',previous);}catch{}}
    localStorage.setItem(KEY,serialize(g));dirty=false;hasSaved=true;lastPersist=Date.now();
    if(manual){loadWarning='';toast('피난처의 기록을 저장했습니다.');}
  }catch{toast('저장 공간에 접근할 수 없습니다. 브라우저 설정을 확인하세요.');}
}
function exportSave(){
  const url=URL.createObjectURL(new Blob([serialize(g)],{type:'application/json'}));
  const link=document.createElement('a');link.href=url;link.download=`hearth-cycle-${g.cycle}-day-${day(g)}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
  toast('현재 진행을 저장 파일로 내보냈습니다.');
}
function importSave(){
  const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.id='save-file';input.hidden=true;document.body.append(input);
  input.addEventListener('cancel',()=>input.remove(),{once:true});
  input.addEventListener('change',async()=>{
    const file=input.files?.[0];input.remove();if(!file)return;
    try{if(file.size>2*1024*1024)throw Error('too large');pendingImport=restore((await file.text()).replace(/^\uFEFF/,''));modal='import-confirm';render();}
    catch{pendingImport=null;toast('지원하지 않거나 손상된 저장 파일입니다. 현재 진행은 유지됩니다.');}
  },{once:true});input.click();
}
function toast(text){
  document.querySelector('.toast')?.remove();const el=document.createElement('div');
  el.className='toast';el.setAttribute('role','status');el.textContent=text;document.body.append(el);setTimeout(()=>el.remove(),3500);
}
function storePreferences(){
  try{localStorage.setItem(PREFERENCE_KEY,JSON.stringify(preferences));}catch{toast('이 브라우저에서 설정을 보존할 수 없습니다.');}
  document.documentElement.classList.toggle('reduced-motion',!preferences.motion);document.documentElement.classList.toggle('full-motion',preferences.motion);
  document.documentElement.classList.toggle('high-contrast',preferences.contrast);
}
function configureAudio(){audio.configure(preferences).catch(()=>toast('소리를 재생할 수 없습니다. 소리 설정을 다시 확인하세요.'));}
function drawScene(now=performance.now()){
  const advancing=!modal&&g.speed&&!journeyFrozen(g)&&!needsDecision(g);
  const interpolation=advancing&&preferences.motion?Math.min(.95,(now-lastSimulationFrame)/1000)*g.speed:0;
  positions=drawWorld(g,selected,{...preferences,visualTime:g.time+interpolation,ambientTime:now/1000});
}
let lastSimulationFrame=performance.now();
function guidePanel(){
  if(!preferences.guide||g.ending||g.cycle>1)return '';
  const steps=tutorialSteps(g),current=steps.find(s=>!s.done),done=steps.filter(s=>s.done).length;
  return `<section class="first-steps" aria-label="플레이 안내"><div><small>첫 불빛을 위한 안내 · ${done}/${steps.length}</small><h3>${current?current.title:'첫 준비를 마쳤습니다'}</h3><p>${current?current.text:'이제 사람들의 삶과 다음 세대를 돌보며 성소와 위기에 도전하세요.'}</p></div>${button('tutorial','처음 하는 법 · 따라하기',false,'primary')}${current?`<button data-guide="${current.action}">${current.label} ↗</button>`:''}<button data-action="hide-guide" aria-label="초반 안내 숨기기">×</button></section>`;
}
function focusState(){const el=document.activeElement;if(!el||el===document.body)return null;return {id:el.id,data:{...el.dataset},dialog:Boolean(el.closest('[role=dialog]'))};}
function restoreFocus(state,previousDialog){
  const dialog=document.querySelector('[role=dialog]');document.querySelector('main').inert=Boolean(dialog);
  let target=state?.id?document.getElementById(state.id):null;
  if(!target&&state&&Object.keys(state.data).length)target=[...document.querySelectorAll('button')].find(el=>Object.entries(state.data).every(([key,value])=>el.dataset[key]===value)&&Boolean(el.closest('[role=dialog]'))===state.dialog);
  if(dialog&&previousDialog!==dialog.getAttribute('aria-label'))target=dialog.querySelector('button:not(:disabled),input:not(:disabled),select:not(:disabled)');
  if(target&&!target.disabled)target.focus({preventScroll:true});
}
const portrait=r=>`<div class="portrait ${r.age<16?'child':''} ${r.age>=60?'elder':''}" style="--coat:${colors[r.id%colors.length]}"></div>`;
const signed=n=>`${n>0?'+':''}${n}`;
function button(action,label,disabled=false,classes=''){
  return `<button data-action="${action}" ${disabled?'disabled':''} class="${classes}">${label}</button>`;
}
function resourcePanel(){
  return [['식량','◒',g.food],['자재','▱',g.wood],['의약품','✚',g.medicine],['공동체 기록','⌑',g.records]]
    .map(([label,icon,value])=>`<div class="resource"><span>${label}</span><i>${icon}</i><b>${Math.floor(value)}</b></div>`).join('');
}
function residentsPanel(){
  return `<aside class="panel population"><div class="panel-title"><h2>우리의 사람들</h2><small>${living(g).length} / ${capacity(g)}</small></div>
    <div class="residents">${living(g).map(r=>`<button class="resident ${r.id===selected?'selected':''}" data-person="${r.id}">
      ${portrait(r)}<div class="person-info"><strong>${esc(r.name)}</strong> <small style="display:inline">${r.age}세</small>
      <small><i class="dot"></i>${away(g,r.id)?'원정 중':activityLabel(r)} · ${lifeStage(r)}</small>
      <div class="bar"><i style="width:${r.hp}%"></i></div><div class="bar stress"><i style="width:${r.stress}%"></i></div></div></button>`).join('')}</div>
    <div class="sidebar-foot"><small>자라나는 이야기</small><p>${Math.floor(g.time/YEAR_SECONDS)+1}번째 생애의 해</p>
    <small>기본 속도 2분 = 생애 1년<br>16세 성인 · 60세 은퇴 선택<br>자연사 전에는 항상 멈춥니다.</small></div></aside>`;
}
function settlementPanel(){
  return `<section class="panel"><div class="scene-top"><h2>${world(g).name} <small>${world(g).description}</small></h2>
    <button class="upgrade" data-action="upgrade" ${g.gameOver||g.event||g.wood<25*g.level||g.level>=4?'disabled':''}>${g.level>=4?'확장 완료':`확장 · 자재 ${25*g.level}`} / Lv.${g.level}</button></div>
    <div class="scene"><canvas id="world" width="1120" height="650" aria-label="주민과 아이들이 함께 살아가는 숲속 정착지"></canvas>
    <div class="scene-tag"><b>● 함께 살아가는 터전</b> · ${g.expedition?'돌아올 사람들을 기다립니다.':'오늘의 배움이 내일의 삶이 됩니다.'}</div></div>
    <div class="legend"><span>식당 · 작업장 · 의무실 · 쉼터 · 배움터</span><span>주민을 누르면 상세 정보</span></div></section>`;
}
function familyDescription(r){
  const links=familyLinks(g,r.id),parts=[];
  if(links.guardians.length)parts.push(`보호자: ${links.guardians.map(p=>`${p.name}${p.alive?'':' (추모)'}`).join(', ')}`);
  if(links.children.length)parts.push(`자녀: ${links.children.map(p=>p.name).join(', ')}`);
  if(links.previous.length)parts.push(`이전 터전의 가족: ${links.previous.join(', ')}`);
  return parts.map(esc).join('<br>')||'아직 맺어진 가족이 없습니다.';
}
function detailPanel(r){
  const mentorCandidates=living(g).filter(p=>p.id!==r.id&&p.age>=16&&p.skill>=2);
  return `<section class="panel detail"><div class="detail-head">${portrait(r)}<div><h2>${esc(r.name)} <small>${r.age}세 · ${r.generation}세대</small></h2>
    <small>${esc(r.trait)} · 숙련 ${r.skill} · ${lifeStage(r)}</small></div><span class="badge" style="margin-left:auto">${!r.alive?'추모':away(g,r.id)?'원정 중':r.job}</span></div>
    <div class="detail-grid"><div>${needsPanel(g,r,away(g,r.id))}<div class="stats"><div class="stat"><span>체력 <b>${Math.floor(r.hp)}/100</b></span><div class="bar"><i style="width:${r.hp}%"></i></div></div>
    <div class="stat"><span>스트레스 <b>${Math.floor(r.stress)}/100</b></span><div class="bar stress"><i style="width:${r.stress}%"></i></div></div></div>
    <div class="job-row"><label>생활 초점</label>${availableRoles(g,r).map(job=>`<button data-job="${job}" class="${r.job===job?'active':''}" ${g.event||away(g,r.id)?'disabled':''}>${job}</button>`).join('')}</div>
    ${r.alive&&r.age>=6?`<div class="learning-row"><label for="mentor">스승</label><select id="mentor" ${g.event||away(g,r.id)?'disabled':''}><option value="">자동 연결</option>
      ${mentorCandidates.map(p=>`<option value="${p.id}" ${r.mentorId===p.id?'selected':''}>${esc(p.name)} · ${p.job}</option>`).join('')}</select><small>배움 ${Math.floor(r.education*100)}%</small></div>`:''}
    ${r.alive&&r.age>=55&&!r.retired?button('retire','현역 은퇴 · 가르침',g.event||away(g,r.id)):''}${loadoutPanel(g,r)}${goalPanel(g,r,away(g,r.id))}</div>
    <div class="biography">${esc(r.history[0])}<div class="family-summary">${familyDescription(r)}</div><small>부상 ${Math.ceil(r.injury)} · 후유증 ${r.trauma}<br>
    ${!r.alive?`${r.deathDay}일째, 노환으로 세상을 떠났습니다.`:r.age<6?'보호자의 돌봄을 받습니다. 보호자의 농사·건설 생산 -15%.':r.job==='가르침'?'배움을 선택한 주민의 성장을 돕습니다.':r.job==='배움'?'스승이 가르침에 전념하면 더 빨리 배웁니다.':r.job==='치료'?'의약품으로 거점의 부상자를 치료합니다.':'경험과 선택이 생애에 남습니다.'}</small></div></div>
    <div class="connection-strip"><small>함께 살아가는 사람들</small>${connections(g,r.id).slice(0,3).map(c=>`<button data-person="${c.id}" class="relationship ${c.value<0?'negative':''}">${esc(c.name)}${c.alive?'':' †'} · ${c.label} ${signed(c.value)}</button>`).join('')}
    ${button('journal','생애 전체 보기 ↗')}</div></section>`;
}
function expeditionPanel(){
  const e=g.expedition;
  return `<section class="panel"><div class="panel-title"><h2>경계 너머로</h2><small>${e?'탐사 진행 중':'원정대 편성'}</small></div><div class="exp-content">${e?`
    <h3>${areas[e.target].name}</h3><p class="description">${e.team.map(id=>esc(g.residents[id].name)).join(' · ')}<br>${e.policy} 방침 · 확보 자재 ${e.loot}</p>
    <div class="route">${[1,2,3,4,5].map(n=>`<i class="${e.node>=n?'done':''}">${n}</i>`).join('')}</div><div class="bar"><i style="width:${e.battle?e.battle.clock/2*100:e.choice?100:e.wait/4*100}%"></i></div>
    <div class="combat-report">${e.report[0]?`<strong>${esc(e.report[0].title)}</strong><p>${esc(e.report[0].text)}</p>`:'첫 탐사 지점으로 이동 중입니다.'}</div>
    <p class="description">보급 ${e.supplies} · 구급약 ${e.medkits}<br>전방: ${esc(g.residents[e.team[0]].name)} · 유물: ${relicLabel(g)}<br>체력 35 미만 또는 스트레스 85 이상이면 자동 철수합니다. 피로한 원정대는 공격력이 줄어듭니다.</p>${button('retreat','지금 귀환시키기',false,'primary')}`:`
    <p class="description">셋이 길을 나섭니다. 미성년자와 은퇴한 주민은 거점을 지킵니다.</p><div class="fields">
    <select id="target" aria-label="원정 지역">${Object.entries(areas).map(([id,area])=>`<option value="${id}" ${target===id?'selected':''} ${areaUnlocked(g,id)?'':'disabled'}>${area.name} · ${areaUnlocked(g,id)?area.difficulty:'숲 완주 후 개방'}</option>`).join('')}</select>
    <select id="policy" aria-label="원정 방침"><option ${policy==='신중'?'selected':''}>신중</option><option ${policy==='강행'?'selected':''}>강행</option></select></div>
    <p class="description">${areas[target].description} 완주: 기록 ${areas[target].rewardRecords}${areas[target].rewardMedicine?` · 의약품 ${areas[target].rewardMedicine}`:''} · 유물 발견</p><div class="team">${living(g).map(r=>`<button data-team="${r.id}" class="${team.includes(r.id)?'active':''}" ${!canExpedition(g,r.id)?'disabled':''}>${team.includes(r.id)?'✓ ':''}${esc(r.name)}${r.age<16?' (아이)':r.retired?' (은퇴)':''}</button>`).join('')}</div>
    ${formationView(g,team)}<small class="loadout-note">구급약 최대 3개를 따로 챙기며, 남은 약은 귀환 시 돌려줍니다. 유물: ${relicLabel(g)}</small>${button('depart','원정 출발 · 식량 8',g.gameOver||g.event||team.length!==3||g.food<8,'primary')}
    <p class="notice">${team.length!==3?'체력·마음·배고픔·피로가 준비된 성인 세 명을 선택하세요.':'강행: 전리품 +50%, 피해 증가. 전방에 수호자, 후방에 사수·치유사를 권합니다.'}</p>`}</div></section>`;
}
function chroniclePanel(){
  return `<section class="panel journal"><div class="panel-title"><h2>불 곁의 기록</h2><small>CHRONICLE</small></div><div class="entries">
  ${g.log.slice(0,30).map(l=>`<div class="entry ${l.kind}"><time>${Math.floor(l.time/60)+1}일째 · ${String(l.time%60).padStart(2,'0')}</time>${esc(l.text)}</div>`).join('')}</div></section>`;
}
function dialog(content,classes='',label='피난처 이야기'){
  return `<div class="overlay"><section class="modal ${classes}" role="dialog" aria-modal="true" aria-label="${label}">${content}</section></div>`;
}
function journalModal(r){
  return dialog(`<small>한 사람의 삶 · ${r.generation}세대 · ${lifeStage(r)}</small><h2>${esc(r.name)}의 이야기</h2><div class="journal-columns"><div><h3>삶에 남은 순간들</h3>
    <ol class="life-timeline">${r.history.map(h=>`<li>${esc(h)}</li>`).join('')}</ol></div><div><h3>가족과 배움</h3><p class="description">${familyDescription(r)}<br>${r.mentorId!==null?`스승: ${esc(g.residents[r.mentorId].name)}`:''}</p><h3>관계</h3>
    ${connections(g,r.id).filter(c=>c.alive||c.value!==0).map(c=>`<button data-person="${c.id}" class="relationship-row"><strong>${esc(c.name)}${c.alive?'':' †'}</strong><span>${c.label} · ${signed(c.value)}</span></button>`).join('')}
    <p class="description">관계 15 이상: 원정 피해·스트레스 감소.<br>친한 동료와 휴식: 스트레스 회복 +50%.<br>원정 직업은 생활 역할과 별개입니다. 아이와 은퇴한 스승도 삶의 주인공입니다.</p></div></div>${button('close-modal','피난처로 돌아가기')}`,'journal-modal','생애와 관계');
}
function familyModal(){
  const ready=familyReadiness(g,guardians,familyMode),candidates=living(g).filter(r=>r.age>=18&&r.age<70);
  const cost=Object.entries(ready.cost).map(([k,n])=>`${{food:'식량',wood:'자재',medicine:'의약품'}[k]} ${n}`).join(' · ');
  return dialog(`<small>다음 세대가 살아갈 곳</small><h2>새로운 가족 맞이하기</h2><div class="family-modes"><button data-family-mode="adoption" class="${familyMode==='adoption'?'active':''}">8세 아이 입양</button><button data-family-mode="birth" class="${familyMode==='birth'?'active':''}">0세 아이 출생</button></div>
    <p class="description">보호자를 선택하세요. 입양은 한 명 또는 두 명, 출생은 관계 35 이상의 두 명이 필요합니다. 현재 주민 ${living(g).length}/${capacity(g)}명.</p>
    <div class="heirs">${candidates.map(r=>`<button data-guardian="${r.id}" class="${guardians.includes(r.id)?'active':''}" ${away(g,r.id)?'disabled':''}>${guardians.includes(r.id)?'✓ ':''}${esc(r.name)}<small>${r.age}세 · ${r.job}</small></button>`).join('')}</div>
    <p class="notice">${esc(ready.reason)}</p><p class="description">필요 자원: ${cost}<br>6세부터 배움, 16세부터 성인의 삶을 시작합니다. 6세 미만 아이를 돌보는 보호자는 농사·건설 생산 효율이 15% 줄어듭니다.</p>
    ${button('welcome-child',familyMode==='birth'?'새 생명 맞이하기':'가족으로 맞이하기',!ready.allowed,'primary')}${button('close-modal','조금 더 준비하기')}`,'family-modal','가족 맞이하기');
}
function memorialModal(){
  const dead=g.residents.filter(r=>!r.alive);
  return dialog(`<small>여기서 살아간 사람들</small><h2>불 곁에 남은 이름</h2><p class="description">${dead.length?'한 사람의 끝이 그가 남긴 배움과 관계를 지우지는 않습니다.':'아직 떠나보낸 주민이 없습니다. 마지막 인사는 자동 모드에서도 직접 확인합니다.'}</p>
    <div class="memorial-list">${dead.map(r=>`<button data-memorial="${r.id}"><strong>${esc(r.name)} · ${r.age}세</strong><small>${r.generation}세대 · ${r.deathDay}일째 · 노환</small><p>${esc(r.history.find(h=>!h.includes('노환'))||r.history[0])}</p></button>`).join('')}</div>${button('close-modal','지금의 사람들에게 돌아가기')}`,'journal-modal','추모 기록');
}
function legacyModal(){
  const summary=journeySummary(g),eligible=eligibleHeirs(g),recordOnly=eligible.length===0&&Boolean(g.ending);
  if(!eligible.some(r=>r.id===heirId))heirId=eligible[0]?.id??-1;
  return dialog(`<small>한 여정의 끝, 다른 이야기의 시작</small><h2>불씨를 이어갈 사람</h2><p>${esc(summary.place)}에서 ${summary.days}일을 함께 살았습니다.<br>원정 ${summary.expeditions}회 · ${g.totalBirths}명의 새 가족 · 추모 ${g.residents.filter(r=>!r.alive).length}명</p>
    <div class="heirs">${living(g).map(r=>`<button data-heir="${r.id}" class="${heirId===r.id?'active':''}" ${!eligible.some(p=>p.id===r.id)?'disabled':''}>${esc(r.name)}<small>${r.age}세 · ${r.generation}세대 · 숙련 ${r.skill}</small></button>`).join('')}</div>
    <p class="description">성인 한 명의 숙련·나이·생애·가족 이름과 공동체 기록을 보존합니다. 착용 장비와 활성 유물 하나도 이어갑니다. 다른 가족이 함께 이동하지는 않습니다. 새 동료 다섯 명과 초기 자원으로 시작하며 관계는 초기화됩니다. 계승 주민은 치료받지만 젊어지지는 않습니다.<br>누적 생산 보너스 +${Math.min(10,g.legacyPoints+(g.ending&&!g.ending.success?0:1))*5}% (최대 50%).${g.ending&&!g.ending.success?' 대피·실패에서는 승리 보너스가 늘지 않습니다. 어린이가 계승하면 새 공동체에서 성장합니다.':''}${recordOnly?' 남겨진 기록과 함께 새로운 주민 여섯 명으로 시작합니다.':''}</p>
    <div class="past-journeys">${g.legacy.slice(-3).map(j=>`<small>${j.cycle}번째 · ${esc(j.place)} · ${j.days}일 · 원정 ${j.expeditions}회${j.outcome?` · ${endingTypes[j.outcome].title}`:''}</small>`).join('')}</div>
    ${button('continue-journey',heirId<0?(recordOnly?'기록을 이어 새 공동체로':'계승할 성인이 없습니다'):`${esc(g.residents[heirId].name)}와 다음 피난처로`,heirId<0&&!recordOnly,'primary')}${button('close-modal','아직 이곳에 머무르기')}`,'legacy-modal','여정의 계승');
}
function eventModal(){
  const ev=eventView(g),farewell=g.event.kind==='farewell';
  return dialog(`<small>${farewell?'마지막 인사 · 자동으로 진행되지 않습니다':'삶의 갈림길 · 시간은 잠시 멈춥니다'}</small><h2>${esc(ev.title)}</h2><p>${esc(ev.text)}</p>
    ${farewell?`<ol class="life-timeline farewell-timeline">${g.residents[g.event.who].history.slice(0,5).map(h=>`<li>${esc(h)}</li>`).join('')}</ol>`:''}
    ${ev.options.map((op,i)=>`<button data-choice="${i}" ${op.available?'':'disabled'}>${esc(op.label)}<small>${esc(op.effects)}</small></button>`).join('')}`,'','삶의 갈림길');
}
function helpModal(){
  if(!readStorage('hearth-intro'))return dialog(`<small>정착지 · 자동 원정 · 세대의 이야기</small><h2>처음 목표는 안개 숲에서 돌아오기</h2><p>주민은 자동으로 일하고 싸웁니다. 당신은 생활 역할과 원정대를 정하고, 귀환한 사람들의 몸과 마음을 돌봅니다.</p><ol class="tutorial-instructions"><li>거점에 농사·건설·치료 담당 세 명을 남깁니다.</li><li>수호자·척후병·치유사를 안개 숲으로 보냅니다.</li><li>안전한 길을 고르고, 돌아오면 휴식과 치료를 합니다.</li></ol>${button('tutorial','처음 하는 법 · 6단계로 따라하기',false,'primary')}${button('begin','설명 없이 바로 시작')}<small>안내를 읽는 동안 시간은 멈춥니다. 상단 「처음 하는 법」에서 언제든 다시 볼 수 있습니다.</small>`,'','플레이 안내');
  return dialog(`<small>한 세대가 남긴 불씨, 다음 세대의 삶</small><h2>이곳에서 다시 살아갑니다.</h2><p>생활 초점과 별도로 원정 직업·장비를 정하고 전방 1명, 후방 2명을 편성하세요. 장비·유물은 작업장에서 준비합니다. 표식과 사격, 방어와 치료를 조합하고 길의 분기에서 우회·지름길·야영을 선택하세요. 성소의 문지기를 쓰러뜨리면 이번 여정을 완료합니다.<br><br>「위기 대비」에서 다가오는 겨울·병해·포위에 필요한 물자를 투입하세요. 위기가 닥치면 최종 결정 전 시간이 멈춥니다. 준비가 충분하면 일찍 대응할 수도 있습니다.<br><br>「시설·생활」에서 생산·치료·교육을 개선하세요. 피로한 주민은 자율적으로 쉬고 돌아오며, 개인 목표를 이룰 수 있습니다.<br><br>「가족 맞이」로 아이를 돌보고, 배움과 가르침으로 경험을 전하세요. 아이는 16세에 진로를 고르고, 어른은 60세에 은퇴를 고민합니다.</p>
    ${button('tutorial','처음 하는 법 · 따라하기',false,'primary')}${button('begin','게임으로 돌아가기')}<small>기본 1배속: 하루 60초, 생애 1년 120초. 아이는 원정에 나가지 않습니다. 노환에 의한 마지막 인사는 자동 모드에서도 직접 확인합니다. 종료 중에는 시간이 흐르지 않습니다.</small>`,'','플레이 안내');
}
function render(){
  const focus=focusState(),previousDialog=document.querySelector('[role=dialog]')?.getAttribute('aria-label');
  const scroll=document.querySelector('.modal')?.scrollTop||0;
  const current=capturePresentation(g),changes=presentationChanges(presented,current);presented=current;
  if(changes.sounds.length){feedback=changes;feedbackUntil=performance.now()+700;for(const cue of changes.sounds)audio.play(cue);}
  const visibleFeedback=preferences.motion&&performance.now()<feedbackUntil?feedback:{};
  if(!g.expedition)view='settlement';
  if(g.expedition?.choice&&!g.autoEvents)view='expedition';
  const r=g.residents[selected]||g.residents[0],oldScroll=document.querySelector('.entries')?.scrollTop||0;
  const listScroll=document.querySelector('.residents')?.scrollTop||0;
  if(!g.expedition)team=team.filter(id=>canExpedition(g,id));
  const message=g.gameOver?'마지막 불빛이 잦아들었습니다. 추모 기록을 돌아보고 새 여정을 시작할 수 있습니다.':g.cleared?'✧ 성소를 밝혔습니다. 이곳에서 다음 세대를 키우거나 「여정 계승」으로 새 터전을 향하세요.':g.totalBirths?'다음 세대가 자라고 있습니다. 배움과 가르침을 연결하고, 성인 원정대의 몸과 마음도 돌봐 주세요.':g.relics.includes('lantern')?'채석장과 수로가 열렸습니다. 주민을 회복하고 지역에 맞는 장비를 준비하세요.':'첫 목표 · 세 명의 원정대를 안개 숲에 보내고, 돌아온 사람들의 삶을 돌보세요.';
  let overlay='';
  if(modal==='import-confirm'&&pendingImport)overlay=dialog(`<h2>이 저장으로 이어서 할까요?</h2><p>${pendingImport.cycle}번째 여정 · ${day(pendingImport)}일째 · 생존 ${living(pendingImport).length}명<br>현재 진행을 교체합니다. 먼저 내보내기로 보관할 수 있습니다.</p>${button('export-save','현재 진행 내보내기')}${button('confirm-import','이 저장 불러오기',false,'primary')}${button('cancel-import','취소')}`,'','저장 불러오기 확인');
  else if(modal==='settings')overlay=dialog(settingsContents(preferences),'settings-modal','화면과 소리');
  else if(modal==='help')overlay=helpModal();
  else if(modal==='tutorial')overlay=dialog(tutorialContents(g,tutorialPage),'tutorial-modal',`처음 하는 법 · ${tutorialPage+1}단계`);
  else if(needsDecision(g))overlay=eventModal();
  else if(g.crisis.ready)overlay=dialog(crisisContents(g),'crisis-modal','위기 최종 대응');
  else if(modal==='legacy')overlay=legacyModal();
  else if(modal==='journal')overlay=journalModal(r);
  else if(modal==='family')overlay=familyModal();
  else if(modal==='facilities')overlay=dialog(facilitiesContents(g),'facilities-modal','시설과 생활');
  else if(modal==='armory')overlay=dialog(armoryContents(g),'armory-modal','작업장과 유물');
  else if(modal==='memorial')overlay=memorialModal();
  else if(modal==='crisis')overlay=dialog(crisisContents(g),'crisis-modal','위기 대비');
  else if(modal==='ending'||g.ending&&(!g.crisis.sandbox||g.gameOver)&&!modal)overlay=dialog(endingContents(g),'ending-modal','여정의 결말');
  else if(modal==='reset')overlay=dialog(`<h2>새로운 여정을 시작할까요?</h2><p>현재 주민과 가족, 추모·계승 기록이 초기화됩니다. 계승하려면 성소를 완료한 후 「여정 계승」을 사용하세요.</p>${button('confirm-reset','초기화하고 시작')}${button('close-modal','계속 살아가기')}`);
  document.querySelector('#app').innerHTML=`<main data-time="${g.time}" class="shell ${g.expedition?'on-expedition':''}"><header class="top"><div class="brand"><span class="emblem">♧</span><div><h1>잔향의 피난처</h1><small>THE HEARTH OF ECHOES</small></div></div><div class="resources">${resourcePanel()}</div></header>
    <nav class="toolbar"><div class="season">☀ ${g.cycle}번째 여정 · ${day(g)}일 <span>${living(g).length}명의 삶 · ${Math.floor(g.time/YEAR_SECONDS)+1}번째 해</span></div>
    ${button('pause','Ⅱ',false,g.speed===0?'active':'')}${[1,2,4,8].map(s=>`<button data-speed="${s}" class="${g.speed===s?'active':''}">${s}×</button>`).join('')}
    ${button('save','저장')}${button('facilities','시설·생활')}${button('armory','장비·유물')}${button('family','가족 맞이',g.gameOver)}${button('journal','생애·관계')}${button('memorial','추모')}${button('auto-events',`선택: ${g.autoEvents?'자동':'직접'}`,false,g.autoEvents?'active':'')}
    ${(g.cleared||g.ending)?button('legacy','여정 계승',g.expedition||g.event||g.crisis.ready,'active'):''}${button('settings','화면·소리')}${button('sound',preferences.sound?'♫ 소리 켜짐':'♪ 소리 꺼짐')}${button('tutorial','처음 하는 법')}${button('help','도움말')}${button('reset','새 여정')}</nav>
    ${crisisStrip(g)}${guidePanel()}${!preferences.guide||g.cycle>1||g.ending?`<div class="guide">${message}</div>`:''}${loadWarning?`<p class="notice">${esc(loadWarning)} ${button('recover','이전 저장 복구')}</p>`:''}
    <section class="layout">${residentsPanel()}<div class="center"><nav class="view-tabs"><button data-view="settlement" class="${view==='settlement'?'active':''}">정착지</button><button data-view="expedition" class="${view==='expedition'?'active':''}" ${!g.expedition?'disabled':''}>원정 현장</button><small>${view==='expedition'?'거점의 일상은 계속됩니다':'주민의 하루를 살펴보세요'}</small></nav>${view==='expedition'?battlePanel(g,visibleFeedback):settlementPanel()}${detailPanel(r)}</div><aside class="right">${expeditionPanel()}${chroniclePanel()}</aside></section>
    <footer class="footer"><span>잔향의 피난처 · 다가오는 계절 / 계승 ${g.legacyPoints}회 · 생산 +${Math.min(10,g.legacyPoints)*5}%</span><span class="save-status" aria-label="게임 저장 상태">${loadWarning?'저장 중지':dirty?'변경 사항 있음 · 10초마다 자동 저장':hasSaved?'✓ 저장됨':'자동 저장 대기'} · 종료 중 진행 없음</span></footer></main>${overlay}`;
  drawScene();
  const entries=document.querySelector('.entries');if(entries)entries.scrollTop=oldScroll;
  const list=document.querySelector('.residents');if(list)list.scrollTop=listScroll;
  const currentDialog=document.querySelector('[role=dialog]');if(currentDialog&&currentDialog.getAttribute('aria-label')===previousDialog)currentDialog.scrollTop=scroll;
  restoreFocus(focus,previousDialog);
}
function openFamily(){
  const eligible=living(g).filter(r=>r.age>=18&&r.age<70&&!away(g,r.id));
  guardians=eligible.some(r=>r.id===selected)?[selected]:eligible.slice(0,1).map(r=>r.id);familyMode='adoption';modal='family';
}
function resetView(){selected=living(g)[0]?.id??0;team=living(g).filter(r=>canExpedition(g,r.id)).slice(0,3).map(r=>r.id);modal=null;}
function perform(action){
  switch(action){
    case 'pause':if(g.speed){lastSpeed=g.speed;g.speed=0;}else g.speed=lastSpeed;lastSimulationFrame=performance.now();dirty=true;break;
    case 'settings':modal='settings';break;
    case 'sound':preferences.sound=!preferences.sound;storePreferences();configureAudio();break;
    case 'hide-guide':preferences.guide=false;storePreferences();break;
    case 'save':save(true);break;
    case 'export-save':exportSave();break;
    case 'import-save':importSave();break;
    case 'cancel-import':pendingImport=null;modal='settings';break;
    case 'confirm-import':if(pendingImport){g=pendingImport;pendingImport=null;g.speed=0;target='숲';resetView();view=g.expedition?'expedition':'settlement';presented=null;feedback={};loadWarning='';dirty=true;save(true);}break;
    case 'journal':modal='journal';break;
    case 'family':openFamily();break;
    case 'armory':modal='armory';break;
    case 'facilities':modal='facilities';break;
    case 'crisis':modal='crisis';break;
    case 'ending':modal='ending';break;
    case 'confront':if(beginCrisis(g)){modal=null;dirty=true;}break;
    case 'continue-home':if(continueSettlement(g)){modal=null;dirty=true;save();}break;
    case 'memorial':modal='memorial';break;
    case 'close-journal':case 'close-legacy':case 'cancel-reset':case 'close-modal':modal=null;break;
    case 'help':modal='help';break;
    case 'tutorial':tutorialPage=0;modal='tutorial';try{localStorage.setItem('hearth-intro','1');}catch{}break;
    case 'tutorial-prev':tutorialPage=Math.max(0,tutorialPage-1);break;
    case 'tutorial-next':tutorialPage=Math.min(tutorialPages.length-1,tutorialPage+1);break;
    case 'tutorial-finish':modal=null;break;
    case 'tutorial-setup':{const result=applyTutorialSetup(g);if(result){team=result;selected=0;target='숲';policy='신중';dirty=true;toast('추천 배치를 적용했습니다. 다음 설명을 읽거나 원정 편성으로 이동하세요.');}break;}
    case 'tutorial-resident':modal=null;selected=tutorialHomeResident(g);view='settlement';break;
    case 'tutorial-expedition':modal=null;if(g.expedition)view='expedition';break;
    case 'tutorial-crisis':modal='crisis';break;
    case 'begin':modal=null;try{localStorage.setItem('hearth-intro','1');}catch{}break;
    case 'depart':if(depart(g,team,policy,target))view='expedition';else toast('편성·체력·스트레스·식량을 확인하세요.');dirty=true;break;
    case 'retreat':retreat(g);dirty=true;break;
    case 'upgrade':upgrade(g);dirty=true;break;
    case 'retire':if(retireResident(g,selected)){dirty=true;toast('이제 다음 세대를 가르치는 삶을 시작합니다.');}break;
    case 'auto-events':g.autoEvents=!g.autoEvents;dirty=true;toast(g.autoEvents?'자원 안에서 자동 결정합니다. 마지막 인사는 직접 확인합니다.':'삶의 갈림길을 직접 결정합니다.');break;
    case 'legacy':modal='legacy';heirId=selected;break;
    case 'continue-journey':{const next=nextJourney(g,heirId);if(next){g=next;resetView();save();toast('새로운 터전에서도 삶은 이어집니다.');}break;}
    case 'welcome-child':{const child=welcomeChild(g,guardians,familyMode);if(child){selected=child.id;modal=null;dirty=true;toast(`${child.name}의 이야기가 시작됩니다.`);}else toast(familyReadiness(g,guardians,familyMode).reason);break;}
    case 'reset':modal='reset';break;
    case 'confirm-reset':g=freshGame();resetView();loadWarning='';save();break;
    case 'recover':try{g=restore(localStorage.getItem(KEY+'-backup'));resetView();loadWarning='';dirty=true;toast('이전 저장을 복원했습니다.');}catch{toast('복구 가능한 이전 저장이 없습니다.');}break;
  }
}
document.addEventListener('click',ev=>{
  const b=ev.target.closest('button');if(!b||b.disabled)return;
  if(preferences.sound&&!audio.context)configureAudio();audio.play('click');
  if(b.dataset.person!==undefined)selected=+b.dataset.person;
  if(b.dataset.endingPerson!==undefined){selected=+b.dataset.endingPerson;modal='journal';}
  if(b.dataset.prepare&&contributeCrisis(g,b.dataset.prepare))dirty=true;
  if(b.dataset.resolution&&resolveCrisis(g,b.dataset.resolution)){modal=null;dirty=true;save();}
  if(b.dataset.view&&['settlement','expedition'].includes(b.dataset.view))view=b.dataset.view;
  if(b.dataset.memorial!==undefined){selected=+b.dataset.memorial;modal='journal';}
  if(b.dataset.heir!==undefined)heirId=+b.dataset.heir;
  if(b.dataset.speed){g.speed=+b.dataset.speed;lastSpeed=g.speed;lastSimulationFrame=performance.now();dirty=true;}
  if(b.dataset.job&&setJob(g,selected,b.dataset.job))dirty=true;
  if(b.dataset.team!==undefined){const id=+b.dataset.team;if(canExpedition(g,id))team=team.includes(id)?team.filter(x=>x!==id):team.length<3?[...team,id]:team;}
  if(b.dataset.choice!==undefined){if(decide(g,+b.dataset.choice))dirty=true;}
  if(b.dataset.familyMode)familyMode=b.dataset.familyMode;
  if(b.dataset.guardian!==undefined){const id=+b.dataset.guardian;guardians=guardians.includes(id)?guardians.filter(x=>x!==id):guardians.length<2?[...guardians,id]:guardians;}
  if(b.dataset.front!==undefined){const index=team.indexOf(+b.dataset.front);if(index>0)[team[0],team[index]]=[team[index],team[0]];}
  if(b.dataset.facility&&upgradeFacility(g,b.dataset.facility)){dirty=true;toast('시설을 개선했습니다. 생활과 작업의 효율이 높아집니다.');}
  if(b.dataset.autonomy!==undefined){const id=+b.dataset.autonomy;if(setAutonomy(g,id,!g.residents[id].autonomy))dirty=true;}
  if(b.dataset.craft&&craftEquipment(g,b.dataset.craft)){dirty=true;toast('장비를 제작했습니다. 주민의 장비 칸에서 착용하세요.');}
  if(b.dataset.relic!==undefined){if(activateRelic(g,b.dataset.relic||null))dirty=true;}
  if(b.dataset.route&&chooseRoute(g,b.dataset.route))dirty=true;
  if(b.dataset.guide){if(b.dataset.guide==='facilities'||b.dataset.guide==='crisis')modal=b.dataset.guide;else if(b.dataset.guide==='resident')selected=living(g)[0]?.id??0;else if(g.expedition)view='expedition';}
  if(b.dataset.tutorialPage!==undefined)tutorialPage=Number(b.dataset.tutorialPage);
  if(b.dataset.action)perform(b.dataset.action);
  render();
  if(b.dataset.action==='tutorial-resident')document.querySelector('.detail')?.scrollIntoView({block:'center',behavior:'instant'});
  if(b.dataset.action==='tutorial-expedition')document.querySelector('.exp-content')?.scrollIntoView({block:'center',behavior:'instant'});
  if(b.dataset.guide==='resident')document.querySelector('.detail')?.scrollIntoView({block:'center',behavior:preferences.motion?'smooth':'instant'});
  if(b.dataset.guide==='expedition')document.querySelector('.exp-content')?.scrollIntoView({block:'center',behavior:preferences.motion?'smooth':'instant'});
});
document.addEventListener('change',ev=>{
  if(ev.target.dataset.pref){const key=ev.target.dataset.pref;if(Object.hasOwn(preferences,key)){preferences[key]=ev.target.checked;storePreferences();if(['sound','music','ambience'].includes(key))configureAudio();render();}return;}
  if(ev.target.id==='personal-goal'){if(setPersonalGoal(g,selected,ev.target.value))dirty=true;render();}
  if(ev.target.id==='target'){target=ev.target.value;render();}
  if(ev.target.id==='policy')policy=ev.target.value;
  if(ev.target.id==='combat-class'){if(setCombatClass(g,selected,ev.target.value))dirty=true;render();}
  if(ev.target.id==='gear'){if(equipResident(g,selected,ev.target.value))dirty=true;render();}
  if(ev.target.id==='mentor'){if(assignMentor(g,selected,ev.target.value===''?null:+ev.target.value))dirty=true;render();}
});
document.addEventListener('click',ev=>{
  if(ev.target.id!=='world'||modal||needsDecision(g))return;
  const rect=ev.target.getBoundingClientRect(),x=(ev.clientX-rect.left)/rect.width*1120,y=(ev.clientY-rect.top)/rect.height*650;
  const p=positions.find(p=>Math.hypot(p.x-x,p.y-y)<25);if(p){selected=p.id;render();}
});
setInterval(()=>{
  if(!modal&&g.speed&&!journeyFrozen(g)&&!needsDecision(g)){
    tick(g,g.speed);lastSimulationFrame=performance.now();dirty=true;if(document.activeElement?.tagName!=='SELECT')render();
  }
  if(dirty&&!loadWarning&&Date.now()-lastPersist>10000)save();
},1000);
document.addEventListener('input',ev=>{
  if(ev.target.id==='volume'){preferences.volume=Number(ev.target.value)/100;audio.setVolume(preferences.volume);try{localStorage.setItem(PREFERENCE_KEY,JSON.stringify(preferences));}catch{}document.querySelector('#volume-output').textContent=`${ev.target.value}%`;}
});
document.addEventListener('keydown',ev=>{
  const dialog=document.querySelector('[role=dialog]');
  if(ev.key==='Tab'&&dialog){const controls=[...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled)')];if(controls.length){const first=controls[0],last=controls.at(-1);if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}}return;}
  if(ev.repeat||ev.ctrlKey||ev.metaKey||ev.altKey)return;
  if(ev.key==='Escape'){if(modal==='settings'||modal==='help'||modal==='tutorial'||(!needsDecision(g)&&!g.crisis.ready)){ev.preventDefault();if(modal==='help')perform('begin');else modal=null;render();}return;}
  if(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName))return;
  const key=ev.key.toLowerCase();
  if(key==='m'){ev.preventDefault();perform('sound');render();return;}
  if(key==='s'){ev.preventDefault();save(true);render();return;}
  if(modal||needsDecision(g)||journeyFrozen(g))return;
  if(ev.code==='Space'){ev.preventDefault();perform('pause');render();}
  else if(['1','2','4','8'].includes(key)){g.speed=Number(key);lastSpeed=g.speed;lastSimulationFrame=performance.now();dirty=true;render();}
});
document.addEventListener('visibilitychange',()=>audio.visibility(document.hidden));
function animate(now){requestAnimationFrame(animate);if(document.hidden||modal||needsDecision(g)||journeyFrozen(g)||!preferences.motion||now-lastFrame<33)return;lastFrame=now;drawScene(now);}
storePreferences();requestAnimationFrame(animate);
window.addEventListener('pagehide',()=>{if(dirty&&!loadWarning)save();});
render();
