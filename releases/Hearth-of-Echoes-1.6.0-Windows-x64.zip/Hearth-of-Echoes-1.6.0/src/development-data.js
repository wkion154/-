export const researchDefs={
 agriculture:{name:'경작 지식',text:'밭 전문화 해금',cost:{wood:20,records:2},work:240},
 craft:{name:'제작 체계',text:'작업장 전문화 해금',cost:{wood:24,records:2},work:300},
 care:{name:'회복 지식',text:'의무소·숙소 전문화 해금',cost:{medicine:4,records:2},work:300},
 community:{name:'공동체 운영',text:'식당·배움터 전문화와 공동체 사업 해금',cost:{food:25,records:3},work:360},
 survey:{name:'주변 지리 조사',text:'경계 확장 사업 해금',cost:{wood:30,records:3},work:400},
 archives:{name:'기록 보존법',text:'후속 연구 속도 +20% · 공동 기록 사업 해금',cost:{wood:30,records:4},work:450},
};
export const specializationDefs={
 farm:{research:'agriculture',options:{fields:{name:'집약 경작',text:'식량 생산 +20%'},herbs:{name:'약초 경작',text:'식량 생산 -10%, 농사 중 의약품 확보'}}},
 workshop:{research:'craft',options:{salvage:{name:'잔해 재활용',text:'자재 수집 +25%'},precision:{name:'정밀 작업',text:'공사·장비 제작 작업 +25%'}}},
 clinic:{research:'care',options:{surgery:{name:'회복 병동',text:'거점 치료·부상 회복 +25%'},counsel:{name:'마음 돌봄',text:'거점 치료 중 환자 스트레스도 회복'}}},
 dorm:{research:'care',options:{beds:{name:'여유 잠자리',text:'주민 정원 +2'},quiet:{name:'고요한 숙소',text:'휴식 체력·피로 회복 +25%'}}},
 lounge:{research:'community',options:{hearth:{name:'불 곁의 모임',text:'실제 위로 효과 +20%'},meals:{name:'공동 식사',text:'거점 식량 유지 소비 -15%'}}},
 school:{research:'community',options:{study:{name:'연구 교실',text:'연구 작업 +25%'},apprentice:{name:'도제 교실',text:'거점 분야 경험 획득 +15%'}}},
};
export const projectDefs={
 palisade:{name:'마을의 방호 울타리',text:'자동 방어력 +4 · 시설을 직접 파괴하는 전술 전투는 아닙니다.',research:'craft',facilities:['workshop'],cost:{wood:55,records:2},work:450},
 watchtower:{name:'경계 신호망',text:'자동 방어력 +3',research:'survey',facilities:['school'],cost:{wood:45,records:2},work:400},
 fieldaid:{name:'야영 구호 동선',text:'자동 방어력 +2 · 정면 방어 패배의 추가 부상 방지',research:'care',facilities:['clinic'],cost:{wood:35,medicine:5,records:2},work:400},
 roof:{name:'함께 쓰는 지붕',text:'농사·숙소를 갖춘 마을의 정원 +2',research:'community',facilities:['farm','dorm'],cost:{wood:70,food:35,records:2},work:600},
 boundary:{name:'새 경계의 길',text:'지도 바깥 한 줄 구역의 건설·이동 개방',research:'survey',facilities:['school'],cost:{wood:60,food:25,records:3},work:650},
 archive:{name:'우리의 공동 기록',text:'연구 +15%, 정찰·의지 분야 경험 획득 +15%',research:'archives',facilities:['school','lounge'],cost:{wood:65,records:4},work:700},
};
export function developmentDefaults(){return {research:[],activeResearch:null,projects:[],activeProject:null,specializations:{farm:null,workshop:null,clinic:null,dorm:null,lounge:null,school:null}};}
export function hasSpec(g,kind,option){return g.development?.specializations[kind]===option&&g.facilities[kind]>0;}

export function activeProjectReady(g){const task=g.development?.activeProject;return Boolean(task&&projectDefs[task.key]?.facilities.every(k=>g.facilities[k]>0));}
