// Authored scenes: each choice has a distinct, disclosed resource or relationship consequence.
export const factions={caravan:{name:'길잡이 상단',icon:'➶',text:'보급과 탐사 기록을 나누는 이동 상단.',gear:'bow'},keepers:{name:'불씨 지킴이',icon:'✧',text:'피난처와 기억을 지키는 이웃 공동체.',gear:'charm'},herbalists:{name:'갈대 약초회',icon:'✚',text:'환자와 물길을 돌보는 치료사들.',gear:'salve'}};
const option=(label,cost,gain={},extra={})=>({label,cost,gain,...extra});
const scene=(id,title,text,a,b,faction='keepers')=>({id,title,text,faction,options:[a,b,option('흔적을 기록하고 지나간다',{}, {records:1},{stress:2})]});
export const expeditionScenes=[
 scene('forest-nest','둥지에 걸린 배낭','새끼 늑대 곁에 원정대의 배낭이 걸려 있다.',option('먹이를 두고 배낭만 회수',{food:5},{wood:15},{calm:2}),option('발자국을 추적해 안전한 통로 기록',{}, {records:2},{skill:'scouting'}),'caravan'),
 scene('forest-grove','속삭이는 나무','나무껍질에 서로 다른 방향을 가리키는 표식이 새겨져 있다.',option('줄을 묶어 길을 검증',{wood:5},{records:3},{skill:'scouting'}),option('약초 향을 따라 돌아간다',{}, {medicine:2},{stress:3}),'herbalists'),
 scene('forest-hunter','다친 사냥꾼','덫에 다친 사냥꾼이 동료에게 보낼 소식을 부탁한다.',option('응급 치료와 식량을 나눈다',{medicine:2,food:4},{records:2},{rep:2,skill:'medicine'}),option('동료가 찾을 수 있도록 표식을 남긴다',{wood:3},{wood:9},{rep:1}),'caravan'),
 scene('quarry-lift','멈춘 승강기','승강기 아래 공구 상자가 보이지만 밧줄은 삭아 있다.',option('받침대를 만들어 안전하게 회수',{wood:6},{wood:23},{skill:'construction'}),option('주변 광맥만 조사',{}, {records:2},{stress:3}),'caravan'),
 scene('quarry-bell','지하의 종소리','폐광 아래서 일정한 간격으로 종이 울린다.',option('방향과 시간을 재어 지도에 적는다',{}, {records:3},{stress:6,skill:'will'}),option('돌 틈 약초를 채집하고 돌아선다',{food:3},{medicine:3}),'herbalists'),
 scene('quarry-wall','이름이 새겨진 벽','광부들의 이름과 미완성된 귀환 약속이 벽에 남았다.',option('이름을 옮겨 추모 기록을 만든다',{wood:3},{records:3},{calm:4,rep:1}),option('남겨진 공구만 챙긴다',{}, {wood:15},{stress:4})),
 scene('canal-boat','묶인 나룻배','나룻배에는 젖지 않은 보급 상자와 치료 도구가 실려 있다.',option('밧줄과 도르래로 끌어온다',{wood:5},{medicine:4},{skill:'construction'}),option('뱃사공의 안내장을 챙긴다',{}, {records:2},{rep:1}),'herbalists'),
 scene('canal-filter','녹슨 여과기','여과기를 고치면 근처 사람들이 맑은 물을 쓸 수 있다.',option('여과재를 교체하고 사용법을 남긴다',{wood:8,medicine:1},{records:3},{rep:2}),option('필터 구조만 그려 간다',{}, {records:2},{skill:'education'}),'herbalists'),
 scene('canal-song','갈대 속 노래','길을 잃은 아이의 노랫소리가 물길을 따라 들린다.',option('등불과 먹을 것을 두고 길을 안내한다',{food:6},{medicine:2},{calm:5,rep:2}),option('멀리서 경로를 확인하고 구호 표식 설치',{wood:4},{records:2},{rep:1})),
 scene('shrine-archive','닫힌 기록함','성소의 기록함은 방수천과 약초로 봉해져 있다.',option('봉인을 보존하며 기록을 복원',{medicine:2},{records:4},{skill:'education'}),option('문양만 베껴 간다',{}, {records:2},{stress:2})),
 scene('shrine-echo','돌아오지 않는 메아리','한 주민의 목소리만 메아리로 돌아오지 않는다.',option('함께 이름을 부르며 기다린다',{food:4},{records:2},{calm:8,relation:3}),option('출구를 표시하고 조용히 이동',{}, {wood:12},{stress:4})),
 scene('shrine-flame','꺼져 가는 불씨','작은 제단의 불씨가 바람에 흔들린다.',option('덮개를 만들고 불씨를 나눈다',{wood:8},{records:3},{rep:2}),option('불의 흔들림으로 바람길을 읽는다',{}, {records:2},{skill:'scouting'})),
 scene('marsh-lights','늪의 유도등','늪 위의 작은 불빛은 길이 아니라 깊은 물을 가리킨다.',option('안전한 길에 새 표식을 세운다',{wood:6},{medicine:4},{rep:1}),option('발판을 살펴 약초만 챙긴다',{food:3},{medicine:3},{skill:'scouting'}),'herbalists'),
 scene('marsh-shelter','갈대 치료소','비어 있는 치료소에 약 제조법과 환자 명단이 남았다.',option('처방을 분류해 보존한다',{medicine:1},{records:4},{skill:'medicine'}),option('쓸 수 있는 약만 회수한다',{}, {medicine:4},{stress:4}),'herbalists'),
 scene('marsh-bridge','반쯤 잠긴 다리','다리 건너 약초꾼이 보급 교환을 제안한다.',option('먹을 것을 나누고 약초를 받는다',{food:10},{medicine:5},{rep:2}),option('다리를 보강하고 통행 기록을 받는다',{wood:8},{records:3},{rep:1}),'herbalists'),
 scene('station-clock','멈춘 역 시계','서로 다른 시각을 가리키는 시계 아래 상단의 약속이 적혀 있다.',option('시계를 맞추고 만남의 장소를 남긴다',{wood:6},{records:3},{rep:2}),option('시간표를 베껴 다른 통로를 찾는다',{}, {records:2},{skill:'education'}),'caravan'),
 scene('station-vault','화물칸의 잠금쇠','무거운 잠금쇠 아래 운송 물자가 남아 있다.',option('잠금쇠를 수리해 상자만 연다',{wood:7},{wood:26},{skill:'construction'}),option('운송장을 모아 가져온다',{}, {records:3},{rep:1}),'caravan'),
 scene('station-trader','홀로 기다린 교역상','교역상은 아직 오지 않은 동료를 위해 자리를 지킨다.',option('구호품과 귀환 소식을 전한다',{food:8},{wood:18},{rep:2,calm:3}),option('찾아올 사람을 위해 약속을 기록한다',{}, {records:2},{rep:1}),'caravan'),
 scene('ridge-rope','절벽의 안전줄','안전줄 너머 바람에 흩어지는 문서가 보인다.',option('새 밧줄을 설치해 회수',{wood:8},{records:4},{skill:'construction'}),option('낙하 지점을 살피며 주변 수집',{}, {wood:16},{stress:5})),
 scene('ridge-signal','희미한 신호탑','멀리서 피난처를 찾는 신호가 반복된다.',option('신호판을 고쳐 응답한다',{wood:7},{records:3},{rep:2}),option('다음 탐사를 위해 좌표만 적는다',{}, {records:2},{skill:'scouting'})),
 scene('ridge-wind','바람 속 목소리','능선에서 동료의 목소리를 놓치기 쉽다.',option('손짓을 맞추고 함께 통과한다',{food:5},{records:2},{relation:4,calm:5}),option('낮은 길을 찾아 돌아간다',{}, {wood:12},{stress:3})),
 scene('garden-seeds','봉인된 종자고','정원 깊숙한 곳에 옛 종자와 파종 기록이 남았다.',option('싹을 살려 나눌 몫을 남긴다',{medicine:2},{food:25},{rep:2,skill:'cultivation'}),option('보관 방법을 조사한다',{}, {records:3},{skill:'education'}),'herbalists'),
 scene('garden-statue','정원사의 조각상','조각상 아래 깨진 급수 장치가 작은 꽃밭을 둘러싼다.',option('급수 장치를 복구한다',{wood:9},{records:4},{rep:2}),option('생존한 약초를 채집한다',{food:4},{medicine:4}),'herbalists'),
 scene('garden-night','빛을 머금은 꽃','꽃을 꺾으면 빛이 사라지지만 주변 길은 선명해진다.',option('관찰 기록만 남기고 지킨다',{food:5},{records:4},{calm:5}),option('귀환로에 쓸 꽃 몇 송이만 챙긴다',{}, {medicine:3},{stress:3})),
];
export const townScenes=[
 scene('town-peddler','비를 피한 행상','행상이 마을 앞에서 식량과 자재의 교환을 청한다.',option('비축 식량을 교환한다',{food:12},{wood:18},{rep:1}),option('처마와 따뜻한 식사를 나눈다',{food:5},{records:2},{rep:2}),'caravan'),
 scene('town-letter','배달되지 않은 편지','돌아온 길손이 발신인을 모르는 편지 한 묶음을 내민다.',option('이름을 찾아 기록에 남긴다',{wood:4},{records:3},{rep:1}),option('다음 상단에 전달한다',{food:3},{wood:9},{rep:2})),
 scene('town-well','흐려진 우물','빗물에 우물이 탁해져 약초회가 임시 정화를 권한다.',option('여과통을 만든다',{wood:8},{medicine:3},{rep:1}),option('약으로 물을 정화하고 이웃과 나눈다',{medicine:2},{records:3},{rep:2}),'herbalists'),
 scene('town-stories','모닥불의 옛 지도','길손이 식사를 받으면 오래된 지도를 그려 주겠다고 한다.',option('식사와 종이를 내어 준다',{food:8},{records:3},{skill:'scouting'}),option('이웃의 소식부터 듣는다',{}, {wood:6},{calm:3}),'caravan'),
 scene('town-repair','바람에 흔들린 덮개','생활 공간의 덮개가 흔들려 주민들이 잠을 설쳤다.',option('덮개와 매듭을 보강한다',{wood:10},{},{calm:8,skill:'construction'}),option('서로 잠자리를 바꾸어 돌본다',{food:4},{records:1},{relation:3})),
 scene('town-feast','돌아온 사람의 식탁','원정 이야기를 들으려 주민들이 테이블을 둘러싼다.',option('함께 먹으며 이야기를 나눈다',{food:12},{records:2},{calm:8,relation:3}),option('짧은 귀환 기록을 남긴다',{}, {records:1},{skill:'social'})),
 scene('town-herbs','함께 말리는 약초','약초회가 건조 방법을 가르치는 대신 보관 자재를 부탁한다.',option('건조 선반을 함께 만든다',{wood:10},{medicine:4},{rep:2,skill:'medicine'}),option('가진 약초로 응급 처방을 배운다',{medicine:1},{records:2},{rep:1}),'herbalists'),
 scene('town-watch','새벽의 발자국','마을 바깥에 낯선 발자국이 보인다.',option('식량을 챙겨 주변을 조사한다',{food:6},{records:3},{skill:'scouting'}),option('마을의 표식을 세워 경계를 알린다',{wood:6},{records:1},{calm:5})),
 scene('town-apprentice','배우고 싶은 손','한 주민이 동료에게 다른 일도 배워 보고 싶다고 말한다.',option('연습 도구를 마련한다',{wood:8},{records:2},{skill:'construction',relation:3}),option('오늘 배운 일을 서로 설명한다',{food:4},{records:2},{skill:'education',relation:2})),
 scene('town-cart','바퀴가 부러진 수레','상단 수레가 마을 앞에서 멈췄다.',option('바퀴를 수리해 준다',{wood:12},{food:20},{rep:2,skill:'construction'}),option('짐을 나누어 다음 쉼터를 안내한다',{food:5},{records:2},{rep:1}),'caravan'),
 scene('town-memorial','아무도 모르는 이름','낡은 물건에 지워져 가는 이름이 새겨져 있다.',option('기억을 모아 작은 추모를 준비한다',{food:6},{records:3},{calm:5,rep:1}),option('이름을 덧새겨 다음 사람에게 전한다',{wood:4},{records:2},{rep:1})),
 scene('town-sickbird','다친 전서조','젖은 전서조가 낯선 피난처의 소식을 품고 내려앉았다.',option('치료하고 답장을 보낸다',{medicine:2},{records:3},{rep:2,skill:'medicine'}),option('마른 둥지와 먹이를 준다',{food:5},{records:2},{rep:1}),'herbalists'),
];
export const sceneDefs=Object.fromEntries([...expeditionScenes,...townScenes].map(s=>[s.id,s]));
export const scenePools={숲:expeditionScenes.slice(0,3),채석장:expeditionScenes.slice(3,6),수로:expeditionScenes.slice(6,9),성소:expeditionScenes.slice(9,12),늪:expeditionScenes.slice(12,15),역:expeditionScenes.slice(15,18),능선:expeditionScenes.slice(18,21),정원:expeditionScenes.slice(21,24)};
export const sites={숲:['낡은 사냥길','이끼 공터','뿌리 회랑','옛 숯가마'],채석장:['노천 작업장','폐광 입구','광부 숙소','붕괴 경사로'],수로:['갈대 나루','옛 여과장','배수 회랑','잠긴 수문'],성소:['침묵의 전당','순례자 쉼터','기록 회랑','불씨 제단'],늪:['등불 늪지','갈대 치료소','물안개 둔덕','침목 다리'],역:['화물 승강장','시계 광장','버려진 대합실','신호실'],능선:['신호 능선','바람 쉼터','절벽 잔도','무너진 관측소'],정원:['종자고','유리 온실','급수 정원','밤꽃 회랑']};
const quest=(id,name,faction,goal,target,amount,reward,cost={})=>({id,name,faction,goal,target,amount,reward,cost});
export const questDefs=Object.fromEntries([
 quest('grain','다음 쉼터의 식량','caravan','delivery',null,1,{wood:24,records:1},{food:30}),
 quest('timber','수레 수리용 목재','caravan','delivery',null,1,{food:35,medicine:2},{wood:30}),
 quest('forest','사냥길 답사','caravan','clear','숲',1,{wood:22,records:2}),
 quest('station','옛 역 운송장','caravan','clear','역',1,{food:25,records:3}),
 quest('craft','함께 쓸 제작 지식','caravan','research','craft',1,{wood:25,records:2}),
 quest('workshop','마을 수리 거점','caravan','build','workshop',1,{food:20,medicine:3}),
 quest('blankets','이웃의 겨울 덮개','keepers','delivery',null,1,{medicine:4,records:2},{wood:25,food:10}),
 quest('watch','한 번의 밤을 지키다','keepers','defend',null,1,{wood:28,records:3}),
 quest('ridge','능선의 신호 확인','keepers','clear','능선',1,{wood:22,records:4}),
 quest('community','서로를 위한 운영법','keepers','research','community',1,{food:30,records:2}),
 quest('dorm','돌아올 잠자리','keepers','build','dorm',1,{wood:20,medicine:3}),
 quest('voices','길 위의 세 가지 선택','keepers','choices',null,3,{food:20,records:3}),
 quest('medicine','공동 구호 꾸러미','herbalists','delivery',null,1,{wood:30,records:2},{medicine:6}),
 quest('marsh','습지 약초 길 조사','herbalists','clear','늪',1,{medicine:6,records:2}),
 quest('garden','종자고의 귀환 기록','herbalists','clear','정원',1,{food:30,medicine:4,records:3}),
 quest('care','회복법을 나누는 날','herbalists','research','care',1,{medicine:5,records:2}),
 quest('clinic','이웃을 돌볼 공간','herbalists','build','clinic',1,{wood:20,records:2}),
 quest('canal','물길 점검','herbalists','clear','수로',1,{medicine:4,records:3}),
].map(q=>[q.id,q]));
