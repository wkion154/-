import {amount,outcomeValue} from './outcomes.js';
import {equipment} from './combat.js';
import {icon} from './ui-art.js';
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rowIcon=row=>row.key.startsWith('relation:')?'people':row.key.endsWith(':hp')?'heart':row.key.endsWith(':stress')?'stress':['food','wood','medicine','records'].includes(row.key)?row.key:'flag';
const priority=row=>['food','wood','medicine','records'].includes(row.key)?0:row.key.endsWith(':hp')||row.key.endsWith(':stress')?1:row.key.startsWith('experience:')?9:3;
export function changeGauge(row){
 if(typeof row.before!=='number'||typeof row.after!=='number')return '';
 const domain=row.key.startsWith('ability:')?[0,10]:row.key.startsWith('relation:')?[-100,100]:/:(hp|stress)$/.test(row.key)?[0,100]:null;if(!domain)return '';
 const pct=n=>Math.max(0,Math.min(100,(n-domain[0])/(domain[1]-domain[0])*100));
 return `<span class="change-gauge" role="img" aria-label="${esc(row.label)}: ${amount(row.before)}에서 ${amount(row.after)}로 변화"><i class="gauge-before" style="width:${pct(row.before)}%"></i><i class="gauge-after" style="width:${pct(row.after)}%"></i></span>`;
}
export function changeBadges(rows){return `<span class="change-badges">${[...rows].sort((a,b)=>priority(a)-priority(b)).slice(0,3).map(row=>`<span class="${row.tone}" title="${esc(row.label)}">${icon(rowIcon(row))}<span>${esc(row.label)}<b>${row.delta!==null?(row.delta>0?'+':'')+amount(row.delta):esc(outcomeValue(row,row.after))}</b></span></span>`).join('')}</span>`;}
export function changeList(rows,{compact=false}={}){
 if(!rows?.length)return '<span class="change-empty">수치 변화 없음 · 선택은 생애 기록에 남습니다.</span>';
 const ordered=[...rows].sort((a,b)=>priority(a)-priority(b)),shown=compact?ordered.slice(0,5):ordered;
 const markup=shown.map(row=>{let label=row.label;if(row.key.startsWith('inventory:'))label='보관 · '+(equipment[row.key.slice(10)]?.name||'장비');return `<span class="change-row ${row.tone}"><span>${icon(rowIcon(row))}${esc(label)}</span><span class="change-values"><b>${esc(outcomeValue(row,row.before))}</b><i>→</i><b>${esc(outcomeValue(row,row.after))}</b>${row.delta!==null?`<em>${row.delta>0?'+':''}${amount(row.delta)}</em>`:''}</span>${changeGauge(row)}</span>`;}).join('');
 return `<span class="change-list">${markup}${compact&&rows.length>5?`<span class="more-changes">외 ${rows.length-5}개 변화 · 아래 펼쳐 보기</span>`:''}</span>`;
}
