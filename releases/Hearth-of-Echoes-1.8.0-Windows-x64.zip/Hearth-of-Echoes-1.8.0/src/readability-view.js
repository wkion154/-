import {resourceNames,actionInfo} from './action-info.js';
import {icon} from './ui-art.js';
import {amount} from './outcomes.js';
import {livingFactors} from './work-effects.js';
import {effectiveRole} from './settlement.js';
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function resourcePreview(g,cost={},delta=null){const changes=delta||Object.fromEntries(Object.entries(cost).map(([k,n])=>[k,-n]));return `<div class="resource-preview">${Object.entries(changes).filter(([k,n])=>n&&resourceNames[k]).map(([k,n])=>`<span class="${n>0?'gain':g[k]+n<0?'shortage':'spend'}">${icon(k)}<span>${resourceNames[k]}<b>${amount(g[k])} <i>→</i> ${amount(g[k]+n)}</b></span></span>`).join('')||'<span class="free-action">공동 자원 소모 없음</span>'}</div>`;}
export function decorateActions(root,g,team,target){
 root.querySelectorAll('[data-research],[data-project],[data-specialize],[data-craft],[data-facility],[data-place-kind],[data-action=depart],[data-action=upgrade]').forEach(el=>{
  const info=actionInfo(g,{...el.dataset,target},team);if(!info)return;
  el.disabled=!info.available;el.dataset.help=[info.condition,info.timing,info.reason].filter(Boolean).join(' · ');
  if(el.dataset.action==='upgrade')return;
  if(!el.closest('article')&&!['depart','upgrade'].includes(el.dataset.action))return;
  const box=document.createElement('div');box.className='action-explanation';box.innerHTML=resourcePreview(g,info.cost)+`<small class="action-condition">${esc(info.condition)} · ${esc(info.timing)}</small>`+(info.reason?`<small class="action-reason">${icon('flag')}${esc(info.reason)}</small>`:'');el.before(box);
 });
}
export function efficiencyContents(g,r){
 const role=effectiveRole(r);if(!r.alive||!['농사','건설','휴식','교류'].includes(role))return '';
 const rows=livingFactors(g,r,role),value=rows.reduce((n,[,v])=>n*v,1);
 return `<details class="efficiency-details"><summary>생산·휴식 여건 <b>${Math.round(value*100)}%</b> ⓘ</summary><p>이 공통 계수는 채집 식량·수집 자재·휴식의 스트레스 회복에 적용됩니다. 능력·시설·터전의 개별 효과는 별도로 계산합니다. 건설 작업 속도·치료량·체력 회복률은 이 수치가 아닙니다.</p><div>${rows.map(([name,n])=>`<span>${name}<b>×${n.toFixed(2)}</b></span>`).join('')}</div></details>`;
}
