// Optional learning history; it never changes rewards, time or the random seed.
export const lessonKeys=['build','roles','depart','choice','return','recover'];
export function lessonDefaults(g){
 const returned=g.expeditions>0,trip=g.expedition;
 return {done:lessonKeys.filter(k=>({build:Object.values(g.facilities).some(n=>n>0),roles:g.residents.filter(r=>r.manualRole).length>=2,depart:!!trip||returned,choice:!!trip?.path||returned,return:returned,recover:returned&&!trip&&g.residents.filter(r=>r.alive).every(r=>r.hp>=95&&r.stress<=25&&r.injury<1)})[k]),team:trip?[...trip.team]:[]};
}
export function validLessons(g){const p=g.onboarding;return p&&Array.isArray(p.done)&&p.done.length<=6&&new Set(p.done).size===p.done.length&&p.done.every(k=>lessonKeys.includes(k))&&Array.isArray(p.team)&&p.team.length<=3&&new Set(p.team).size===p.team.length&&p.team.every(id=>Number.isInteger(id)&&id>=0&&id<g.residents.length);}
export function noteLesson(g,key){if(!lessonKeys.includes(key))return;g.onboarding??=lessonDefaults(g);if(!g.onboarding.done.includes(key))g.onboarding.done.push(key);}
export function observeLessons(g){
 g.onboarding??=lessonDefaults(g);const p=g.onboarding;
 if(Object.values(g.facilities).some(n=>n>0))noteLesson(g,'build');
 if(g.residents.filter(r=>r.manualRole).length>=2)noteLesson(g,'roles');
 if(g.expedition){noteLesson(g,'depart');p.team=[...g.expedition.team];}
 if(g.expeditions>0){noteLesson(g,'return');const team=p.team.length?p.team.map(id=>g.residents[id]):g.residents.filter(r=>r.alive);if(!g.expedition&&team.every(r=>r.alive&&r.hp>=95&&r.stress<=25&&r.injury<1))noteLesson(g,'recover');}
}
