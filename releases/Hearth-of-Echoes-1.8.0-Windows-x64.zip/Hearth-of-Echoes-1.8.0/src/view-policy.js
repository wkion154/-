// All incidental closing routes use the same policy. Important decisions have no dismissal.
export function dismissalFor(modal,{mandatory=false}={}){
 if(!modal||mandatory)return null;
 if(modal==='confirm-command')return 'cancel-command';
 if(modal==='founders')return 'cancel-founders';
 if(modal==='founders-map')return 'back-founders';
 if(modal==='import-confirm')return 'cancel-import';
 if(modal==='coach')return 'coach-skip';
 if(modal==='help')return 'begin';
 if(['settings','tutorial','help-center','journal','memorial','family','facilities','armory','construction','building','customize','social','development','frontier','catalog','legacy','reset','map-person','speech','goals','crisis'].includes(modal))return 'close-modal';
 return null;
}
export const lessonPageFor=key=>({roles:2,depart:3,choice:3,return:4,recover:4})[key]??0;
