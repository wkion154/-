import {equipment} from './combat.js';
import {researchDefs,projectDefs,specializationDefs} from './development-data.js';
import {buildingDefs} from './town.js';
import {facilities,facilityCost} from './settlement.js';
import {extraEquipment,extraFacilities} from './expansion-data.js';
import {areaUnlocked} from './areas.js';
import {journeyFrozen} from './journey.js';
export const resourceNames={food:'식량',wood:'자재',medicine:'의약품',records:'기록'};
export function missingResources(g,cost={}){return Object.entries(cost).filter(([k,n])=>g[k]<n).map(([k,n])=>`${resourceNames[k]} ${(n-g[k]).toFixed(1).replace(/\.0$/,'')} 부족`);}
export function expeditionReason(g,id){const r=g.residents[id];if(!r?.alive)return '현역 주민을 선택하세요.';if(r.age<16||r.age>=70||r.retired)return '16~69세 현역 성인이 필요합니다.';return [r.hp<45?'체력 45 이상 필요':null,r.stress>=85?'스트레스 85 미만 필요':null,r.needs.fatigue>=85?'피로 85 미만 필요':null,r.needs.hunger>=85?'배고픔 85 미만 필요':null].filter(Boolean).join(' · ');}
export function actionInfo(g,d,team=[]){
 let cost={},reason='',condition='',timing='확정 후 반영',queued=false,known=true;
 if(d.research){const x=researchDefs[d.research];if(!x)return null;cost=x.cost;condition='배움터 + 배움·가르침 담당';queued=true;timing='담당자가 연구를 완료하면 적용';reason=g.campaign.mode!=='settlement'?'장기 정착으로 먼저 전환하세요.':g.development.research.includes(d.research)?'이미 완료한 연구입니다.':!g.facilities.school?'배움터를 먼저 건설하세요.':x.requires?.some(k=>!g.development.research.includes(k))?'선행 연구: '+x.requires.filter(k=>!g.development.research.includes(k)).map(k=>researchDefs[k].name).join(' · '):g.development.activeResearch?'진행 중인 연구를 완료하거나 중단하세요.':'';}
 else if(d.project){const x=projectDefs[d.project];if(!x)return null;cost=x.cost;condition='일반 공사를 마친 건설 담당';timing='사업 작업을 완료하면 적용';queued=true;reason=g.campaign.mode!=='settlement'?'장기 정착으로 먼저 전환하세요.':g.development.projects.includes(d.project)?'이미 완료한 사업입니다.':g.development.activeProject?'진행 중인 사업을 완료하거나 중단하세요.':!g.development.research.includes(x.research)?researchDefs[x.research].name+' 연구 필요':x.facilities.some(k=>!g.facilities[k])?'필요 시설: '+x.facilities.filter(k=>!g.facilities[k]).map(k=>facilities[k].name).join(' · '):'';}
 else if(d.specialize){const x=specializationDefs[d.specialize];if(!x)return null;cost={wood:12,records:1};condition='선행 연구 + 시설 + 건설 담당';queued=true;timing='전문화 공사를 완료하면 적용';reason=g.campaign.mode!=='settlement'?'장기 정착으로 먼저 전환하세요.':!g.facilities[d.specialize]?facilities[d.specialize].name+' 건설 필요':!g.development.research.includes(x.research)?researchDefs[x.research].name+' 연구 필요':g.development.specializations[d.specialize]===d.option?'현재 적용 중입니다.':g.town.queue.some(q=>q.kind===d.specialize)?'이 시설의 작업이 이미 예약되어 있습니다.':'';}
 else if(d.craft){const x=equipment[d.craft];if(!x?.cost)return null;cost=x.cost;queued=!g.town.legacy||!!extraEquipment[d.craft];condition=queued?'건설 담당 · 완성 후 직접 착용':'완성 후 직접 착용';timing=queued?'제작 완료 → 보관함 → 주민에게 착용':'확정 후 보관함에 지급';reason=queued&&!['shield','kit'].includes(d.craft)&&!g.facilities.workshop?'작업장을 먼저 건설하세요.':'';}
 else if(d.facility){const x=facilities[d.facility],level=g.facilities[d.facility];if(!x)return null;cost=facilityCost(g,d.facility);queued=!g.town.legacy||!!extraFacilities[d.facility];condition=queued?'건설 담당 · 최대 3단계':'최대 3단계';timing=queued?'개선 공사를 완료하면 적용':'확정 후 개선';reason=!level?'지도에 먼저 건설하세요.':level>=3?'최대 단계입니다.':g.town.queue.some(q=>q.kind===d.facility)?'이 시설의 작업이 이미 예약되어 있습니다.':'';}
 else if(d.placeKind){const x=buildingDefs[d.placeKind];if(!x)return null;cost=x.cost;queued=true;condition='지도에서 위치·입구 확인 → 건설 담당';timing='청사진은 무료 · 위치 확정 때 예약';reason=x.research&&!g.development.research.includes(x.research)?researchDefs[x.research].name+' 연구 필요':g.town.buildings.some(b=>b.kind===d.placeKind)?'이미 건설했습니다. 지도에서 선택하세요.':g.town.queue.some(q=>q.kind===d.placeKind&&q.type==='build')?'이미 건설을 예약했습니다.':'';}
 else if(d.action==='upgrade'){cost={wood:25*g.level};condition='피난처 최대 4단계';reason=g.level>=4?'최대 확장 단계입니다.':'';}
 else if(d.action==='depart'){cost={food:2+team.length*2,medicine:Math.min(team.length,Math.floor(g.medicine))};condition='건강한 성인 2~3명 · 잔류자는 거점 운영';timing='확정 후 출정 · 남은 구급약은 귀환 시 반환';reason=g.expedition?'이미 원정 중입니다.':!areaUnlocked(g,d.target||'숲')?'선택한 지역의 개방 조건을 확인하세요.':![2,3].includes(team.length)||new Set(team).size!==team.length?'서로 다른 두 명 또는 세 명을 선택하세요.':team.map(id=>{const reason=expeditionReason(g,id);return reason?g.residents[id]?.name+' · '+reason:'';}).filter(Boolean).join(' / ');}
 else known=false;
 if(!known)return null;
 if(!reason&&(g.event||journeyFrozen(g)||g.gameOver))reason='현재 중요한 선택을 먼저 마쳐 주세요.';
 if(!reason&&g.frontier?.raid.phase==='battle'&&d.action==='depart')reason='마을 방어가 끝난 뒤 출정할 수 있습니다.';
 if(!reason&&queued&&!d.research&&!d.project&&g.town.queue.length>=3)reason='작업 대기열이 가득 찼습니다(3/3).';
 if(!reason)reason=missingResources(g,cost).join(' · ');
 return {cost,reason,condition,timing,queued,available:!reason};
}
