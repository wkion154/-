// A short, wall-clock victory frame. Simulation, loot and save data stay authoritative.
export class BattleDisplay{
 constructor(){this.world=null;this.previous=null;this.fallen=null;this.deaths=new Map();}
 observe(g,now,enabled=true){
  if(this.world!==g){this.world=g;this.previous=null;this.fallen=null;this.deaths.clear();}
  const e=g.expedition,p=this.previous;
  if(enabled&&p?.battle&&((e?.start===p.start&&e.node>p.node)||(!e&&g.expeditions>p.completed&&p.node===4))){
   const snapshot=structuredClone(p);snapshot.battle.enemies.forEach(r=>r.hp=0);snapshot.battle.actions=e?.report?.[0]?.text?.split(' / ')||snapshot.battle.actions;
   this.fallen={expedition:snapshot,started:now,until:now+Math.max(350,650/Math.sqrt(g.speed||1)),key:p.start+':'+p.node};
  }
  if(!enabled)this.fallen=null;
  if(e?.battle){const prefix=e.start+':'+e.battle.node+':';for(const r of e.battle.enemies)if(r.hp===0&&!this.deaths.has(prefix+r.id))this.deaths.set(prefix+r.id,now);}
  this.previous=e?{...structuredClone(e),completed:g.expeditions}:null;
  if(this.deaths.size>64)this.deaths.clear();
 }
 current(now){return this.fallen&&now<this.fallen.until?this.fallen:null;}
 age(e,r,now){return Math.max(0,now-(this.deaths.get(e.start+':'+e.battle.node+':'+r.id)??now));}
}
