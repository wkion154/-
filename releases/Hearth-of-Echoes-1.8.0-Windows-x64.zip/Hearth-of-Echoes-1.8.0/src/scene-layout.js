import {wrapText} from './map-camera.js';
// One defined palette for every starting condition. Canvas ignores undefined fillStyle.
export const groundColors=['#8b9a77','#9a9578','#81998c','#a0a17b','#8b9e86','#9ba27d','#97947f','#87958b','#a39980'];
export const groundColor=world=>groundColors[world]||groundColors[0];
export function nameplateScale(canvasWidth,zoom=1){return 1120/Math.max(1,canvasWidth)*Math.min(1.45,1+Math.max(0,zoom-1)*.25);}
export function bubbleLayout(measure,text,scale=1){
 const maxWidth=Math.min(180*scale,440),font=11*scale,pad=8*scale,lineHeight=16*scale;
 const lines=wrapText(measure,text,maxWidth),pages=[];for(let i=0;i<lines.length;i+=3)pages.push(lines.slice(i,i+3));
 const width=Math.max(72*scale,Math.min(maxWidth,Math.max(...lines.map(measure))))+pad*2;
 return {pages,width,pad,font,lineHeight,height:(Math.min(3,lines.length)*16+16+(pages.length>1?13:0))*scale};
}
