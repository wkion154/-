import {effectiveRole} from './settlement.js';
import {workTarget,findPath} from './town.js';
import {projectDefs} from './development-data.js';
import {activeProjectReady} from './development-data.js';
export function workStatus(g,kind='construction',index=0){
 const research=kind==='research',role=research?'배움':'건설';
 const result=(state,text,workers=[])=>({state,text,role,workers:workers.map(r=>r.id)});
 if(index>0)return result('queued','앞선 작업 완료 후 진행');
 if(research&&!g.facilities.school)return result('blocked','배움터가 없어 연구 대기 중');
 if(kind==='project'&&!activeProjectReady(g)){const d=projectDefs[g.development.activeProject?.key];return result('blocked',d?'사업에 필요한 시설을 다시 마련하세요.':'진행 중인 사업 없음');}
 if(kind==='project'&&g.town.queue.length)return result('queued','일반 공사·제작을 먼저 완료합니다.');
 const home=g.residents.filter(r=>r.alive&&r.age>=(research?6:16)&&!g.expedition?.team.includes(r.id));
 const assigned=home.filter(r=>research?['배움','가르침'].includes(effectiveRole(r)):effectiveRole(r)==='건설');
 const working=assigned.filter(r=>g.frontier?.raid.phase!=='battle'||!g.frontier.raid.participants.includes(r.id));
 if(!working.length){if(assigned.length)return result('blocked','담당 주민이 마을 방어 중입니다.');const resting=home.filter(r=>research?['배움','가르침'].includes(r.job):r.job==='건설');return result('blocked',resting.length?'담당 주민이 회복·교류 중입니다. 상태를 확인하세요.':'거점에 '+(research?'배움·가르침':'건설')+' 담당이 없습니다.');}
 if(g.event||g.crisis.ready)return result('paused','중요한 선택을 마치면 이어집니다.',working);
 const arrived=working.filter(r=>{const p=workTarget(g,r,research?effectiveRole(r):'건설');return r.motion?.arrived&&Math.hypot(r.motion.x-p.x,r.motion.y-p.y)<.05;});
 if(arrived.length)return result(g.speed?'working':'paused',(g.speed?'작업 중 · ':'일시정지 · 재개하면 작업 · ')+arrived.map(r=>r.name).join(', '),arrived);
 const reachable=working.filter(r=>{const p=workTarget(g,r,research?effectiveRole(r):'건설');return !!findPath(g.town,r.motion,p);});
 if(!reachable.length)return result('blocked','작업 장소까지 통로가 없습니다. 입구와 길을 확인하세요.',working);
 return result(g.speed?'moving':'paused',(g.speed?'현장으로 이동 중 · ':'일시정지 · 재개하면 이동 · ')+reachable.map(r=>r.name).join(', '),reachable);
}
