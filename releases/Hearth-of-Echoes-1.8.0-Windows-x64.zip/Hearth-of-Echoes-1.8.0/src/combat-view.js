import {extraEquipment} from './expansion-data.js';
import {areas} from './areas.js';
import {icon} from './ui-art.js';
import {heroFigure,enemyFigure} from './figures.js';
import {combatClasses,equipment,relics,enemies} from './combat.js';
import {away,routeOptions} from './game.js';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const costText=cost=>Object.entries(cost).map(([k,n])=>`${{wood:'자재',medicine:'의약품',records:'기록'}[k]} ${n}`).join(' · ');
export function loadoutPanel(g,r){
  const locked=!r.alive||r.age<16||away(g,r.id)||g.event;
  if(!r.alive||r.age<16)return '<small class="loadout-note">성인이 되면 원정 직업과 장비를 정할 수 있습니다.</small>';
  return `<div class="loadout"><label for="combat-class">원정 직업</label><select id="combat-class" ${locked||r.retired?'disabled':''}>
    ${Object.entries(combatClasses).map(([id,c])=>`<option value="${id}" ${r.combatClass===id?'selected':''}>${c.icon} ${c.name}</option>`).join('')}</select>
    <label for="gear">장비</label><select id="gear" ${locked?'disabled':''}>${Object.entries(equipment).map(([id,item])=>`<option value="${id}" ${r.gear===id?'selected':''} ${id!=='none'&&r.gear!==id&&g.inventory[id]<1?'disabled':''}>${item.name}${id==='none'?'':` · 보관 ${g.inventory[id]}`}</option>`).join('')}</select>
    <small>${esc(combatClasses[r.combatClass].description)}<br>${equipment[r.gear].description}</small></div>`;
}
export function formationView(g,team){
  return `<div class="formation"><small>편성 · 첫 자리는 전방, 나머지는 후방</small>${team.map((id,index)=>{
    const r=g.residents[id],c=combatClasses[r.combatClass];return `<div><span class="formation-icon">${c.icon}</span><span><strong>${index===0?'전방':'후방'} · ${esc(r.name)}</strong><small>${c.name} · ${equipment[r.gear].name}</small></span>${index>0?`<button data-front="${id}" title="전방으로 배치">전방으로</button>`:'<small>선봉</small>'}</div>`;
  }).join('')}</div>`;
}
function heroCard(g,r,index,feedback){
  const c=combatClasses[r.combatClass];return `<div class="combatant hero ${feedback.heroes?.[r.id]<0?'damaged':feedback.heroes?.[r.id]>0?'healed':''}" data-combat-hero="${r.id}">${heroFigure(r)}${feedback.heroes?.[r.id]?`<span class="floating-number ${feedback.heroes[r.id]>0?'positive':''}">${feedback.heroes[r.id]>0?'+':''}${feedback.heroes[r.id]}</span>`:''}<span class="fighter-icon ${r.combatClass}">${c.icon}</span><strong>${esc(r.name)}</strong><small>${index===0?'전방':'후방'} · ${c.name}</small><div class="bar"><i style="width:${r.hp}%"></i></div><small>체력 ${Math.floor(r.hp)} · 마음 ${Math.floor(r.stress)}</small></div>`;
}
function enemyCard(r,feedback,age=0){
  const def=enemies[r.kind];return `<div class="combatant foe ${r.hp===0?'defeated':''} ${feedback.enemies?.[r.id]<0?'damaged':''}" data-combat-enemy="${r.id}" style="--death-age:-${age}ms">${enemyFigure(r.kind)}${feedback.enemies?.[r.id]?`<span class="floating-number">${feedback.enemies[r.id]}</span>`:''}<span class="fighter-icon enemy-${r.kind}">${def.icon}</span><strong>${def.name}</strong><small>${r.hp===0?'격파':r.intent}</small><div class="bar"><i style="width:${r.hp/r.maxHp*100}%"></i></div><small>체력 ${r.hp}/${r.maxHp}${r.marked?' · 약점 표식':''}</small></div>`;
}
export function battlePanel(g,feedback={},fallen=null,display=null){
  const e=fallen?.expedition||g.expedition;if(!e)return '';
  if(e.choice)return `<section class="panel crossroads"><div class="panel-title"><h2>세 갈래 길</h2><small>원정대가 결정을 기다립니다</small></div><p class="description">이동은 잠시 멈추고 거점의 일상은 계속됩니다. 자동 모드에서는 신중은 우회, 강행은 지름길을 택합니다.</p><div class="route-choices">${routeOptions(g).map(o=>`<button data-route="${o.id}" ${o.available?'':'disabled'}><strong>${o.name}</strong><small>${o.text}</small></button>`).join('')}</div></section>`;
  const b=e.battle;
  return `<section class="panel battle-panel ${{숲:'forest',성소:'sanctuary',채석장:'quarry',수로:'waterways',늪:'marsh',역:'station',능선:'ridge',정원:'garden'}[e.target]} ${feedback.freshTurn?'fresh-turn':''} ${fallen?'victory-frame':''}" ${areas[e.target].color?`style="--region-glow:${areas[e.target].color}"`:''}><div class="panel-title"><h2>${fallen?'전투 승리 · 전리품 정리 중':b?`자동 전투 · ${b.node}/5 지점`:'경계 너머의 발걸음'}</h2><small>${b?`${b.turn}턴 · 적의 다음 행동을 확인하세요`:`${e.node}/5 탐사 · 다음 지점으로 이동 중`}</small></div>
    <div class="battle-line"><div class="combatants">${e.team.map((id,i)=>heroCard(g,g.residents[id],i,feedback)).join('')}</div><span class="versus">${b?'⚔':'⋯'}</span><div class="combatants enemies">${b?b.enemies.map(r=>enemyCard(r,feedback,fallen?performance.now()-fallen.started:display?.age(e,r,performance.now())||0)).join(''):'<p class="description">보급품과 낯선 그림자,<br>다음 길이 기다립니다.</p>'}</div></div>
    ${b?.actions.length?`<ol class="turn-log">${b.actions.slice(-6).map(line=>`<li>${esc(line)}</li>`).join('')}</ol>`:'<p class="battle-hint">직업 기술은 자동으로 발동합니다. 원정 중에는 직업·장비·유물을 바꿀 수 없습니다.</p>'}</section>`;
}
export function armoryContents(g){
  return `<small>길을 나서기 전에</small><h2>작업장과 유물</h2><p class="description">장비는 한 개씩 실제로 소유합니다. 새 야영지에서는 제작을 예약하고 건설 담당이 완성합니다. 방패·응급 가방은 야영 설비로, 다른 장비는 작업장을 지어 만듭니다. 완성 후 주민의 장비 칸에서 착용하세요. 벗은 장비는 보관함으로 돌아옵니다.</p>
    <div class="craft-grid">${Object.entries(equipment).filter(([id])=>id!=='none').map(([id,item])=>{
      const can=!g.event&&!g.gameOver&&(g.town.legacy||g.town.queue.length<3)&&(g.town.legacy||['shield','kit'].includes(id)||g.facilities.workshop>0)&&Object.entries(item.cost).every(([k,n])=>g[k]>=n);
      return `<article><div class="craft-art">${extraEquipment[id]?`<span class="item-glyph">${({spear:'↟',hammer:'⚒',crossbow:'➶',mail:'▤',satchel:'✚',incense:'♧',scalpel:'†',sling:'⌁',ward:'▣',boots:'↝',lens:'◇',banner:'⚑'})[id]}</span>`:icon(id==='charm'?'rest':id==='pick'?'build':id==='salve'?'medicine':id)}</div><h3>${item.name}</h3><p>${item.description}</p><small>보관 ${g.inventory[id]} · 제작 대기 ${g.town.queue.filter(q=>q.type==='craft'&&q.item===id).length} · 착용 ${g.residents.filter(r=>r.alive&&r.gear===id).length}</small>${!g.town.legacy&&!(['shield','kit'].includes(id))&&g.facilities.workshop===0?'<small>작업장을 먼저 건설하세요.</small>':''}<button data-craft="${id}" ${can?'':'disabled'}>제작 · ${costText(item.cost)}</button></article>`;
    }).join('')}</div><h3 class="relic-heading">함께 가져갈 유물 · 한 개만 활성화</h3><p class="description">${g.relics.length?'원정 중에는 바꿀 수 없습니다. 활성 유물 하나는 다음 회차에도 이어집니다.':'각 지역을 완주하면 유물을 발견합니다.'}</p>
    <div class="relic-list"><button data-relic="" class="${g.activeRelic===null?'active':''}" ${g.expedition||g.event?'disabled':''}>유물 없이 출발</button>
    ${g.relics.map(id=>`<button data-relic="${id}" class="${g.activeRelic===id?'active':''}" ${g.expedition||g.event?'disabled':''}><strong>${relics[id].icon} ${relics[id].name}</strong><small>${relics[id].description}</small></button>`).join('')}</div>
    <button data-action="close-modal">피난처로 돌아가기</button>`;
}
export function relicLabel(g){return g.activeRelic?relics[g.activeRelic].name:'없음';}
