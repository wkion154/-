import {backgrounds} from './founders.js';
import {needEfficiency,effectiveRole} from './settlement.js';
// These factors are shared by the simulation and the explanatory view.
export function livingFactors(g,r,role=effectiveRole(r)){
 return [
  ['출신',r.background&&backgrounds[r.background]?.role===role?(backgrounds[r.background].factor||1.15):1],
  ['욕구',needEfficiency(r)],['터전·계승',1+(g.level-1)*.2+Math.min(10,g.legacyPoints)*.05],
  ['부상',Math.max(.6,1-r.injury*.04)],['나이',r.age>=70?.65:r.age>=60?.8:1],
  ['어린아이 돌봄',g.residents.some(child=>child.alive&&child.age<6&&child.guardians.includes(r.id))?.85:1],
 ];
}
export const livingFactor=(g,r,role)=>livingFactors(g,r,role).reduce((n,[,v])=>n*v,1);
