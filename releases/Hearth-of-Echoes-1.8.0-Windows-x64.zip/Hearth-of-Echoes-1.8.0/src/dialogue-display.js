// Wall-clock reading time is separate from game seconds and social rewards.
export class DialogueDisplay{
 constructor(){this.world=null;this.seen=0;this.items=[];}
 update(g,now,hold=false){
  if(this.world!==g){this.world=g;this.seen=g.social.serial;this.items=[];const e=g.social.feed[0];if(e&&g.time-e.time<=10)this.add(e,g,now);}
  if(g.social.serial>this.seen){for(const e of [...g.social.feed].reverse().filter(e=>e.id>this.seen))this.add(e,g,now);this.seen=g.social.serial;}
  if(hold){for(const item of this.items){const elapsed=Math.max(0,now-(this.last??now));if(item.starts>(this.last??now))item.starts+=elapsed;item.expires+=elapsed;}}
  this.last=now;this.items=this.items.filter(item=>item.expires>now);return this.items.filter(item=>item.starts<=now).slice(-2);
 }
 add(e,g,now){e.lines.forEach((text,i)=>{const who=i===0?e.who:e.other;if(who===null)return;const starts=now+(i?Math.max(4500,e.lines[0].length/8*1000):0);this.items.push({key:e.id+':'+i,who,text,starts,expires:starts+Math.max(4500,text.length/8*1000)});});this.items=this.items.slice(-6);}
}
