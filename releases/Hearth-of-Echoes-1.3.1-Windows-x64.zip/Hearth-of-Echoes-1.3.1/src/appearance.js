export const appearanceChoices={
 hair:['단정한 짧은 머리','옆으로 넘긴 머리','단발','곱슬머리','묶은 머리','아주 짧은 머리'],
 skin:['#efd2ae','#dfb58d','#c9936b','#aa7657','#82553e','#634331'],
 hairColor:['#39463d','#715344','#a0794e','#332d31','#bead7b','#bfc4b3'],
 coat:['#a4b47b','#be956f','#7daba8','#b6a887','#a18ba9','#8e9bb9','#c19b8d','#8ca174'],
 face:['미소','주근깨','눈썹 짙음','턱수염'],accessory:['없음','둥근 안경','머리띠','귀걸이'],
};
export function defaultAppearance(id=0){return {hair:id%6,skin:id%6,hairColor:id%6,coat:id%8,face:id%4,accessory:0};}
export function validAppearance(a){return !!a&&typeof a==='object'&&Object.keys(a).length===6&&Object.entries(appearanceChoices).every(([key,values])=>Number.isInteger(a[key])&&a[key]>=0&&a[key]<values.length);}
export function appearance(r){return validAppearance(r.appearance)?r.appearance:defaultAppearance(r.id);}
const hairPaths=[
 'M9 30Q6 8 30 8Q56 8 53 31L42 25 39 16Q23 30 9 30Z',
 'M8 31Q4 7 31 6Q58 7 53 32L45 26 43 16Q25 33 8 31Z',
 'M7 48V26Q6 6 30 7Q55 6 55 27V49L45 45 45 25Q30 17 16 26V46Z',
 'M9 31Q0 26 8 18Q3 6 17 9Q22-1 31 7Q44 0 47 12Q61 10 55 23Q60 34 49 33L43 22 18 22Z',
 'M8 30Q6 8 30 8Q50 7 53 27Q65 22 62 41L51 40 46 25 40 17Q25 30 8 30Z',
 'M10 28Q9 10 30 10Q51 10 52 29L46 24Q30 16 15 25Z',
];
export function headShapes(r){
 const a=appearance(r),skin=appearanceChoices.skin[a.skin],hair=appearanceChoices.hairColor[a.hairColor];
 const shapes=[{d:'M25 51H38V64H25Z',fill:skin},{d:'M10 31C10 3 52 3 52 31C52 64 10 64 10 31Z',fill:skin},{d:hairPaths[a.hair],fill:hair},
 {d:'M22 34a1.9 1.9 0 1 0 .1 0M39 34a1.9 1.9 0 1 0 .1 0',fill:'#304138'},
 {d:'M25 46Q31 50 37 45',stroke:'#9b6c56'}];
 if(a.face===1)shapes.push({d:'M16 40h1m3 1h1m21-1h1m-5 1h1',stroke:'#a57052'});
 if(a.face===2)shapes.push({d:'M18 28h9m9 0h9',stroke:hair,width:3});
 if(a.face===3)shapes.push({d:'M14 43Q30 58 49 42Q48 61 31 62Q15 60 14 43Z',fill:hair});
 if(a.accessory===1)shapes.push({d:'M16 34a8 7 0 1 0 16 0a8 7 0 1 0-16 0M33 34a8 7 0 1 0 16 0a8 7 0 1 0-16 0M31 34h3',stroke:'#4e6254',width:2});
 if(a.accessory===2)shapes.push({d:'M9 25Q30 15 53 25',stroke:'#c9b177',width:5});
 if(a.accessory===3)shapes.push({d:'M51 42a3 4 0 1 0 .1 0',stroke:'#dfcf8b',width:2});
 return shapes;
}
export function headSVG(r){return headShapes(r).map(s=>`<path d="${s.d}" fill="${s.fill||'none'}" ${s.stroke?`stroke="${s.stroke}" stroke-width="${s.width||1.5}" stroke-linecap="round"`:''}/>`).join('');}
export function portraitSVG(r){return `<svg class="resident-avatar" viewBox="0 0 64 84" aria-hidden="true"><path d="M6 84V69Q31 51 58 69V84Z" fill="${appearanceChoices.coat[appearance(r).coat]}"/><g>${headSVG(r)}</g><path d="M28 63v21h7V63" fill="#ded2aa" opacity=".6"/></svg>`;}
export function drawHead(c,r){for(const s of headShapes(r)){const path=new Path2D(s.d);if(s.fill){c.fillStyle=s.fill;c.fill(path);}if(s.stroke){c.strokeStyle=s.stroke;c.lineWidth=s.width||1.5;c.lineCap='round';c.stroke(path);}}}
