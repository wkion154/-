import {amount,outcomeValue} from './outcomes.js';
import {equipment} from './combat.js';
import {icon} from './ui-art.js';
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function changeList(rows,{compact=false}={}){
 if(!rows?.length)return '<span class="change-empty">수치 변화 없음 · 선택은 생애 기록에 남습니다.</span>';
 const shown=compact?rows.slice(0,5):rows;
 const markup=shown.map(row=>{let label=row.label;if(row.key.startsWith('inventory:'))label='보관 · '+(equipment[row.key.slice(10)]?.name||'장비');return `<span class="change-row ${row.tone}"><span>${icon(row.key.startsWith('relation:')?'people':row.key.split(':').at(-1)==='hp'?'heart':row.key.split(':').at(-1)==='stress'?'stress':['food','wood','medicine','records'].includes(row.key)?row.key:'flag')}${esc(label)}</span><span><b>${esc(outcomeValue(row,row.before))}</b><i>→</i><b>${esc(outcomeValue(row,row.after))}</b>${row.delta!==null?`<em>(${row.delta>0?'+':''}${amount(row.delta)})</em>`:''}</span></span>`;}).join('');
 return `<span class="change-list">${markup}${compact&&rows.length>5?`<span class="more-changes">외 ${rows.length-5}개 변화 · 아래 펼쳐 보기</span>`:''}</span>`;
}
