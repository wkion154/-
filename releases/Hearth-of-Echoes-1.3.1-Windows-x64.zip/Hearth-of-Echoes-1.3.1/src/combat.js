// Battle rules are deterministic: randomness and relationship lookup are injected.
export const combatClasses={
  guardian:{name:'수호자',icon:'▣',description:'방패 전진으로 아군을 보호합니다. 강한 공격의 예고를 보면 방어를 우선합니다.'},
  scout:{name:'척후병',icon:'⌁',description:'공포를 주는 적부터 노려 약점을 표시합니다. 사수가 표식을 활용할 수 있습니다.'},
  ranger:{name:'사수',icon:'➶',description:'후방에서 공격력이 높아집니다. 표식에 꿰뚫는 화살을 쏴 방어를 무시합니다.'},
  healer:{name:'치유사',icon:'✚',description:'홀수 턴에 체력이 82 미만인 동료를 구급약으로 치료합니다. 약이 없으면 공격합니다.'},
};
export const classOrder=['guardian','scout','healer','ranger'];
export const equipment={
  none:{name:'기본 장비',description:'추가 효과 없음',attack:0,armor:0},
  shield:{name:'철테 방패',description:'받는 피해 -3 · 공격 -2',attack:-2,armor:3,cost:{wood:18}},
  bow:{name:'강화 활',description:'공격 +3 · 받는 피해 +1',attack:3,armor:-1,cost:{wood:22}},
  kit:{name:'응급 가방',description:'치료 +5 · 출혈 방지',heal:5,bleedResist:true,cost:{wood:12,medicine:3}},
  pick:{name:'강철 곡괭이',description:'적 방어 2 무시 · 공격 -1',attack:-1,pierce:2,cost:{wood:20,records:1}},
  salve:{name:'약초 주머니',description:'치료 +2 · 받는 스트레스 -1',heal:2,stress:1,cost:{wood:16,medicine:2}},
  charm:{name:'매듭 부적',description:'받는 스트레스 -2 · 공격 -1',attack:-1,stress:2,cost:{wood:15,records:1}},
};
export const relics={
  lantern:{name:'꺼지지 않는 등불',icon:'◉',description:'원정대가 받는 스트레스 -2. 안개 숲 첫 완주 보상.'},
  oath:{name:'전우의 매듭',icon:'∞',description:'친밀한 동료가 있으면 받는 피해 추가 -2. 숲 지름길 완주 보상.'},
  bastion:{name:'고요한 초석',icon:'▣',description:'수호자의 방패 엄호 +1. 채석장 첫 완주 보상.'},
  spring:{name:'물빛 유리병',icon:'◈',description:'원정마다 첫 응급 처치는 구급약 없이 사용. 수로 첫 완주 보상.'},
  seed:{name:'새벽의 씨앗',icon:'✧',description:'전투 치료 +3 · 야영 회복 +10. 성소 첫 완주 보상.'},
};
export const enemies={
  wolf:{name:'그림자 늑대',icon:'◇',hp:28,attack:8,armor:0,description:'전방을 물어 출혈을 일으킵니다.'},
  stalker:{name:'폐허 추적자',icon:'⟁',hp:34,attack:8,armor:1,description:'후방에서 약한 대상을 노립니다.'},
  howler:{name:'울음의 잔향',icon:'◌',hp:28,attack:3,armor:0,description:'후방의 마음을 흔듭니다. 척후병과 사수로 우선 처치하세요.'},
  brute:{name:'돌가죽 거인',icon:'▰',hp:52,attack:10,armor:3,description:'준비 동작 다음 턴에 전방을 강타합니다.'},
  sentinel:{name:'이끼 갑옷병',icon:'▤',hp:46,attack:7,armor:5,description:'홀수 턴에는 방어를 더 굳힙니다. 표식·관통이 유효합니다.'},
  leech:{name:'수로의 군체',icon:'≈',hp:30,attack:5,armor:0,description:'후방을 공격하고 출혈을 남깁니다.'},
  colossus:{name:'채석장의 파수꾼',icon:'▰',hp:120,attack:14,armor:5,description:'분쇄 예고 뒤 전방 강타와 후방 낙석을 반복합니다.'},
  keeper:{name:'수문의 관리자',icon:'♜',hp:105,attack:11,armor:1,description:'물결 부름으로 회복·공포를 주고 다음 턴 후방을 압박합니다.'},
  warden:{name:'성소의 문지기',icon:'♜',hp:150,attack:16,armor:3,description:'힘 모으기 → 전원 휩쓸기 → 공포의 종소리를 반복합니다.'},
};
export function combatDefaults(id){return {combatClass:classOrder[id%classOrder.length],gear:'none'};}
export function enemyIntent(kind,turn){
  if(kind==='colossus')return turn%2===1?'분쇄 준비':'전방 분쇄';
  if(kind==='keeper')return turn%2===1?'물결 부름':'수압 분사';
  if(kind==='sentinel')return turn%2===1?'갑옷 굳히기':'전방 제압';
  if(kind==='leech')return '후방 출혈';
  if(kind==='warden')return turn%3===1?'힘 모으기':turn%3===2?'전원 휩쓸기':'공포의 종소리';
  if(kind==='brute')return turn%2===1?'강타 준비':'전방 강타';
  return {wolf:'전방 물어뜯기',stalker:'후방 기습',howler:'후방 공포'}[kind];
}
export function makeBattle(kinds,node){
  return {node,turn:1,clock:0,enemies:kinds.map((kind,id)=>({id,kind,hp:enemies[kind].hp,maxHp:enemies[kind].hp,marked:false,intent:enemyIntent(kind,1)})),bleeding:{},actions:[]};
}
export function battleRound(g,e,{random,relationship,risk}){
  const b=e.battle,actions=[],party=e.team.map(id=>g.residents[id]);
  const clamp=(n,lo=0,hi=100)=>Math.max(lo,Math.min(hi,n));
  const live=()=>b.enemies.filter(x=>x.hp>0);
  const hasFriend=r=>party.some(o=>o.id!==r.id&&relationship(g,r.id,o.id)>=15);
  const gear=r=>equipment[r.gear];
  const relic=g.activeRelic;
  const danger=()=>party.some(r=>r.hp<35||r.stress>=85);
  const stress=(r,n)=>{const gain=Math.max(0,n+r.trauma-(gear(r).stress||0)-(relic==='lantern'?2:0)-(hasFriend(r)?1:0));r.stress=clamp(r.stress+gain);return gain;};
  const shields={};
  const hit=(r,power,label,bleed=false)=>{
    const bond=hasFriend(r)?2+(relic==='oath'?2:0):0;
    const damage=Math.max(1,Math.floor(power*risk)-(gear(r).armor||0)-(shields[r.id]||0)-bond);
    r.hp=Math.max(1,r.hp-damage);const fear=stress(r,2);
    if(damage>=13)r.injury++;
    if(bleed&&!gear(r).bleedResist)b.bleeding[r.id]=2;
    actions.push(`${label} → ${r.name} -${damage} 체력, +${fear} 스트레스${bond?' · 동료의 엄호':''}`);
  };
  for(const r of party){
    if((b.bleeding[r.id]||0)>0){r.hp=Math.max(1,r.hp-2);b.bleeding[r.id]--;actions.push(`${r.name} 출혈 -2`);}
  }
  if(danger()){b.actions=actions;return {outcome:'retreat',actions};}
  const order={guardian:0,scout:1,ranger:2,healer:3};
  const actors=[...party].sort((a,c)=>order[a.combatClass]-order[c.combatClass]);
  for(const r of actors){
    if(!live().length)break;
    const kind=r.combatClass,skill=Math.min(14,r.skill),item=gear(r);
    let target=live()[0],power=(kind==='ranger'?10:kind==='healer'?6:7)+skill*.85+(item.attack||0);
    if(r.needs.fatigue>=70)power*=.85;
    let action='공격',pierce=false;
    if(kind==='guardian'){
      const threatened=live().some(x=>['전방 강타','전원 휩쓸기','전방 분쇄','수압 분사'].includes(x.intent));
      if(b.turn%2===1||threatened){
        const block=3+Math.floor(skill/4)+(e.team[0]===r.id?1:0)+(relic==='bastion'?1:0);
        for(const ally of party)shields[ally.id]=(shields[ally.id]||0)+block;
        power*=.65;action='방패 전진';actions.push(`${r.name} 방패 엄호 · 이번 턴 아군 피해 -${block}`);
      }
    }
    if(kind==='scout'){
      target=live().find(x=>['howler','leech'].includes(x.kind))||live()[0];
      if(b.turn%2===1){target.marked=true;action='약점 표식';}
      pierce=true;
    }
    if(kind==='ranger'){
      target=live().find(x=>x.marked)||live().at(-1);
      if(e.team.indexOf(r.id)>0)power+=2;
      if(target.marked){power+=6;target.marked=false;pierce=true;action='꿰뚫는 화살';}
      else action='조준 사격';
    }
    if(kind==='healer'){
      const hurt=[...party].sort((a,c)=>a.hp-c.hp)[0];
      if(hurt.hp<82&&(e.medkits>0||relic==='spring'&&!e.healGiftUsed)&&b.turn%2===1){
        const amount=Math.min(100-hurt.hp,Math.floor(11+skill*1.1+(item.heal||0)+(relic==='seed'?3:0)));
        hurt.hp+=amount;const gift=relic==='spring'&&!e.healGiftUsed;if(gift)e.healGiftUsed=true;else e.medkits--;delete b.bleeding[hurt.id];actions.push(`${r.name} 응급 처치 → ${hurt.name} 체력 +${amount} · ${gift?'유물로 구급약 소모 없음':'구급약 -1'}`);continue;
      }
      action='지팡이 타격';
    }
    const armor=enemies[target.kind].armor+(target.kind==='sentinel'&&b.turn%2===1?2:0);
    const damage=Math.max(1,Math.floor(power)+(Math.floor(random(g)*3)-1)-(pierce?0:Math.max(0,armor-(item.pierce||0))));
    target.hp=Math.max(0,target.hp-damage);actions.push(`${r.name} ${action} → ${enemies[target.kind].name} -${damage}${target.hp===0?' · 격파':''}`);
  }
  for(const enemy of live()){
    const def=enemies[enemy.kind],front=party[0],rear=party.slice(1);
    if(enemy.kind==='brute'&&b.turn%2===1){actions.push('돌가죽 거인이 다음 턴의 강타를 준비합니다.');continue;}
    if(enemy.kind==='colossus'){
      if(b.turn%2===1){actions.push('채석장의 파수꾼이 다음 턴의 분쇄를 예고합니다.');continue;}
      hit(front,def.attack*1.4,'파수꾼 분쇄');hit(rear[0],5,'후방 낙석');
    }else if(enemy.kind==='keeper'){
      if(b.turn%2===1){enemy.hp=Math.min(enemy.maxHp,enemy.hp+5);for(const r of party)stress(r,6);actions.push('물결 부름 · 관리자 체력 +5, 원정대 공포 증가');}
      else for(const r of rear)hit(r,def.attack,'수압 분사');
    }else if(enemy.kind==='leech'){const r=rear[Math.floor(random(g)*rear.length)];hit(r,def.attack,'군체의 습격',true);
    }else if(enemy.kind==='warden'){
      if(b.turn%3===1){actions.push('문지기가 힘을 모읍니다. 다음 턴, 원정대 전원을 공격합니다.');continue;}
      if(b.turn%3===0){for(const r of party){const gain=stress(r,10);actions.push(`공포의 종소리 → ${r.name} 스트레스 +${gain}`);}continue;}
      for(const r of party)hit(r,def.attack,'문지기 휩쓸기');
    }else if(enemy.kind==='howler'){
      const r=[...rear].sort((a,c)=>c.stress-a.stress)[0];hit(r,def.attack,'울음의 잔향');const gain=stress(r,8);actions.push(`${r.name} 공포 +${gain}`);
    }else if(enemy.kind==='stalker'){
      const r=[...rear].sort((a,c)=>a.hp-c.hp)[0];hit(r,def.attack,'후방 기습');
    }else hit(front,def.attack*(enemy.kind==='brute'?1.8:1),def.name,enemy.kind==='wolf');
  }
  b.actions=actions;b.turn++;
  for(const enemy of live())enemy.intent=enemyIntent(enemy.kind,b.turn);
  return {outcome:danger()?'retreat':live().length===0?'victory':b.turn>16?'retreat':'continue',actions};
}
