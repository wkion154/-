// Original synthesized effects and ambient music; no external assets or network calls.
export class Soundscape{
  constructor(){this.context=null;this.master=null;this.preference=null;this.bed=[];this.musicTimer=null;this.note=0;this.revision=0;}
  async configure(preference){
    const revision=++this.revision;this.preference={...preference};
    if(!preference.sound){this.stopBed();if(this.master)this.master.gain.setTargetAtTime(0,this.context.currentTime,.05);return;}
    const Context=globalThis.AudioContext||globalThis.webkitAudioContext;
    if(!Context)return;
    if(!this.context){this.context=new Context();this.master=this.context.createGain();this.master.connect(this.context.destination);}
    try{await this.context.resume();}catch{return;}
    if(revision!==this.revision||!this.preference.sound)return;
    this.master.gain.setTargetAtTime(this.preference.volume,this.context.currentTime,.06);
    this.stopBed();
    if(this.preference.ambience)this.startBed();
    if(this.preference.music){this.musicTimer=setInterval(()=>{
      if(globalThis.document?.hidden||!this.preference.sound)return;
      const melody=[196,246.94,293.66,246.94,220,196,164.81,146.83];this.tone(melody[this.note++%melody.length],1.7,.035,'sine');
    },4200);}
  }
  tone(frequency,duration=.15,level=.09,type='sine',delay=0){
    const ctx=this.context;if(!ctx||!this.preference?.sound||ctx.state!=='running')return;
    const osc=ctx.createOscillator(),gain=ctx.createGain(),at=ctx.currentTime+delay;
    osc.type=type;osc.frequency.setValueAtTime(frequency,at);gain.gain.setValueAtTime(0,at);
    gain.gain.linearRampToValueAtTime(level,at+.018);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
    osc.connect(gain);gain.connect(this.master);osc.start(at);osc.stop(at+duration+.03);osc.onended=()=>{osc.disconnect();gain.disconnect();};
  }
  play(event){
    if(!this.preference?.sound)return;
    const patterns={click:[330],hit:[95,65],heal:[392,523.25],event:[293.66,349.23],depart:[196,246.94,293.66],return:[293.66,246.94],goal:[392,493.88,587.33],victory:[261.63,329.63,392,523.25],farewell:[220,196,164.81]};
    (patterns[event]||[]).forEach((f,i)=>this.tone(f,event==='click' ? .07 : event==='hit' ? .12 : .5,event==='click' ? .025 : .07,event==='hit'?'triangle':'sine',i*.12));
  }
  startBed(){
    const ctx=this.context,buffer=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate),samples=buffer.getChannelData(0);
    let previous=0;for(let i=0;i<samples.length;i++){previous=(previous+(Math.random()*2-1)*.035)/1.025;samples[i]=previous;}
    const source=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),gain=ctx.createGain();
    source.buffer=buffer;source.loop=true;filter.type='lowpass';filter.frequency.value=550;gain.gain.value=.15;
    source.connect(filter);filter.connect(gain);gain.connect(this.master);source.start();this.bed=[source,filter,gain];
  }
  stopBed(){
    if(this.musicTimer)clearInterval(this.musicTimer);this.musicTimer=null;
    if(this.bed[0]){try{this.bed[0].stop();}catch{}}
    for(const node of this.bed)node.disconnect();this.bed=[];
  }
  setVolume(value){if(this.preference)this.preference.volume=value;if(this.master)this.master.gain.setTargetAtTime(this.preference.sound?value:0,this.context.currentTime,.04);}
  async visibility(hidden){if(!this.context)return;try{if(hidden)await this.context.suspend();else if(this.preference?.sound)await this.context.resume();}catch{}}
}
