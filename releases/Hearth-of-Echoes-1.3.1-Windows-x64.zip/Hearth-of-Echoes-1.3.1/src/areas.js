export const areas={
 '숲':{name:'안개 숲',difficulty:'보통',risk:1,rewardRecords:1,rewardMedicine:0,relic:'lantern',description:'첫 탐사에 적합한 숲. 방어·공포·철수의 기본을 배웁니다.'},
 '채석장':{name:'버려진 채석장',difficulty:'단단한 적',risk:1.1,rewardRecords:2,rewardMedicine:0,relic:'bastion',description:'방어력이 높은 적이 지킵니다. 표식·방어 관통을 준비하세요. 자재 보상이 풍부합니다.'},
 '수로':{name:'침수된 수로',difficulty:'출혈·후방 압박',risk:1.05,rewardRecords:2,rewardMedicine:3,relic:'spring',description:'출혈과 수압 공격에 대비하세요. 치료·야영이 유리하며 의약품을 확보합니다.'},
 '성소':{name:'침묵의 성소',difficulty:'보스',risk:1.15,rewardRecords:3,rewardMedicine:0,relic:'seed',description:'문지기의 예고된 광역 공격과 종소리에 대비하는 최종 탐사.'},
};
export function areaUnlocked(g,id){return Object.hasOwn(areas,id)&&(['숲','성소'].includes(id)||g.relics.includes('lantern')||g.cleared||g.legacyPoints>0);}
export function encounterKinds(target,node,path){
 if(node===1)return [{숲:'wolf',채석장:'sentinel',수로:'leech',성소:'stalker'}[target]];
 if(node===5)return [{숲:'brute',채석장:'colossus',수로:'keeper',성소:'warden'}[target]];
 return {숲:[path==='shortcut'?'brute':'stalker','howler'],채석장:[path==='shortcut'?'brute':'sentinel','stalker'],수로:['leech',path==='shortcut'?'howler':'stalker'],성소:['brute','howler']}[target];
}
export const discoveries={
 cache:{name:'버려진 보급품',text:'자재를 확보하고 길을 살폈다.',wood:0},
 tools:{name:'무너진 작업대',text:'남은 공구와 목재를 추려 챙겼다.',wood:9},
 herbs:{name:'돌틈의 약초',text:'치료에 쓸 수 있는 약초를 조심스럽게 모았다.',medicine:2},
 journal:{name:'이전 원정대의 일지',text:'돌아오지 못한 사람들의 길과 경고를 기록했다.',records:1},
 fire:{name:'아직 따뜻한 화덕',text:'다른 생존자가 남긴 불 곁에서 잠시 숨을 돌렸다.',calm:6},
 collapse:{name:'무너져 내린 저장고',text:'위험한 소리에 긴장했지만 더 많은 자재를 건졌다.',wood:14,stress:4},
 trail:{name:'표식이 새겨진 길',text:'척후병이 있으면 흔적을 더 자세히 읽을 수 있다.',records:1,scoutRecords:1},
};
export function discoveryFor(g,e,random){
 if(g.expeditions===0&&['숲','성소'].includes(e.target))return 'cache';
 const pool=e.target==='수로'?['herbs','fire','journal','trail']:e.target==='채석장'?['tools','collapse','journal','trail']:['tools','herbs','journal','fire','collapse','trail'];
 return pool[Math.floor(random(g)*pool.length)];
}
