import {decide,resolveCrisis,eventView} from './game.js';
import {captureOutcome,outcomeChanges} from './outcomes.js';
export function previewChoice(g,index){
 if(!eventView(g)?.options[index]?.available)return null;
 const copy=structuredClone(g),before=captureOutcome(g);if(!decide(copy,index))return null;
 return outcomeChanges(before,captureOutcome(copy));
}
export function previewResolution(g,choice){
 const copy=structuredClone(g),before=captureOutcome(g);if(!resolveCrisis(copy,choice))return null;
 return outcomeChanges(before,captureOutcome(copy));
}
