const paths={
 dice:'<rect x="2" y="2" width="20" height="20" rx="4"/><path d="M7 7h.1M17 7h.1M12 12h.1M7 17h.1M17 17h.1" stroke-width="3"/>',
 food:'<path d="M5 21 18 3M8 17C1 15 3 10 8 13M11 13C4 11 7 6 11 9M14 9C9 5 12 2 15 5M11 15c7 3 9-2 5-3M15 10c7 2 8-3 4-3"/>',
 wood:'<path d="m3 9 10-5 8 5-10 5Z"/><path d="m3 13 8 5 10-5M3 17l8 5 10-5M11 14v8"/>',
 medicine:'<path d="M8 3h8v4l3 4v9H5v-9l3-4Z"/><path d="M9 14h6m-3-3v6M8 7h8"/>',
 records:'<path d="M12 5C8 2 4 3 2 4v15c4-1 7-1 10 1 3-2 6-2 10-1V4c-4-1-7-1-10 1Zm0 0v15M5 8h4M5 12h4M15 8h4M15 12h4"/>',
 town:'<path d="m2 11 10-8 10 8M5 10v11h14V10M10 21v-7h5v7M8 10h1m7 0h1"/>',
 expedition:'<circle cx="12" cy="12" r="10"/><path d="m16 7-2 7-7 3 3-7ZM12 2v2m0 16v2M2 12h2m16 0h2"/>',
 people:'<circle cx="9" cy="7" r="3"/><path d="M2 21v-3a7 7 0 0 1 14 0v3M17 4a3 3 0 0 1 0 6m1 4c3 0 4 2 4 5v2"/>',
 settings:'<path d="M4 5h16M4 12h16M4 19h16"/><rect x="7" y="3" width="4" height="4" rx="1"/><rect x="14" y="10" width="4" height="4" rx="1"/><rect x="7" y="17" width="4" height="4" rx="1"/>',
 heart:'<path d="M12 21S1 14 2 7c1-5 7-5 10-1 3-4 9-4 10 1 1 7-10 14-10 14Z"/><path d="M5 12h4l2-4 2 8 2-4h4"/>',
 stress:'<path d="M8 20H5a4 4 0 0 1-1-8 7 7 0 0 1 13-5 5 5 0 0 1 3 9M13 11l-3 5h5l-3 6"/>',
 rest:'<path d="M20 15A9 9 0 0 1 9 3a9 9 0 1 0 11 12ZM17 3v4m-2-2h4"/>',
 build:'<path d="m3 21 10-10m-3-7 4-2 8 8-3 3-5-5-3 3-3-3Z"/>',
 shield:'<path d="m12 2 9 4v7c-1 5-9 9-9 9S4 18 3 13V6Zm0 4v12M7 10h10"/>',
 leaf:'<path d="M4 21C4 9 9 3 21 3c0 12-5 17-13 14M5 19 17 7M9 15v-5m4 1h5"/>',
 eye:'<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
 pause:'<path d="M8 4v16M16 4v16"/>',
 save:'<path d="M3 3h15l3 3v15H3ZM7 3v6h10V3M7 21v-8h10v8"/>',
 help:'<circle cx="12" cy="12" r="10"/><path d="M9 8a3 3 0 1 1 5 2c-2 1-2 2-2 3m0 3v1"/>',
 family:'<path d="M2 20v-3a5 5 0 0 1 10 0v3M12 20v-3a5 5 0 0 1 10 0v3"/><circle cx="7" cy="6" r="3"/><circle cx="17" cy="6" r="3"/><path d="m10 21 2-5 2 5"/>',
 candle:'<path d="M9 11h6v11H9ZM12 11V8c-5-1-4-5 0-7 1 3 5 5 0 7M5 22h14"/>',
 flag:'<path d="M5 22V3c6-4 9 4 15 0v11c-6 4-9-4-15 0"/>',
 hand:'<path d="M3 14h5l4-4 6 1v3h-6m-4 0 4 4h5l5-4M3 13v7h4v-7"/>',
 chat:'<path d="M3 3h18v13H9l-6 5ZM7 7h10M7 11h7"/>',
 check:'<path d="m4 12 5 5L21 5"/>',
 alert:'<path d="m12 2 11 20H1Zm0 6v6m0 3v1"/>',
 bow:'<path d="M7 2c14 5 14 15 0 20L7 2ZM3 12h19m-4-4 4 4-4 4"/>',
 kit:'<rect x="2" y="6" width="20" height="16" rx="3"/><path d="M8 6V2h8v4M8 14h8m-4-4v8"/>',
};
const aliases={farm:'leaf',workshop:'build',clinic:'medicine',dorm:'rest',lounge:'food',school:'records',guardian:'shield',scout:'expedition',ranger:'bow',healer:'medicine','농사':'leaf','건설':'build','치료':'medicine','휴식':'rest','배움':'records','가르침':'people'};
export function icon(name,extra=''){const key=aliases[name]||name;return `<svg class="ui-icon ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[key]||paths.help}</svg>`;}
const sceneKinds={training:'records',trainingResult:'records',mentor:'records',childhood:'leaf',comingOfAge:'flag',conflict:'build',reconcile:'food',nightmare:'rest',harvest:'food',remembrance:'town',retirement:'rest',farewell:'candle',winter:'rest',blight:'medicine',siege:'shield'};
export function illustration(kind='town'){
 const theme=sceneKinds[kind]||aliases[kind]||kind;
 return `<svg class="scene-illustration" viewBox="0 0 460 170" aria-hidden="true"><rect width="460" height="170" rx="14" fill="#202f2b"/><circle cx="337" cy="47" r="31" fill="#b6c996" opacity=".12"/><path d="M0 139Q100 94 212 130T460 112V170H0Z" fill="#344b3c"/><path d="m338 120 34-45 40 45Z" fill="#798971"/><path d="m343 120 29-35v35Z" fill="#b0ad86"/><path d="M24 145h410" stroke="#9aaf7d" opacity=".3"/><g transform="translate(30 17)"><path d="M35 123 39 82Q59 71 80 82l8 41Z" fill="#92a57c"/><circle cx="60" cy="55" r="20" fill="#d5b18a"/><path d="M40 53q-1-30 23-24 21 1 18 25l-11-13Z" fill="#6f5746"/><path d="m51 124-3 17m23-17 4 17" stroke="#455b4a" stroke-width="9"/><path d="m42 91-9 16m45-16 12 14" stroke="#92a57c" stroke-width="10" stroke-linecap="round"/><circle cx="54" cy="55" r="2" fill="#3b493d"/><circle cx="68" cy="55" r="2" fill="#3b493d"/></g><g transform="translate(350 50) scale(.67)"><path d="M35 123 39 82Q59 71 80 82l8 41Z" fill="#8ca8a0"/><circle cx="60" cy="55" r="20" fill="#d5b18a"/><path d="M40 52q0-28 22-23 21 0 19 25l-14-10Z" fill="#435451"/><circle cx="54" cy="55" r="2" fill="#3b493d"/><circle cx="68" cy="55" r="2" fill="#3b493d"/></g><circle cx="234" cy="82" r="53" fill="#182923" stroke="#889b6e" stroke-width="1.5"/><g transform="translate(204 52) scale(2.5)" fill="none" stroke="#c5d3a8" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">${paths[theme]||paths.town}</g><path d="M129 91h29m150 0h24M143 83v16m174-16v16" stroke="#9ab47c" opacity=".55"/></svg>`;
}
