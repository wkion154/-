export const defaultPreferences={sound:false,ambience:true,music:true,volume:.25,motion:true,weather:true,labels:true,contrast:false,guide:true,menuHints:true,bubbles:true};
export function readPreferences(raw,reducedMotion=false){
  const fallback={...defaultPreferences,motion:!reducedMotion};
  try{const value=JSON.parse(raw);if(!value||typeof value!=='object')return fallback;
    for(const key of ['sound','ambience','music','motion','weather','labels','contrast','guide','menuHints','bubbles'])if(typeof value[key]==='boolean')fallback[key]=value[key];
    if(Number.isFinite(value.volume))fallback.volume=Math.max(0,Math.min(1,value.volume));
  }catch{}
  return fallback;
}
export function capturePresentation(g){
  const e=g.expedition,b=e?.battle;
  return {cycle:g.cycle,time:g.time,trip:e?`${g.cycle}:${e.start}`:null,
    fight:b?`${g.cycle}:${e.start}:${b.node}`:null,turn:b?.turn??0,
    heroes:Object.fromEntries(g.residents.map(r=>[r.id,r.hp])),
    enemies:Object.fromEntries((b?.enemies||[]).map(r=>[r.id,r.hp])),
    goals:g.residents.reduce((n,r)=>n+r.completedGoals.length,0),
    event:g.event?`${g.event.kind}:${g.event.who}`:null,ending:g.ending?.kind??null,success:g.ending?.success??false,
    expeditions:g.expeditions};
}
export function presentationChanges(before,after){
  const result={heroes:{},enemies:{},sounds:[],freshTurn:false};if(!before||before.cycle!==after.cycle)return result;
  if(before.trip===after.trip&&after.trip){
    for(const [id,hp] of Object.entries(after.heroes)){const delta=hp-before.heroes[id];if(Number.isFinite(delta)&&Math.abs(delta)>=1)result.heroes[id]=Math.round(delta);}
  }
  if(before.fight===after.fight&&after.fight){
    result.freshTurn=after.turn!==before.turn;
    for(const [id,hp] of Object.entries(after.enemies)){const delta=hp-before.enemies[id];if(Number.isFinite(delta)&&delta!==0)result.enemies[id]=Math.round(delta);}
    if(result.freshTurn){result.sounds.push('hit');if(Object.values(result.heroes).some(n=>n>0))result.sounds.push('heal');}
  }
  if(after.trip&&!before.trip)result.sounds.push('depart');
  if(before.trip&&!after.trip&&after.expeditions>before.expeditions)result.sounds.push('return');
  if(after.goals>before.goals)result.sounds.push('goal');
  if(after.event&&after.event!==before.event)result.sounds.push('event');
  if(after.ending&&after.ending!==before.ending)result.sounds.push(after.success?'victory':'farewell');
  return result;
}
export function tutorialSteps(g){
  if(!g.town.legacy)return [
   {title:'첫 밭이나 작업대를 놓아 보기',text:'마을 → 건설·길에서 시설을 고르고 지도에서 위치·입구를 확인해 예약하세요. 건설 담당이 현장으로 이동해 완성합니다.',done:Object.values(g.facilities).some(v=>v>0),action:'construction',label:'건설·길 열기'},
   {title:'두 명 또는 세 명을 안개 숲에 보내기',text:'2인 수호자·치유사는 거점에 둘을 남길 수 있습니다. 3인은 전투 조합이 넓어집니다. 첫 갈림길은 안전한 우회로를 권합니다.',done:g.relics.includes('lantern')||g.cleared,action:'expedition',label:'원정 편성 보기'},
   {title:'돌아온 사람과 장비 돌보기',text:'자율 행동이 켜진 귀환자는 쉬었다가 본래 업무로 돌아갑니다. 방패·응급 가방을 제작 예약하고 완성 후 착용하세요.',done:g.expeditions>0&&g.residents.some(r=>r.gear!=='none'),action:'resident',label:'주민 상태 보기'},
   {title:'다가오는 계절 준비하기',text:'위기 대비에 실제 물자를 투입해 점수를 올립니다. 가족과 교육은 생활에 여유가 생기면 시작해도 됩니다.',done:Object.values(g.crisis.preparations).some(v=>v>0)||!!g.ending,action:'crisis',label:'위기 대비 보기'},
  ];
  const alive=g.residents.filter(r=>r.alive),worked=alive.some(r=>r.job==='농사')&&alive.some(r=>r.job==='치료');
  return [
    {title:'오늘의 일을 나누기',text:'농사로 식량을, 치료로 귀환자의 회복을 준비하세요. 주민을 누르면 생활 초점을 바꿀 수 있습니다.',done:worked,action:'resident',label:'주민 살펴보기'},
    {title:'안개 숲에 다녀오기',text:'성인 세 명을 편성하세요. 전방에는 수호자, 후방에는 지원 역할을 권합니다. 지점마다 전투와 갈림길이 이어집니다.',done:g.relics.includes('lantern')||g.cleared,action:'expedition',label:'원정 준비 보기'},
    {title:'터전과 사람을 돌보기',text:'시설 하나를 개선하거나 개인 목표를 이뤄 보세요. 지친 주민은 자율적으로 쉬었다가 돌아옵니다.',done:Object.values(g.facilities).some(n=>n>1)||alive.some(r=>r.completedGoals.length),action:'facilities',label:'시설 살펴보기'},
    {title:'다가올 계절 준비하기',text:'위기 대비에 물자를 투입하세요. 대응 점수와 최종 선택의 결과는 결정 전에 확인할 수 있습니다.',done:Object.values(g.crisis.preparations).some(n=>n>0)||Boolean(g.ending),action:'crisis',label:'위기 대비 보기'},
  ];
}
