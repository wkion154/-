// Choices are data shared by the rules and UI, so displayed costs match effects.
export const eventTypes = {
  training: {
    title: r => `${r.name}의 작은 바람`,
    text: r => `“살아남는 것 말고도, 잘하는 일을 하나쯤 갖고 싶어요.” ${r.name}가 새로운 기술을 배울 시간을 요청했다.`,
    options: [
      {label:'배움을 지원한다', cost:{wood:12}, skill:1, stress:-12, memory:'공동체의 지원으로 새로운 기술을 배웠다.'},
      {label:'지금은 일손이 필요하다', food:10, stress:8, memory:'자신의 꿈을 미루고 식량 확보를 도왔다.'},
      {label:'스스로 결정할 시간을 준다', stress:-5, bond:1, memory:'결정을 존중받으며 앞으로의 삶을 생각했다.'},
    ],
  },
  conflict: {
    title: (r,o) => `${r.name}와 ${o.name}, 다른 생각`,
    text: (r,o) => `남은 도구를 두고 ${r.name}와 ${o.name}의 말다툼이 길어졌다. 부족한 것은 도구일까, 서로를 이해할 시간일까.`,
    options: [
      {label:'도구를 더 만들어 나눈다',cost:{wood:10},relation:10,stress:-4,memory:'새 도구를 나누고 동료와 오해를 풀었다.'},
      {label:'함께 앉아 이야기를 듣는다',cost:{food:5},relation:15,stress:-8,memory:'식탁에서 동료의 사정을 이해하게 되었다.'},
      {label:'각자 해결하도록 둔다',relation:-12,stress:6,memory:'도구를 둘러싼 다툼을 해결하지 못했다.'},
    ],
  },
  nightmare: {
    title: r => `${r.name}가 잠들지 못하는 밤`,
    text: r => `귀환한 ${r.name}는 작은 소리에도 몸을 움츠린다. 원정에서 본 그림자가 꿈에 나타난다고 한다. 동료가 문 앞에서 기다리고 있다.`,
    options: [
      {label:'치료와 휴식을 보장한다',cost:{medicine:2},stress:-22,trauma:-1,rest:true,memory:'원정의 악몽을 털어놓고 치료를 받았다.'},
      {label:'동료와 함께 밤을 보낸다',cost:{food:4},relation:14,stress:-14,memory:'곁을 지킨 동료 덕에 긴 밤을 견뎠다.'},
      {label:'다음 임무에 집중시킨다',stress:10,skill:1,memory:'악몽을 안은 채 훈련에 매달렸다.'},
    ],
  },
  harvest: {
    title: () => '공동 식탁의 저녁',
    text: () => '오늘 수확은 평소보다 좋았다. 한 주민이 모두 함께 따뜻한 식사를 하자고 제안한다. 다가올 원정을 위해 남겨둘 수도 있다.',
    options: [
      {label:'모두 함께 식사한다',cost:{food:12},allStress:-10,relation:12,memory:'넉넉한 저녁을 동료들과 나누었다.'},
      {label:'보급품으로 가공한다',food:8,stress:3,memory:'즐거움을 미루고 다음 원정을 준비했다.'},
      {label:'지친 두 사람에게 나누어 준다',cost:{food:5},stress:-12,relation:8,memory:'자신을 챙겨 준 공동체에 고마움을 느꼈다.'},
    ],
  },
  mentor: {
    title: (r,o) => `${o.name}에게 가르쳐 줄 것`,
    text: (r,o) => `${o.name}가 ${r.name}의 일을 유심히 지켜본다. 배움을 나누면 당장의 생산은 줄겠지만, 한 사람에게만 기대지 않아도 될 것이다.`,
    options: [
      {label:'정식으로 기술을 전수한다',cost:{wood:15},otherSkill:1,relation:15,stress:4,memory:'동료에게 자신의 기술을 전수했다.'},
      {label:'쉬는 시간에 조금씩 알려 준다',otherSkill:1,stress:12,relation:6,memory:'쉴 시간을 줄여 동료에게 일을 가르쳤다.'},
      {label:'지금은 각자의 일을 맡긴다',stress:-3,memory:'가르침을 다음으로 미루고 자신의 일에 집중했다.'},
    ],
  },
  remembrance: {
    title: r => `${r.name}가 기억하는 집`,
    text: r => `${r.name}는 떠나온 고향 이야기를 처음 꺼냈다. 돌아갈 수 있을지는 모르지만, 이곳에도 기억할 자리를 만들고 싶다고 한다.`,
    options: [
      {label:'작은 기념물을 함께 세운다',cost:{wood:14},stress:-15,relation:12,memory:'고향을 기억하는 작은 기념물을 세웠다.'},
      {label:'그 이야기를 기록으로 남긴다',stress:-7,relation:7,memory:'동료에게 자신의 고향 이야기를 들려주었다.'},
      {label:'조용히 혼자 있을 시간을 준다',stress:-10,rest:true,memory:'혼자 쉬면서 떠나온 집을 기억했다.'},
    ],
  },
};
export const worldConditions = [
  {name:'버드나무 터',description:'비옥한 땅 · 식량 생산 +10%',food:1.1,wood:1,risk:1},
  {name:'붉은 솔 고개',description:'오래된 벌목지 · 자재 생산 +20%',food:1,wood:1.2,risk:1.05},
  {name:'안개 여울',description:'깊은 안개 · 원정 피해 +10%, 휴식 회복 +20%',food:1,wood:1,risk:1.1,rest:1.2},
];

Object.assign(eventTypes, {
  childhood: {
    title:r=>`${r.name}가 바라보는 세상`,
    text:r=>`여섯 살이 된 ${r.name}. 무엇이든 만져 보고, 질문하고, 따라 해 보는 시간이 시작됐다. 어떤 경험을 함께 나눌까?`,
    options:[
      {label:'함께 세상을 관찰한다',trait:'호기심',job:'배움',stress:-5,memory:'궁금한 것을 묻고 관찰하며 배우기 시작했다.'},
      {label:'다른 사람을 돌보는 모습을 보여 준다',trait:'다정함',job:'배움',relation:8,memory:'서로를 돌보는 공동체에서 배움을 시작했다.'},
      {label:'작은 도전을 끝까지 해 보게 한다',trait:'끈기',job:'배움',skill:1,memory:'작은 도전을 끝내며 자신감을 얻었다.'},
    ],
  },
  comingOfAge: {
    title:r=>`${r.name}, 자신의 길을 고를 때`,
    text:r=>`${r.name}가 열여섯 살이 되었다. 이제 공동체의 한 사람으로 일을 맡고 원정에도 참여할 수 있다. 어린 시절의 배움은 숙련과 관계로 남는다.`,
    options:[
      {label:'사람들을 먹이는 일을 택한다',job:'농사',skill:1,memory:'성인이 되어 식량을 돌보는 길을 택했다.'},
      {label:'새로운 보금자리를 만드는 일을 택한다',job:'건설',skill:1,memory:'성인이 되어 공동체를 짓는 길을 택했다.'},
      {label:'다친 사람을 돌보는 일을 택한다',job:'치료',skill:1,memory:'성인이 되어 사람을 치료하는 길을 택했다.'},
    ],
  },
  retirement: {
    title:r=>`${r.name}의 다음 계절`,
    text:r=>`예순이 된 ${r.name}는 지난날을 돌아본다. 손길은 느려졌지만 쌓인 경험은 누구보다 깊다. 앞으로 어떤 삶을 살고 싶을까?`,
    options:[
      {label:'은퇴하고 다음 세대를 가르친다',retire:'teach',stress:-15,memory:'현역에서 은퇴하고 다음 세대의 스승이 되었다.'},
      {label:'충분히 쉬며 가족과 시간을 보낸다',retire:'rest',stress:-25,memory:'현역에서 은퇴하고 자신과 가족을 위한 시간을 택했다.'},
      {label:'당분간 하던 일을 계속한다',retire:'continue',stress:8,memory:'조금 더 현역으로 남기로 했다. 일흔에는 은퇴하게 된다.'},
    ],
  },
  farewell: {
    title:r=>`${r.name}와 함께하는 마지막 불빛`,
    text:r=>`${r.name}, ${r.age}세. 노환으로 삶의 끝을 앞두고 있다. 함께한 사람과 배움, 살아온 순간들을 기억한다. 배웅을 선택하면 이 주민은 세상을 떠나고 생애가 추모 기록에 남는다. 남겨진 자녀의 스트레스는 20, 친한 동료는 12, 다른 주민은 4 오른다.`,
    options:[
      {label:'작은 추모 자리를 마련해 배웅한다',cost:{wood:8},allStress:-5,farewell:true,memory:'동료들의 작은 추모 속에서 마지막 인사를 나누었다.'},
      {label:'함께했던 이야기를 나누며 배웅한다',allStress:-2,farewell:true,memory:'함께했던 이야기를 들으며 마지막 인사를 나누었다.'},
      {label:'곁을 지키며 조용히 배웅한다',farewell:true,memory:'곁을 지키는 사람들과 조용히 마지막 인사를 나누었다.'},
    ],
  },
});

Object.assign(eventTypes,{
  reconcile:{
    title:(r,o)=>`${r.name}와 ${o.name}, 다시 마주 앉다`,
    text:(r,o)=>`도구를 둘러싼 다툼 뒤로 ${r.name}와 ${o.name}의 말수가 줄었다. 그때 남겨 둔 감정을 풀 기회가 왔다.`,
    options:[
      {label:'따뜻한 식사를 함께 나눈다',cost:{food:4},relation:18,stress:-6,memory:'미뤄 둔 갈등을 식탁에서 풀고 서로의 사정을 들었다.'},
      {label:'함께 작은 일을 마무리한다',relation:10,stress:3,memory:'함께 일을 마치며 다툼 뒤의 어색함을 조금 덜었다.'},
      {label:'더 이상 간섭하지 않는다',relation:-8,stress:6,memory:'풀지 못한 갈등이 서먹함으로 남았다.'},
    ],
  },
  trainingResult:{
    title:r=>`${r.name}가 배워 온 것`,
    text:r=>`공동체가 배움을 지원했던 ${r.name}가 작은 결과물을 가져왔다. 이 배움을 어디에 남기면 좋을까?`,
    options:[
      {label:'동료에게도 배움을 나눈다',cost:{food:4},otherSkill:1,relation:8,memory:'지원받아 배운 기술을 동료에게도 나누었다.'},
      {label:'혼자 더 깊이 연습한다',skill:1,stress:8,memory:'배운 기술을 더 깊이 연습하며 자신의 길을 다졌다.'},
      {label:'다음 세대를 위한 기록으로 남긴다',records:1,stress:-4,memory:'배움의 결과를 공동체의 기록으로 남겼다.'},
    ],
  },
});
