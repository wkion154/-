import {socialDefaults,advanceSocial,recordDebrief,validateSocial,rememberFact} from './social.js';
import {defaultAppearance,validAppearance} from './appearance.js';
import {generateFounder,validFounder,backgrounds} from './founders.js';
import {createTown,validateTown,advanceTown,townCapacity,queueUpgrade,queueCraft,spawnResidents} from './town.js';
import {captureOutcome,outcomeChanges,outcomeLine} from './outcomes.js';
import {areas,areaUnlocked,encounterKinds,discoveries,discoveryFor} from './areas.js';
import {crisisTypes,preparationTypes,endingTypes,createCrisis,journeyFrozen,crisisReadiness,canConfront,eligibleHeirs,endingSnapshot,advanceCrisis,validateJourney} from './journey.js';
import {facilities,goalTypes,facilityDefaults,settlementDefaults,facilityCost,effectiveRole,needEfficiency,updateNeeds,recordGoal,updateGoals,makeGoal,readyStory,validateSettlement} from './settlement.js';
import {eventTypes, worldConditions} from './content.js';
import {combatDefaults,combatClasses,equipment,relics,enemies,makeBattle,battleRound,enemyIntent} from './combat.js';
export const roles = ['농사', '건설', '치료', '휴식', '배움', '가르침'];
// Historical export for pre-1.3 saves; use g.yearSeconds for live simulation.
export const YEAR_SECONDS = 120;
export const names = ['유나', '도윤', '미루', '하람', '서린', '노아'];
const origins = ['국경의 작은 마을에서 약초를 배우며 자랐다.', '무너진 북부 성벽에서 가족과 헤어졌다.', '떠돌이 상단에서 장부와 도구를 배웠다.', '굶주린 겨울, 낯선 이의 도움으로 살아남았다.', '벌목꾼의 집에서 숲의 길을 익혔다.', '오래된 역에서 아이들을 돌보며 지냈다.'];
const clamp = (n, low=0, high=100) => Math.max(low, Math.min(high, n));
export function createGame(seed=8192,{founders=null,established=false}={}) {
  const variation=seed===8192?0:seed>>>0;
  if(founders&&(!Array.isArray(founders)||founders.length!==4||!founders.every(validFounder)))throw new Error('개척단은 유효한 주민 네 명이어야 합니다.');
  const roster=established?names.map((name,i)=>({name,age:18+i*4+variation%7,skill:2+(i+variation)%3,trait:['다정함','용감함','호기심','신중함','끈기','낙천적'][(i+variation)%6],appearance:defaultAppearance(i)})):founders||Array.from({length:4},(_,i)=>generateFounder(seed,i));
  const g={
    version:9,yearSeconds:established?120:600,time:0,speed:1,autoEvents:false,seed:seed>>>0,food:established?45:60,wood:established?30:44,medicine:established?8:10,
    records:0,level:1,cleared:false,expedition:null,event:null,eventCount:0,lastEvent:0,lastSave:Date.now(),cycle:1,legacy:[],legacyPoints:0,
    world:variation%3,relationships:{},pendingEvent:null,expeditions:0,lifeQueue:[],gameOver:false,totalBirths:0,
    inventory:Object.fromEntries(Object.keys(equipment).filter(k=>k!=='none').map(k=>[k,0])),relics:[],activeRelic:null,
    facilities:established?facilityDefaults():Object.fromEntries(Object.keys(facilityDefaults()).map(k=>[k,0])),storyQueue:[],routineCount:0,crisis:createCrisis(variation%3),ending:null,operatingPolicy:'balanced',
    residents:roster.map((r,i)=>({id:i,...structuredClone(r),job:established?roles[i%4]:['농사','건설','치료','농사'][i],hp:100,stress:8+i*3,injury:0,trauma:0,
      ...lifeDefaults(r.age,i),...combatDefaults(i),...settlementDefaults(i,r.skill),bond:0,lastChildAt:-(established?120:600),history:[r.background?backgrounds[r.background].name+' · '+backgrounds[r.background].text:origins[(i+variation)%6]]})),
    log:[{time:0,text:established?'여섯 사람이 폐허에 불을 밝혔다. 우리의 이야기가 시작된다.':'네 사람이 텐트와 모닥불 곁에 모였다. 우리의 손으로 마을을 짓는다.',kind:'story'}],
  };
  g.town=createTown(established,g.facilities);spawnResidents(g);g.social=socialDefaults(g);for(const r of g.residents)r.memories=[];return g;
}

export function random(g) {g.seed=(Math.imul(g.seed,1664525)+1013904223)>>>0;return g.seed/4294967296;}
export function log(g,text,kind='normal') {g.log.unshift({time:g.time,text,kind});g.log=g.log.slice(0,100);}
export function day(g) {return Math.floor(g.time/60)+1;}
export function away(g,id) {return Boolean(g.expedition?.team.includes(id));}
export function world(g) {return worldConditions[g.world];}
function memory(g,r,text) {
  r.history.unshift(`${day(g)}일: ${text}`);
  if(r.history.length>60)r.history=[...r.history.slice(0,59),r.history.at(-1)];
}
const pairKey = (a,b) => [a,b].sort((a,b)=>a-b).join(':');
export function relationship(g,a,b) {return a===b?0:(g.relationships[pairKey(a,b)]||0);}
export function changeRelationship(g,a,b,amount) {
  if(a===b||!g.residents[a]||!g.residents[b]) return;
  g.relationships[pairKey(a,b)]=clamp(relationship(g,a,b)+amount,-100,100);
  for(const id of [a,b]) g.residents[id].bond=Object.entries(g.relationships)
    .filter(([key])=>key.split(':').map(Number).includes(id)).reduce((sum,[,v])=>sum+Math.max(0,v),0);
}
export function relationshipLabel(value) {
  return value>=35?'깊은 신뢰':value>=15?'친밀':value<=-15?'갈등':value<0?'서먹함':'알아가는 사이';
}
export function connections(g,id) {
  return g.residents.filter(r=>r.id!==id).map(r=>({id:r.id,name:r.name,
    alive:r.alive,value:relationship(g,id,r.id),label:relationshipLabel(relationship(g,id,r.id))}))
    .sort((a,b)=>Math.abs(b.value)-Math.abs(a.value));
}
export function depart(g,team,policy='신중',target='숲') {
  if(journeyFrozen(g)||g.event||g.expedition||!['신중','강행'].includes(policy)||!areaUnlocked(g,target)
    ||!Array.isArray(team)||![2,3].includes(team.length)||new Set(team).size!==team.length||team.some(id=>!Number.isInteger(id))
    ||team.some(id=>!canExpedition(g,id))||g.food<2+team.length*2) return false;
  g.food-=2+team.length*2;
  const medkits=Math.min(team.length,Math.floor(g.medicine));g.medicine-=medkits;
  g.expedition={team:[...team],policy,target,progress:0,node:0,loot:0,report:[],start:g.time,
    engine:'tactical',wait:0,battle:null,choice:null,path:null,supplies:3,medkits,lootMedicine:0,bonusRecords:0,discovery:null,healGiftUsed:false};
  log(g,`${team.map(id=>g.residents[id].name).join(', ')} · ${areas[target].name}으로 출발했다.`,'expedition');
  return true;
}
export function retreat(g,reason='철수 명령') {
  const e=g.expedition;if(!e)return;
  g.wood+=Math.floor(e.loot);g.medicine+=e.medkits+e.lootMedicine;g.records+=e.bonusRecords;g.expeditions++;
  for(const id of e.team){
    const r=g.residents[id];r.motion={x:14,y:9,path:[],target:'14,9',revision:g.town.revision,arrived:true,prevX:14,prevY:9};memory(g,r,`${e.target} 원정에서 돌아왔다. ${reason}.`);
    if(e.node>0)for(const other of e.team.filter(x=>x>id)) changeRelationship(g,id,other,5);
  }
  const shaken=e.team.map(id=>g.residents[id]).find(r=>r.stress>=45||r.injury>=2);
  if(shaken){shaken.trauma=Math.min(3,shaken.trauma+1);g.pendingEvent={kind:'nightmare',who:shaken.id,other:e.team.find(id=>id!==shaken.id)};memory(g,shaken,'원정의 그림자가 잠든 뒤에도 따라왔다.');}
  recordDebrief(g,e,reason);
  log(g,`${reason}. 원정대 귀환 · 자재 +${Math.floor(e.loot)}${e.lootMedicine?` · 의약품 +${e.lootMedicine}`:''}${e.bonusRecords?` · 기록 +${e.bonusRecords}`:''}`,'expedition');g.expedition=null;
}
export function upgrade(g) {
  const cost=25*g.level;if(journeyFrozen(g)||g.event||g.wood<cost||g.level>=4)return false;
  g.wood-=cost;g.level++;log(g,`피난처가 ${g.level}단계로 확장되었다. 생산과 휴식 효율이 높아졌다.`,'story');return true;
}
export function eventView(g) {
  if(!g.event)return null;
  const def=eventTypes[g.event.kind||'training'],r=g.residents[g.event.who],o=eventOther(g,r);
  return {title:def.title(r,o),text:def.text(r,o),options:def.options.map(option=>{
    const parts=[];
    for(const [key,cost] of Object.entries(option.cost||{})) parts.push(`${{food:'식량',wood:'자재',medicine:'의약품'}[key]} -${cost}`);
    for(const [key,label] of Object.entries({food:'식량',skill:'숙련',stress:'스트레스',records:'기록',relation:'상호 관계',otherSkill:`${o.name} 숙련`,allStress:'모두의 스트레스',trauma:'후유증',bond:'유대'}))
      if(option[key])parts.push(`${label} ${option[key]>0?'+':''}${option[key]}`);
    if(option.rest)parts.push('생활 초점 → 휴식');
    if(option.job)parts.push(`생활 초점 → ${option.job}`);
    if(option.trait)parts.push(`기질 → ${option.trait}`);
    if(option.retire)parts.push(option.retire==='continue'?'현역 유지':'은퇴 · '+(option.retire==='teach'?'가르침':'휴식'));
    if(option.farewell)parts.push('자연사 · 추모 기록 보존');
    return {...option,effects:parts.join(' · '),available:Object.entries(option.cost||{}).every(([key,n])=>g[key]>=n)&&!(option.retire==='continue'&&r.age>=70)};
  })};
}
export function decide(g,choice) {
  if(g.ending&&!g.crisis.sandbox)return false;
  const view=eventView(g),option=view?.options[choice];if(!option||!option.available)return false;
  const before=captureOutcome(g);
  const r=g.residents[g.event.who],o=eventOther(g,r);
  for(const [key,n] of Object.entries(option.cost||{}))g[key]-=n;
  g.food+=option.food||0;g.records+=option.records||0;r.skill+=option.skill||0;r.stress=clamp(r.stress+(option.stress||0));
  if(option.otherSkill)o.skill+=option.otherSkill;
  if(option.allStress)living(g).forEach(p=>p.stress=clamp(p.stress+option.allStress));
  if(option.relation||option.bond)changeRelationship(g,r.id,o.id,option.relation||option.bond);
  if(option.trauma)r.trauma=clamp(r.trauma+option.trauma,0,3);
  if(option.rest){r.job='휴식';r.routine='assigned';}
  if(option.job){r.job=option.job;r.routine='assigned';}
  if(option.trait)r.trait=option.trait;
  if(option.retire&&option.retire!=='continue'){r.retired=true;r.job=option.retire==='teach'?'가르침':'휴식';}
  memory(g,r,option.memory);if(option.relation||option.otherSkill)memory(g,o,`${r.name}와 함께한 일: ${option.memory}`);
  log(g,`${view.title} · ${option.label}. ${option.effects}`,'story');
  if(g.event.kind==='conflict'&&choice===2)scheduleStory(g,'reconcile',r.id,o.id,60);
  if(g.event.kind==='training'&&choice===0)scheduleStory(g,'trainingResult',r.id,o.id,90);
  if(option.farewell)completeLife(g,r);
  updateGoals(g,{relationship,memory,log});
  g.event=null;g.lastEvent=g.time;
  const changes=outcomeChanges(before,captureOutcome(g));if(changes.length)log(g,'선택 결과 · '+changes.map(outcomeLine).join(' · '),'story');
  return true;
}
function automaticChoice(g) {
  const order={reconcile:[0,1,2],trainingResult:[0,2,1],childhood:[0,1,2],comingOfAge:[0,1,2],retirement:[0,1,2],training:[0,2,1],conflict:[1,0,2],nightmare:[0,1,2],
    harvest:g.food>=30?[0,2,1]:[1,2,0],mentor:g.wood>=30?[0,2,1]:[2,0,1],remembrance:[1,2,0]};
  const view=eventView(g);
  const choice=(order[g.event.kind||'training']||[2,1,0]).find(i=>view.options[i].available);
  return decide(g,choice);
}
function nextEvent(g,home) {
  home=home.filter(r=>r.alive&&r.age>=16);
  if(home.length<2)return;
  if(g.pendingEvent){g.event=g.pendingEvent;g.pendingEvent=null;}
  else if(readyStory(g)){g.event=readyStory(g);g.storyQueue=g.storyQueue.filter(e=>e!==g.event);}
  else {
    const kinds=['training','conflict','harvest','mentor','remembrance'];
    const kind=kinds[g.routineCount%kinds.length];
    const who=kind==='mentor'?[...home].sort((a,b)=>b.skill-a.skill)[0].id:home[g.routineCount%home.length].id;
    const other=home.find(r=>r.id!==who).id;
    g.event={kind,who,other};g.routineCount++;
  }
  g.eventCount++;log(g,'한 주민이 당신과 이야기하고 싶어 한다.','story');
}
export function routeOptions(g) {
  const e=g.expedition;if(!e?.choice)return [];
  return [
    {id:'safe',name:'안전한 우회로',text:'남은 전투 피해 -20% · 기본 보상',available:true},
    {id:'shortcut',name:'위험한 지름길',text:'남은 전투 피해 +25% · 이후 전리품 +50% · 정예 적 등장 · 숲 완주 시 유물',available:true},
    {id:'camp',name:'야영 후 출발',text:`보급 2 소모 · 전원 체력 +${g.activeRelic==='seed'?25:15} · 스트레스 -12`,available:e.supplies>=2},
  ];
}
export function chooseRoute(g,path) {
  const e=g.expedition,option=routeOptions(g).find(o=>o.id===path);
  if(!e||!option?.available)return false;
  e.path=path;e.choice=null;
  if(path==='camp'){
    e.supplies-=2;
    for(const id of e.team){const r=g.residents[id];r.hp=Math.min(100,r.hp+(g.activeRelic==='seed'?25:15));r.stress=Math.max(0,r.stress-12);memory(g,r,'폐허의 야영지에서 동료들과 숨을 돌렸다.');}
  }
  expeditionReport(g,e,3,option.name,option.text);finishNode(g,e,option.name,0);return true;
}
function expeditionReport(g,e,node,title,text) {
  e.report.unshift({node,title,text});e.report=e.report.slice(0,24);
  log(g,`원정 ${node}/5 · ${title}. ${text}`,'expedition');
}
function finishNode(g,e,title,loot) {
  const bonus=(e.policy==='강행'?1.5:1)*(e.path==='shortcut'?1.5:1);
  e.loot+=Math.floor(loot*bonus);e.node++;e.wait=0;e.battle=null;
  if(e.node<5)return;
  const target=e.target,path=e.path;
  for(const id of e.team)recordGoal(g,id,'explore',1);
  const area=areas[target];e.lootMedicine+=area.rewardMedicine;
  retreat(g,'탐사 완료');g.records+=area.rewardRecords;
  const found=[area.relic,...(target==='숲'&&path==='shortcut'?['oath']:[])];
  for(const id of found)if(!g.relics.includes(id)){
    g.relics.push(id);if(g.activeRelic===null)g.activeRelic=id;
    log(g,`유물 발견 · ${relics[id].name}. ${relics[id].description}`,'story');
  }
  if(target==='성소'&&!g.cleared){g.cleared=true;log(g,'성소의 문지기가 쓰러지고 종이 다시 울렸다. 다음 세대와 피난처에 불씨를 이어갈 수 있다.','story');}
}
function expeditionStep(g) {
  const e=g.expedition;if(!e)return;e.progress++;
  if(e.choice){if(g.autoEvents)chooseRoute(g,e.policy==='강행'?'shortcut':'safe');return;}
  if(e.battle){
    e.battle.clock++;if(e.battle.clock<2)return;e.battle.clock=0;
    const risk=areas[e.target].risk*(e.policy==='강행'?1.3:1)*(e.path==='safe'?.8:e.path==='shortcut'?1.25:1)*world(g).risk;
    const turn=e.battle.turn;const result=battleRound(g,e,{random,relationship,risk});
    expeditionReport(g,e,e.node+1,`${turn}턴 전투`,result.actions.join(' / '));
    if(result.outcome==='retreat'){retreat(g,'위험 감지 · 자동 철수');return;}
    if(result.outcome==='victory')finishNode(g,e,'전투 승리',10+Math.floor(random(g)*7));
    return;
  }
  e.wait++;if(e.wait<4)return;e.wait=0;
  const node=e.node+1;
  if(node===2){
    const id=discoveryFor(g,e,random),discovery=discoveries[id];e.discovery=id;
    e.lootMedicine+=discovery.medicine||0;e.bonusRecords+=(discovery.records||0)+(discovery.scoutRecords&&e.team.some(id=>g.residents[id].combatClass==='scout')?discovery.scoutRecords:0);
    for(const id of e.team){const r=g.residents[id];r.stress=clamp(r.stress+(discovery.stress||0)-(discovery.calm||0));if(e.discovery!=='cache')memory(g,r,`${areas[e.target].name}에서 ${discovery.name}를 발견했다.`);}
    expeditionReport(g,e,node,discovery.name,discovery.text);finishNode(g,e,discovery.name,12+(discovery.wood||0)+(e.target==='채석장'?8:0));
    if(e.team.some(id=>g.residents[id].stress>=85))retreat(g,'위험 감지 · 자동 철수');return;}
  if(node===3){e.choice={kind:'crossroads'};expeditionReport(g,e,node,'세 갈래 길','우회·강행·야영 중 다음 길을 정하세요.');return;}
  const kinds=encounterKinds(e.target,node,e.path);
  e.battle=makeBattle(kinds,node);
  expeditionReport(g,e,node,'적과 조우',kinds.map(k=>`${enemies[k].name}: ${enemies[k].description}`).join(' / '));
}
export function tick(g,seconds=1) {
  if(!Number.isInteger(seconds)||seconds<0||seconds>86400)throw new RangeError('시간 범위 오류');
  for(let t=0;t<seconds;t++){
    if(journeyFrozen(g))break;
    if(g.event){if(needsDecision(g))break;automaticChoice(g);}
    g.time++;advanceAges(g);const home=living(g).filter(r=>!away(g,r.id));
    const upkeep=home.reduce((sum,r)=>sum+(r.age<16 ? .009 : .018),0),fed=g.food>=upkeep;
    g.food=Math.max(0,g.food-upkeep);updateNeeds(g,home,fed,{relationship,changeRelationship,log});
    advanceTown(g,home,{log,recordGoal});
    for(const r of home){
      const role=effectiveRole(r);
      if(!g.town.legacy&&!r.motion?.arrived)continue;
      const aptitude=r.background&&({farmer:'농사',carpenter:'건설',herbalist:'치료',keeper:'휴식'}[r.background]===role)?1.15:1;
      const f=aptitude*needEfficiency(r)*(1+(g.level-1)*.2+Math.min(10,g.legacyPoints)*.05)*Math.max(.6,1-r.injury*.04)*(r.age>=70 ? .65 : r.age>=60 ? .8 : 1)
        *(living(g).some(child=>child.age<6&&child.guardians.includes(r.id)) ? .85 : 1);
      if(role==='배움')learn(g,r,home);
      if(role==='농사')g.food+=.09*r.skill*f*world(g).food*(g.facilities.farm?1+(g.facilities.farm-1)*.25:.65);
      if(role==='건설'&&!r.townWorking)g.wood+=.045*r.skill*f*world(g).wood*(g.facilities.workshop?1+(g.facilities.workshop-1)*.2:.8);
      if(role==='치료'){
        if(g.time%12===0)g.medicine+=.15*r.skill*aptitude;
        const hurt=[...home].sort((a,b)=>a.hp-b.hp).find(x=>(g.town.legacy||x.motion?.arrived)&&(x.hp<100||x.injury>0));
        if(hurt&&g.medicine>=.025){g.medicine-=.025;const before=hurt.hp,bonus=g.facilities.clinic?1+(g.facilities.clinic-1)*.25:.65;hurt.hp=Math.min(100,hurt.hp+.45*r.skill*bonus*aptitude);hurt.injury=Math.max(0,hurt.injury-.015*bonus*aptitude);if(hurt.id!==r.id)recordGoal(g,r.id,'care',hurt.hp-before);}
      }
      if(role==='휴식'||role==='교류'){
        const friend=home.some(o=>o.id!==r.id&&['휴식','교류'].includes(effectiveRole(o))&&relationship(g,r.id,o.id)>=15);
        r.stress=clamp(r.stress-.13*f*(g.town.legacy?1:g.facilities.dorm?1:.8)*(world(g).rest||1)*(friend?1.5:1)*(1+Math.max(0,g.facilities.lounge-1)*.15));r.hp=Math.min(100,r.hp+(g.town.legacy ? .08 : g.facilities.dorm ? .12 : .08));
        if(r.stress<15&&g.time%60===0&&r.trauma>0){r.trauma--;memory(g,r,'평온한 휴식 속에서 원정의 악몽이 조금 옅어졌다.');}
      }else r.stress=clamp(r.stress+.012+r.trauma*.004);
      if(g.food===0){r.stress=clamp(r.stress+.12);r.hp=Math.max(25,r.hp-.025);}
    }
    advanceSocial(g,{relationship,changeRelationship,log,memory});
    if(g.town.legacy&&g.time%60===0&&home.length>=2){const a=home[Math.floor(random(g)*home.length)],others=home.filter(x=>x!==a),b=others[Math.floor(random(g)*others.length)];
      changeRelationship(g,a.id,b.id,3);log(g,`${a.name}와 ${b.name}가 식탁에서 이야기를 나눴다. 관계 +3.`,'story');}
    expeditionStep(g);
    if(!g.event&&g.lifeQueue.length){g.event=g.lifeQueue.shift();g.eventCount++;}
    updateGoals(g,{relationship,memory,log});
    if(!g.event&&!g.expedition&&((g.pendingEvent&&g.time-g.lastEvent>=20)||readyStory(g)||g.time-g.lastEvent>=110))nextEvent(g,living(g).filter(r=>!away(g,r.id)));
    advanceCrisis(g,{log,retreat});
  }
  return g;
}
export function journeySummary(g) {
  return {cycle:g.cycle,place:world(g).name,days:day(g),expeditions:g.expeditions,
    outcome:g.ending?.kind??null,crisis:g.crisis.kind,score:g.ending?.score??crisisReadiness(g).score,endingAt:g.ending?.at??null,
    stories:g.residents.map(r=>({name:r.name,skill:r.skill,age:r.age,alive:r.alive,generation:r.generation,history:r.history.slice(0,3)}))};
}
export function nextJourney(g,heirId=null,{founders=null}={}) {
  if((!g.cleared&&!g.ending)||g.expedition||g.event||g.crisis.ready)return null;
  const candidates=eligibleHeirs(g);
  if(candidates.length&&!candidates.some(r=>r.id===heirId))return null;
  if(!candidates.length&&!g.ending)return null;
  const outcome=g.ending?.kind??'pilgrimage',won=endingTypes[outcome].success;
  const next=createGame((g.seed+104729)>>>0,{founders}),heir=candidates.length?structuredClone(g.residents[heirId]):null;
  next.autoEvents=g.autoEvents;next.cycle=g.cycle+1;next.legacyPoints=g.legacyPoints+(won?1:0);
  next.legacy=[...g.legacy,{...journeySummary(g),outcome}].slice(-10);next.world=(g.world+1)%worldConditions.length;
  next.crisis=createCrisis(next.world);
  if(heir){
    heir.familyNames=[...new Set([...heir.familyNames,...heir.guardians.map(id=>g.residents[id].name)])];
    if(g.activeRelic){next.relics=[g.activeRelic];next.activeRelic=g.activeRelic;}
    heir.guardians=[];heir.mentorId=null;heir.lastChildAt=-next.yearSeconds;
    heir.needs={hunger:12,fatigue:10,loneliness:12};heir.routine='assigned';
    delete heir.motion;delete heir.workRole;delete heir.townWorking;delete heir.workLabel;
    heir.memories=(heir.memories||[]).map(m=>({...m,time:0,other:null,kind:'legacy'}));heir.ageProgress=Math.floor(heir.ageProgress/g.yearSeconds*next.yearSeconds);
    heir.id=0;heir.hp=100;heir.stress=10;heir.injury=0;heir.trauma=0;heir.bond=0;
    heir.history.unshift(`${g.cycle}번째 피난처의 기억과 「${endingTypes[outcome].title}」의 결말을 품고 새 공동체에 합류했다.`);
    next.residents[0]=heir;
  }
  const newcomers=['이솔','재이','가온','온유','다온','솔비'];
  next.residents.forEach((r,i)=>{if(i===0&&heir||founders)return;r.name=newcomers[(i+next.cycle)%newcomers.length];if(r.name===heir?.name)r.name+='빛';});
  spawnResidents(next);
  if(outcome==='beacon')next.records+=2;
  if(outcome==='shelter')next.food+=15;
  next.log=[{time:0,text:`${heir?heir.name+'가':'남겨진 기록으로'} ${world(next).name}에 불씨를 옮겼다. 이전 결말: ${endingTypes[outcome].title}. 계승 ${next.legacyPoints} · 생산 +${Math.min(10,next.legacyPoints)*5}%.`,kind:'story'}];
  return next;
}
export function serialize(g) {return JSON.stringify({...g,lastSave:Date.now()});}

function lifeDefaults(age,id) {
  return {alive:true,ageProgress:0,lifespan:Math.max(age+4,78+(id%7)*2),retired:false,
    guardians:[],familyNames:[],generation:1,education:0,mentorId:null,lastChildAt:-YEAR_SECONDS,
    childhoodNoted:age>=6,adultNoted:age>=16,retirementNoted:false,farewellNoted:false,deathDay:null};
}
export function living(g) {return g.residents.filter(r=>r.alive);}
export function capacity(g) {return townCapacity(g);}
export function lifeStage(r) {
  return !r.alive?'기억 속의 사람':r.age<6?'유아':r.age<16?'성장기':r.retired?'은퇴':r.age>=60?'노년':'성인';
}
export function availableRoles(g,r) {
  return !r?.alive?[]:r.age<6?['휴식']:r.age<16?['배움','휴식']:r.retired?['가르침','휴식']:roles;
}
export function setJob(g,id,job) {
  const r=g.residents[id];if(journeyFrozen(g)||g.event||away(g,id)||!availableRoles(g,r).includes(job))return false;
  r.job=job;r.routine='assigned';r.workRole=job;r.workLabel=job;r.manualRole=true;return true;
}
export function canExpedition(g,id) {
  const r=g.residents[id];return Boolean(r?.alive&&r.age>=16&&r.age<70&&!r.retired&&r.hp>=45&&r.stress<85&&r.needs.fatigue<85&&r.needs.hunger<85);
}
export function needsDecision(g) {return Boolean(g.event&&(!g.autoEvents||g.event.kind==='farewell'||g.crisis?.ready));}
function eventOther(g,r) {
  const o=g.residents[g.event.other];return o?.alive?o:(living(g).find(o=>o.id!==r.id)||r);
}
export function familyLinks(g,id) {
  const r=g.residents[id];return {guardians:r.guardians.map(id=>g.residents[id]),
    children:g.residents.filter(child=>child.guardians.includes(id)),
    mentor:g.residents[r.mentorId]||null,previous:r.familyNames};
}
export function familyReadiness(g,ids,mode='adoption') {
  const cost=mode==='birth'?{food:20,medicine:4}:{food:15,wood:8};
  const fail=reason=>({allowed:false,reason,cost});
  if(!['birth','adoption'].includes(mode))return fail('가족을 맞이하는 방식을 선택하세요.');
  if(g.gameOver||g.event)return fail('진행 중인 이야기를 먼저 마쳐 주세요.');
  if(living(g).length>=capacity(g))return fail('숙소가 가득 찼습니다. 피난처를 확장하세요.');
  if(g.residents.length>=256)return fail('이번 여정의 기록이 가득 찼습니다. 다음 피난처로 계승해 주세요.');
  if(!Array.isArray(ids)||ids.some(id=>!Number.isInteger(id))||new Set(ids).size!==ids.length||ids.length<1||ids.length>2||mode==='birth'&&ids.length!==2)
    return fail(mode==='birth'?'보호자 두 명을 선택하세요.':'보호자 한 명 또는 두 명을 선택하세요.');
  const guardians=ids.map(id=>g.residents[id]);
  if(guardians.some(r=>!r?.alive||r.age<18||r.age>(mode==='birth'?55:69)||away(g,r.id)))return fail('보호자는 거점에 있는 성인이어야 합니다. 출생은 55세 이하, 입양은 69세 이하입니다.');
  if(guardians.some(r=>g.time-r.lastChildAt<g.yearSeconds))return fail('가족이 적응할 시간을 주세요. 같은 보호자는 생애 1년 뒤 다시 맞이할 수 있습니다.');
  if(mode==='birth'&&relationship(g,ids[0],ids[1])<35)return fail('새 생명은 깊은 신뢰 관계(35 이상)의 보호자 둘이 함께 준비합니다.');
  if(Object.entries(cost).some(([key,n])=>g[key]<n))return fail('맞이할 식량·의약품·자재가 부족합니다.');
  return {allowed:true,reason:mode==='birth'?'0세 아이가 태어나며 보호자의 돌봄이 필요합니다.':'8세 아이를 가족으로 맞이합니다.',cost};
}
export function welcomeChild(g,ids,mode='adoption') {
  const readiness=familyReadiness(g,ids,mode);if(!readiness.allowed)return null;
  for(const [key,n] of Object.entries(readiness.cost))g[key]-=n;
  const id=g.residents.length,age=mode==='birth'?0:8;
  const pool=['새봄','아람','해온','솔','여울','나린','이든','보리','시우','하늬'];
  let name=pool[g.totalBirths%pool.length];if(g.residents.some(r=>r.name===name))name+=`·${g.totalBirths+1}`;
  const child={id,name,age,job:age<6?'휴식':'배움',hp:100,stress:4,skill:1,injury:0,trauma:0,
    trait:['호기심','다정함','끈기'][Math.floor(random(g)*3)],appearance:defaultAppearance(id),bond:0,...lifeDefaults(age,id),...combatDefaults(id),...settlementDefaults(id,1),
    guardians:[...ids],generation:Math.max(...ids.map(id=>g.residents[id].generation))+1,
    history:[mode==='birth'?'이 피난처에서 작은 울음소리와 함께 태어났다.':'먼 길 끝에 새로운 가족과 피난처를 만났다.']};
  child.lastChildAt=-g.yearSeconds;child.memories=[];g.residents.push(child);g.totalBirths++;
  for(const guardian of ids){g.residents[guardian].lastChildAt=g.time;changeRelationship(g,id,guardian,25);memory(g,g.residents[guardian],`${name}의 보호자가 되었다.`);}
  log(g,`${name}, ${age}세 · ${ids.map(id=>g.residents[id].name).join('와 ')}의 가족이 되었다. ${child.generation}세대의 이야기가 시작된다.`,'story');
  updateGoals(g,{relationship,memory,log});return child;
}
export function assignMentor(g,childId,mentorId) {
  const child=g.residents[childId],mentor=g.residents[mentorId];
  if(journeyFrozen(g)||g.event||!child?.alive||child.age<6||away(g,childId))return false;
  if(mentorId===null){child.mentorId=null;return true;}
  if(!mentor?.alive||mentor.age<16||mentor.id===child.id||mentor.skill<2)return false;
  child.mentorId=mentor.id;memory(g,child,`${mentor.name}에게 배우기로 했다. 가르침에 전념할 때 배움이 빨라진다.`);return true;
}
export function retireResident(g,id) {
  const r=g.residents[id];if(journeyFrozen(g)||g.event||!r?.alive||r.age<55||r.retired||away(g,id))return false;
  r.retired=true;r.job='가르침';r.retirementNoted=true;
  g.lifeQueue=g.lifeQueue.filter(e=>!(e.kind==='retirement'&&e.who===id));
  memory(g,r,'현역에서 은퇴하고 다음 세대를 가르치기로 했다.');log(g,`${r.name}가 은퇴했다. 이제 경험을 나누는 삶이 시작된다.`,'story');return true;
}
function learn(g,r,home) {
  if(r.age<6||!r.alive)return;
  let mentor=home.find(o=>o.id===r.mentorId&&o.id!==r.id&&effectiveRole(o)==='가르침'&&o.skill>=2);
  if(r.mentorId===null){mentor=home.filter(o=>o.id!==r.id&&effectiveRole(o)==='가르침'&&o.skill>=2).sort((a,b)=>b.skill-a.skill)[0];if(mentor)r.mentorId=mentor.id;}
  const care=r.guardians.some(id=>home.some(o=>o.id===id)) ? .0005 : 0;
  r.education+=(.002+care+(mentor ? .002 : 0))*(1+(g.facilities.school-1)*.2)*(r.trait==='호기심'?1.15:r.trait==='끈기'?1.08:1);
  if(r.education>=1){r.education-=1;r.skill++;memory(g,r,`${mentor?mentor.name+'에게 배우며':'꾸준히 공부하며'} 숙련 ${r.skill}에 도달했다.`);log(g,`${r.name}의 배움이 자랐다. 숙련 ${r.skill}.`,'story');if(mentor)changeRelationship(g,r.id,mentor.id,4);}
}
function advanceAges(g) {
  for(const r of living(g)){
    r.ageProgress++;if(r.ageProgress<g.yearSeconds)continue;
    r.ageProgress-=g.yearSeconds;r.age++;
    for(const id of r.guardians)if(g.residents[id]?.alive)changeRelationship(g,r.id,id,3);
    if(r.age>=6&&!r.childhoodNoted){r.childhoodNoted=true;r.job='배움';queueLife(g,'childhood',r);}
    if(r.age>=16&&!r.adultNoted){r.adultNoted=true;memory(g,r,'성인이 되어 자신의 진로를 선택할 수 있게 되었다.');queueLife(g,'comingOfAge',r);}
    if(r.age>=60&&!r.retirementNoted){r.retirementNoted=true;queueLife(g,'retirement',r);}
    if(r.age>=70&&!r.retired){if(away(g,r.id))retreat(g,'노년의 동료를 위해 귀환');r.retired=true;r.job='가르침';memory(g,r,'긴 현역 생활을 마치고 공동체의 어른이 되었다.');}
    if(r.age>=r.lifespan&&!r.farewellNoted){r.farewellNoted=true;if(away(g,r.id))retreat(g,'동료의 마지막 시간을 위해 귀환');queueLife(g,'farewell',r);}
  }
}
function queueLife(g,kind,r) {
  const other=living(g).find(o=>o.id===r.guardians[0])||living(g).find(o=>o.id!==r.id)||r;
  const event={kind,who:r.id,other:other.id};
  // Final goodbyes take priority over routine milestones but always wait for confirmation.
  if(kind==='farewell')g.lifeQueue.unshift(event);else g.lifeQueue.push(event);
  log(g,`${r.name}, ${r.age}세 · ${kind==='farewell'?'함께할 마지막 시간을 준비합니다.':kind==='retirement'?'삶의 새로운 역할을 생각합니다.':kind==='comingOfAge'?'새로운 삶의 문턱에 섰습니다.':'세상에 대한 호기심이 자랍니다.'}`,'story');
}
function completeLife(g,r) {
  if(r.gear!=='none'){g.inventory[r.gear]++;memory(g,r,`${equipment[r.gear].name}를 공동체에 남겼다.`);r.gear='none';}
  r.alive=false;r.hp=0;r.retired=true;r.job='휴식';r.deathDay=day(g);
  memory(g,r,`${r.age}세에 노환으로 생을 마쳤다. 이곳에서의 삶은 사람들의 기억에 남았다.`);
  for(const other of living(g)){
    const grief=other.guardians.includes(r.id)?20:relationship(g,r.id,other.id)>=15?12:4;
    other.stress=clamp(other.stress+grief);if(other.mentorId===r.id)other.mentorId=null;
    if(grief>=12)memory(g,other,`${r.name}를 떠나보냈다. 함께한 시간과 가르침을 기억한다.`);
  }
  g.lifeQueue=g.lifeQueue.filter(e=>e.who!==r.id);
  g.storyQueue=g.storyQueue.filter(e=>e.who!==r.id&&e.other!==r.id);
  if(g.pendingEvent?.who===r.id)g.pendingEvent=null;
  log(g,`${r.name}, ${r.age}세 · 불 곁에 한 사람의 이름을 남겼다.`,'story');
  g.gameOver=living(g).length===0;
  if(g.gameOver){log(g,'마지막 불빛이 잦아들었다. 사람들의 삶은 기록으로 남았다.','story');if(!g.ending)finishJourney(g,'lastLight');}
}

export function restore(raw) {
  const g=JSON.parse(raw);
  const finite=(v,lo=0,hi=Number.MAX_SAFE_INTEGER)=>Number.isFinite(v)&&v>=lo&&v<=hi;
  const int=(v,lo=0,hi=Number.MAX_SAFE_INTEGER)=>Number.isInteger(v)&&v>=lo&&v<=hi;
  const fail=()=>{throw new Error('지원하지 않거나 손상된 저장 파일');};
  if(!g||![1,2,3,4,5,6,7,8,9].includes(g.version)||!Array.isArray(g.residents)||g.residents.length<4||g.residents.length>256)fail();
  const validId=v=>int(v,0,g.residents.length-1);
  const validEvent=e=>e===null||Boolean(e&&Object.hasOwn(eventTypes,e.kind||'training')&&validId(e.who)&&(e.other===undefined||validId(e.other)));
  if(!int(g.time)||![0,1,2,4,8].includes(g.speed)||!int(g.seed,0,4294967295)
    ||!['food','wood','medicine','records'].every(k=>finite(g[k]))||!int(g.level,1,4)
    ||typeof g.cleared!=='boolean'||!int(g.eventCount)||!finite(g.lastEvent)||!Array.isArray(g.log)
    ||g.log.some(l=>!l||!finite(l.time)||typeof l.text!=='string'||!['story','normal','expedition'].includes(l.kind))
    ||!validEvent(g.event)||g.residents.some((r,i)=>!r||r.id!==i||typeof r.name!=='string'||!int(r.age,0,200)
      ||!roles.includes(r.job)||!finite(r.hp,0,100)||!finite(r.stress,0,100)||!finite(r.skill,1)
      ||!finite(r.injury)||!finite(r.bond)||typeof r.trait!=='string'||!Array.isArray(r.history)||!r.history.length||r.history.some(h=>typeof h!=='string')))fail();
  if(g.expedition){const e=g.expedition;if(!Array.isArray(e.team)||![2,3].includes(e.team.length)||new Set(e.team).size!==e.team.length||e.team.some(id=>!validId(id))||!['신중','강행'].includes(e.policy)||!Object.hasOwn(areas,e.target)||!int(e.progress)||!int(e.node,0,4)||!finite(e.loot))fail();}
  if(g.version===1){Object.assign(g,{version:2,autoEvents:false,cycle:1,legacy:[],legacyPoints:0,world:0,relationships:{},pendingEvent:null,expeditions:0});g.residents.forEach(r=>r.trauma=0);if(g.event)g.event.kind='training';if(g.expedition)Object.assign(g.expedition,{report:[],start:g.time});}
  g.autoEvents??=false;
  if(g.version===2){g.version=3;g.lifeQueue=[];g.gameOver=false;g.totalBirths=0;g.residents.forEach(r=>Object.assign(r,lifeDefaults(r.age,r.id)));}
  if(g.version===3){
    g.version=4;g.inventory={shield:0,bow:0,kit:0,charm:0};g.relics=[];g.activeRelic=null;
    g.residents.forEach(r=>Object.assign(r,combatDefaults(r.id)));
    if(g.expedition)Object.assign(g.expedition,{engine:'tactical',wait:0,battle:null,choice:null,path:g.expedition.node>=3?'safe':null,supplies:3,medkits:0});
  }
  if(g.version===4){g.version=5;g.facilities=facilityDefaults();g.storyQueue=[];g.routineCount=g.eventCount;g.residents.forEach(r=>Object.assign(r,settlementDefaults(r.id,r.skill)));}
  if(g.version===5){g.version=6;g.crisis=createCrisis([0,1,2].includes(g.world)?g.world:0,g.time);g.ending=null;if(g.gameOver)finishJourney(g,'lastLight');}
  if(g.version===6){g.version=7;g.inventory.pick??=0;g.inventory.salve??=0;if(g.expedition)Object.assign(g.expedition,{lootMedicine:0,bonusRecords:0,discovery:null,healGiftUsed:false});}
  if(g.version===7){g.version=8;g.town=createTown(true,g.facilities);g.operatingPolicy='balanced';for(const r of g.residents)r.appearance=defaultAppearance(r.id);spawnResidents(g);}
  if(g.version===8){g.version=9;g.yearSeconds=120;g.social=socialDefaults(g);for(const r of g.residents)r.memories=[];}
  if(![120,600].includes(g.yearSeconds))fail();
  if(typeof g.autoEvents!=='boolean'||!int(g.cycle,1)||!int(g.legacyPoints)||!int(g.world,0,worldConditions.length-1)||!Array.isArray(g.legacy)
    ||!int(g.expeditions)||!validEvent(g.pendingEvent)||!g.relationships||Array.isArray(g.relationships)||typeof g.relationships!=='object'
    ||Object.entries(g.relationships).some(([key,v])=>{const parts=key.split(':');return parts.length!==2||parts.some(p=>!/^\d+$/.test(p))||!validId(+parts[0])||!validId(+parts[1])||+parts[0]>=+parts[1]||!finite(v,-100,100);})
    ||g.residents.some(r=>!int(r.trauma,0,3))
    ||g.legacy.some(s=>!s||!int(s.cycle,1)||typeof s.place!=='string'||!int(s.days,1)||!int(s.expeditions)||!Array.isArray(s.stories)||s.stories.some(r=>typeof r.name!=='string'||!finite(r.skill)||!Array.isArray(r.history)||r.history.some(h=>typeof h!=='string')))
    ||(g.expedition&&(!Array.isArray(g.expedition.report)||g.expedition.report.some(r=>!int(r.node,1,5)||typeof r.title!=='string'||typeof r.text!=='string'))))fail();
  if(typeof g.gameOver!=='boolean'||!int(g.totalBirths)||!Array.isArray(g.lifeQueue)||g.lifeQueue.some(e=>!validEvent(e)||!e||!g.residents[e.who].alive)
    ||g.residents.some(r=>typeof r.alive!=='boolean'||!int(r.ageProgress,0,g.yearSeconds-1)||!int(r.lifespan,1,200)
      ||typeof r.retired!=='boolean'||!Array.isArray(r.guardians)||r.guardians.length>2||new Set(r.guardians).size!==r.guardians.length||r.guardians.some(id=>!validId(id)||id>=r.id)
      ||!Array.isArray(r.familyNames)||r.familyNames.some(n=>typeof n!=='string')||!int(r.generation,1)||!finite(r.education,0,1)
      ||(r.mentorId!==null&&(!validId(r.mentorId)||r.mentorId===r.id||!g.residents[r.mentorId].alive))
      ||!finite(r.lastChildAt,-g.yearSeconds)||['childhoodNoted','adultNoted','retirementNoted','farewellNoted'].some(k=>typeof r[k]!=='boolean')
      ||(r.deathDay!==null&&!int(r.deathDay,1))||(!r.alive&&(r.hp!==0||r.deathDay===null))
      ||(r.alive&&!availableRoles(g,r).includes(r.job)))
    ||(g.event&&!g.residents[g.event.who].alive)||(g.pendingEvent&&!g.residents[g.pendingEvent.who].alive)
    ||(g.expedition&&g.expedition.team.some(id=>!g.residents[id].alive||g.residents[id].age<16||g.residents[id].retired))
    ||g.gameOver!==(living(g).length===0)||living(g).length>capacity(g))fail();
  if(!validateSocial(g,{int,finite,validId})||!validateTown(g)||g.residents.some(r=>!validAppearance(r.appearance)||r.background!==undefined&&!Object.hasOwn(backgrounds,r.background))||!validTacticalSave(g,{int,finite,validId})||!validateSettlement(g,{int,finite,validId})||!validateJourney(g,{int,finite,validId}))fail();
  return g;
}

export function setCombatClass(g,id,kind) {
  const r=g.residents[id];if(journeyFrozen(g)||g.event||!r?.alive||r.age<16||r.retired||away(g,id)||!Object.hasOwn(combatClasses,kind))return false;
  r.combatClass=kind;return true;
}
export function craftEquipment(g,key) {
  if(!g.town.legacy)return queueCraft(g,key);
  const item=equipment[key];if(journeyFrozen(g)||g.event||g.gameOver||!item?.cost||Object.entries(item.cost).some(([k,n])=>g[k]<n))return false;
  for(const [k,n] of Object.entries(item.cost))g[k]-=n;g.inventory[key]++;
  log(g,`작업장에서 ${item.name}를 제작했다.`,'story');return true;
}
export function equipResident(g,id,key) {
  const r=g.residents[id];if(journeyFrozen(g)||g.event||!r?.alive||r.age<16||away(g,id)||!Object.hasOwn(equipment,key))return false;
  if(r.gear===key)return true;
  if(key!=='none'&&g.inventory[key]<1)return false;
  if(r.gear!=='none')g.inventory[r.gear]++;
  if(key!=='none')g.inventory[key]--;r.gear=key;return true;
}
export function activateRelic(g,key) {
  if(g.expedition||g.event||(key!==null&&!g.relics.includes(key)))return false;
  g.activeRelic=key;return true;
}
function validTacticalSave(g,{int,finite,validId}) {
  if(!g.inventory||typeof g.inventory!=='object'||Array.isArray(g.inventory)
    ||Object.keys(g.inventory).length!==Object.keys(equipment).length-1||Object.keys(equipment).filter(k=>k!=='none').some(k=>!int(g.inventory[k]))
    ||g.residents.some(r=>!Object.hasOwn(combatClasses,r.combatClass)||!Object.hasOwn(equipment,r.gear))
    ||!Array.isArray(g.relics)||new Set(g.relics).size!==g.relics.length||g.relics.some(k=>!Object.hasOwn(relics,k))
    ||(g.activeRelic!==null&&!g.relics.includes(g.activeRelic)))return false;
  const e=g.expedition;if(!e)return true;
  if(!int(e.lootMedicine)||!int(e.bonusRecords)||typeof e.healGiftUsed!=='boolean'||(e.discovery!==null&&!Object.hasOwn(discoveries,e.discovery)))return false;
  if(e.engine!=='tactical'||!int(e.wait,0,3)||!int(e.supplies,0,3)||!int(e.medkits,0,3)
    ||![null,'safe','shortcut','camp'].includes(e.path)||(e.node>=3&&e.path===null)
    ||(e.choice!==null&&(!e.choice||e.choice.kind!=='crossroads'||e.node!==2||e.battle!==null)))return false;
  const b=e.battle;if(b===null)return true;
  if(!b||![1,4,5].includes(b.node)||b.node!==e.node+1||e.choice!==null||!int(b.turn,1,16)||!int(b.clock,0,1)
    ||!Array.isArray(b.enemies)||b.enemies.length<1||b.enemies.length>2
    ||b.enemies.some((r,i)=>r.id!==i||!Object.hasOwn(enemies,r.kind)||r.maxHp!==enemies[r.kind].hp||!finite(r.hp,0,r.maxHp)||typeof r.marked!=='boolean'||typeof r.intent!=='string'||(r.hp>0&&r.intent!==enemyIntent(r.kind,b.turn)))
    ||!b.bleeding||typeof b.bleeding!=='object'||Array.isArray(b.bleeding)||Object.entries(b.bleeding).some(([k,v])=>!validId(+k)||!e.team.includes(+k)||!int(v,0,2))
    ||!Array.isArray(b.actions)||b.actions.some(x=>typeof x!=='string'))return false;
  return true;
}

function scheduleStory(g,kind,who,other,delay){
  if(who===other||g.storyQueue.some(e=>e.kind===kind&&e.who===who&&e.other===other))return;
  if(g.storyQueue.length<24)g.storyQueue.push({kind,who,other,due:g.time+delay});
}
export function upgradeFacility(g,id){
  if(!g.town.legacy)return queueUpgrade(g,id);
  if(journeyFrozen(g)||g.event||!Object.hasOwn(facilities,id)||g.facilities[id]>=3)return false;
  const cost=facilityCost(g,id);if(Object.entries(cost).some(([k,n])=>g[k]<n))return false;
  for(const [k,n] of Object.entries(cost))g[k]-=n;g.facilities[id]++;const b=g.town.buildings.find(b=>b.kind===id);if(b)b.level=g.facilities[id];g.town.revision++;
  for(const r of living(g).filter(r=>!away(g,r.id)&&effectiveRole(r)==='건설'))recordGoal(g,r.id,'build',1);
  log(g,`${facilities[id].name} 개선 · ${g.facilities[id]}단계. ${facilities[id].bonus(g.facilities[id])}`,'story');
  updateGoals(g,{relationship,memory,log});return true;
}
export function setAutonomy(g,id,value){
  const r=g.residents[id];if(journeyFrozen(g)||g.event||!r?.alive||away(g,id)||typeof value!=='boolean')return false;
  r.autonomy=value;if(!value){r.routine='assigned';r.workRole=r.job;r.workLabel=r.job;}return true;
}
export function setPersonalGoal(g,id,kind){
  const r=g.residents[id];if(journeyFrozen(g)||g.event||!r?.alive||away(g,id)||!Object.hasOwn(goalTypes,kind)||r.completedGoals.includes(kind)||r.personalGoal.kind===kind)return false;
  r.personalGoal=makeGoal(kind,r.skill);memory(g,r,`새로운 개인 목표 「${goalTypes[kind].name}」를 정했다.`);updateGoals(g,{relationship,memory,log});return true;
}

export function contributeCrisis(g,id){
  if(journeyFrozen(g)||g.event||!Object.hasOwn(preparationTypes,id)||g.crisis.resolved||g.crisis.preparations[id]>=3)return false;
  const cost=preparationTypes[id].cost;if(Object.entries(cost).some(([k,n])=>g[k]<n))return false;
  for(const [k,n] of Object.entries(cost))g[k]-=n;g.crisis.preparations[id]++;
  log(g,`${crisisTypes[g.crisis.kind].name} 대비 · ${preparationTypes[id].name} ${g.crisis.preparations[id]}/3. 물자를 공동체 대응에 투입했다.`,'story');return true;
}
export function beginCrisis(g){
  if(!canConfront(g))return false;
  g.crisis.ready=true;log(g,'준비를 마치고 다가올 위기를 맞기로 했다. 최종 결정 전까지 시간은 멈춘다.','story');return true;
}
function finishJourney(g,kind){
  if(g.ending)return false;
  const readiness=crisisReadiness(g);g.crisis.ready=false;g.crisis.resolved=true;g.crisis.sandbox=false;
  const def=endingTypes[kind];
  log(g,`이번 여정의 결말 · ${def.title}. ${def.description}`,'story');
  g.ending={kind,success:def.success,at:g.time,score:readiness.score,required:readiness.required,snapshot:endingSnapshot(g)};
  return true;
}
export function resolveCrisis(g,choice){
  if(!g.crisis.ready||g.crisis.resolved||g.ending||g.event||g.expedition||!['defend','evacuate'].includes(choice))return false;
  const readiness=crisisReadiness(g);
  if(choice==='evacuate')return finishJourney(g,'evacuation');
  if(readiness.score>=readiness.required){
    for(const r of living(g)){r.stress=Math.max(0,r.stress-10);memory(g,r,`${crisisTypes[g.crisis.kind].name}를 동료들과 함께 견뎌냈다.`);}
    return finishJourney(g,g.cleared?'beacon':'shelter');
  }
  for(const r of living(g)){r.hp=Math.max(1,r.hp-15);r.stress=Math.min(100,r.stress+20);r.injury++;memory(g,r,`${crisisTypes[g.crisis.kind].name} 앞에서 터전을 지키지 못했다. 사람과 기록을 챙겨 떠나기로 했다.`);}
  return finishJourney(g,'ruin');
}
export function continueSettlement(g){
  if(!g.ending?.success||g.crisis.sandbox)return false;
  g.crisis.sandbox=true;log(g,'위기를 넘긴 터전에서 계속 살기로 했다. 위기는 재발하지 않으며 다음 세대의 삶이 이어진다.','story');return true;
}

export function customizeResident(g,id,changes){
 const r=g.residents[id];if(!r?.alive||journeyFrozen(g)||g.event||typeof changes?.name!=='string'||!changes.name.trim()||changes.name.length>24||!validAppearance(changes.appearance))return false;
 r.name=changes.name.trim();r.appearance=structuredClone(changes.appearance);return true;
}
export function setOperatingPolicy(g,policy){if(journeyFrozen(g)||g.event||!['balanced','build','recover'].includes(policy))return false;g.operatingPolicy=policy;for(const r of g.residents)r.manualRole=false;return true;}

export function visitorCandidate(g){return g.social.visitor?generateFounder(g.social.visitor.seed,0):null;}
export function visitorReadiness(g){
 const r=visitorCandidate(g);if(!r)return {allowed:false,reason:'현재 기다리는 생존자가 없습니다.'};
 if(journeyFrozen(g)||g.event)return {allowed:false,reason:'현재 선택을 먼저 마쳐 주세요.'};
 if(living(g).length>=capacity(g)||g.residents.length>=256)return {allowed:false,reason:'잠자리가 부족합니다. 숙소나 피난처를 확장하세요.'};
 if(g.food<12||g.wood<6)return {allowed:false,reason:'맞이할 식량 12와 자재 6이 필요합니다.'};
 return {allowed:true,reason:'식량 12 · 자재 6 / 이후 성인 한 명의 식량 유지비가 추가됩니다.'};
}
export function welcomeSurvivor(g){
 if(!visitorReadiness(g).allowed)return null;
 const candidate=visitorCandidate(g),id=g.residents.length;
 const r={id,...candidate,job:'농사',hp:85,stress:28,injury:0,trauma:0,...lifeDefaults(candidate.age,id),...combatDefaults(id),...settlementDefaults(id,candidate.skill),bond:0,history:['먼 길 끝에 이 피난처의 불빛을 찾아왔다.'],memories:[]};
 if(g.residents.some(p=>p.name===r.name))r.name+='·길손';
 r.motion={x:14,y:9,path:[],target:'14,9',revision:g.town.revision,arrived:true,prevX:14,prevY:9};r.lastChildAt=-g.yearSeconds;g.food-=12;g.wood-=6;g.residents.push(r);spawnResidents(g);g.social.visitor=null;g.social.visitorDone=true;
 rememberFact(g,r,'arrival',null,'주민들이 새 잠자리와 식사를 마련해 주었다.');log(g,`${r.name}가 공동체에 합류했다. 식량 -12 · 자재 -6 · 주민 ${living(g).length}명.`,'story');return r;
}
export function declineSurvivor(g){if(journeyFrozen(g)||g.event||!g.social.visitor)return false;g.social.visitor=null;g.social.visitorDone=true;log(g,'길손에게 이번에는 함께하기 어렵다고 전했다. 합류는 강제가 아니다.','story');return true;}
