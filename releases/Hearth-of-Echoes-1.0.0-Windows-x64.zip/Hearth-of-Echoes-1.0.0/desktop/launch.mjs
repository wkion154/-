import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {createGameServer,APP_ID} from './server.mjs';
export const PORT=43187;
export async function launch({root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),openBrowser=true}={}){
 const url=`http://127.0.0.1:${PORT}/`;
 const open=()=>{if(!openBrowser)return;if(process.platform==='win32')execFile('rundll32.exe',['url.dll,FileProtocolHandler',url],error=>{if(error)console.error('Open your browser at '+url);});else console.log('Open your browser at '+url);};
 const server=createGameServer(root);
 try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(PORT,'127.0.0.1',resolve);});}
 catch(error){
  if(error.code==='EADDRINUSE'){
   try{const r=await fetch(url+'__hearth_health',{signal:AbortSignal.timeout(2000)});const data=await r.json();if(data.app===APP_ID&&data.version==='1.0.0'){console.log('The game is already running.');open();return null;}}catch{}
   throw Error(`Port ${PORT} is occupied by another program. Close that program and try again.`);
  }throw error;
 }
 console.log('The Hearth of Echoes 1.0\n'+url+'\nKeep this window open while playing. Press Ctrl+C to stop.');open();return server;
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
 launch({openBrowser:!process.argv.includes('--no-browser')}).then(server=>{
  if(server)for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>server.close(()=>process.exit(0)));
 }).catch(error=>{console.error('Unable to start: '+error.message);process.exitCode=1;});
}
