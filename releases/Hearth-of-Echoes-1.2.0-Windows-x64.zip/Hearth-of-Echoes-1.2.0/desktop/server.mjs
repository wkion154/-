import http from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
export const APP_ID='hearth-of-echoes-desktop';
export function createGameServer(root){
 return http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'}).end();return;}
  try{
   const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
   if(pathname==='/__hearth_health'){const data=JSON.stringify({app:APP_ID,version:'1.2.0'});res.writeHead(200,{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}).end(req.method==='HEAD'?undefined:data);return;}
   const relative=pathname==='/'?'index.html':pathname.slice(1);
   if(relative!=='index.html'&&!/^src\/[a-z-]+\.(js|css)$/.test(relative)){res.writeHead(404).end('Not found');return;}
   const data=await readFile(path.join(root,relative));
   res.writeHead(200,{'Content-Type':relative.endsWith('.html')?'text/html; charset=utf-8':relative.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8','Content-Length':data.length});res.end(req.method==='HEAD'?undefined:data);
  }catch{res.writeHead(404).end('Not found');}
 });
}
