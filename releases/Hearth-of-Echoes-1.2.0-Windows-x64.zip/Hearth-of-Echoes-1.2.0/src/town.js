import {equipment} from './combat.js';
import {journeyFrozen} from './journey.js';
export const GRID={cols:28,rows:16,cell:40};
export const buildingDefs={
 farm:{name:'밭',w:4,h:3,cost:{wood:14},work:40},workshop:{name:'작업장',w:4,h:3,cost:{wood:18},work:50},
 clinic:{name:'의무소',w:3,h:3,cost:{wood:20},work:55},dorm:{name:'숙소',w:4,h:3,cost:{wood:18},work:50},
 lounge:{name:'공동 식사 공간',w:4,h:3,cost:{wood:14},work:40},school:{name:'배움터',w:3,h:3,cost:{wood:24,records:1},work:60},
 tent:{name:'야영 텐트',w:3,h:2,cost:{wood:8},work:25},table:{name:'야영 테이블',w:3,h:1,cost:{wood:4},work:15},
 crate:{name:'보급 상자',w:2,h:1,cost:{wood:4},work:15},fire:{name:'모닥불',w:1,h:1,cost:{},work:1},
};
const facilityIds=['farm','workshop','clinic','dorm','lounge','school'];
const key=(x,y)=>x+','+y;
export function sizeOf(b){const d=buildingDefs[b.kind];return b.rotation%2?{w:d.h,h:d.w}:{w:d.w,h:d.h};}
export function footprint(b){const {w,h}=sizeOf(b),a=[];for(let x=b.x;x<b.x+w;x++)for(let y=b.y;y<b.y+h;y++)a.push({x,y});return a;}
export function entryOf(b){const {w,h}=sizeOf(b);return b.rotation%2?{x:b.x+w,y:b.y+Math.floor(h/2)}:{x:b.x+Math.floor(w/2),y:b.y+h};}
export function terrainOK(x,y){return Number.isInteger(x)&&Number.isInteger(y)&&x>=1&&y>=1&&x<27&&y<15&&!(x>=23&&y>=2&&y<=6);}
export function createTown(established=false,facilities={}){
 const buildings=[{id:'fire',kind:'fire',x:14,y:8,rotation:0,level:1},{id:'table',kind:'table',x:12,y:6,rotation:0,level:1},{id:'crate',kind:'crate',x:8,y:7,rotation:0,level:1}];
 if(!established)buildings.push({id:'tent-a',kind:'tent',x:9,y:11,rotation:0,level:1},{id:'tent-b',kind:'tent',x:16,y:11,rotation:0,level:1});
 else for(const [kind,x,y] of [['farm',11,2],['lounge',4,2],['clinic',18,2],['workshop',4,10],['dorm',19,10],['school',23,10]])buildings.push({id:'old-'+kind,kind,x,y,rotation:0,level:facilities[kind]||1});
 return {version:1,legacy:established,buildings,roads:[],queue:[],nextId:1,revision:0};
}
export function blockedCells(town,{ignore=null,extra=null}={}){
 const set=new Set();for(const b of town.buildings)if(b.id!==ignore)for(const p of footprint(b))set.add(key(p.x,p.y));
 for(const q of town.queue)if(['build','move'].includes(q.type))for(const p of footprint({kind:q.kind,x:q.x,y:q.y,rotation:q.rotation}))set.add(key(p.x,p.y));
 if(extra)for(const p of footprint(extra))set.add(key(p.x,p.y));return set;
}
export function findPath(town,start,end,blocked=blockedCells(town)){
 const sx=Math.round(start.x),sy=Math.round(start.y);if(!terrainOK(sx,sy)||!terrainOK(end.x,end.y)||blocked.has(key(end.x,end.y)))return null;
 const dist=new Map([[key(sx,sy),0]]),previous=new Map(),open=[{x:sx,y:sy,cost:0}],roads=new Map(town.roads.map(p=>[key(p.x,p.y),p.kind==='paved'?1.65:1.3]));
 while(open.length){open.sort((a,b)=>a.cost-b.cost);const at=open.shift(),ak=key(at.x,at.y);if(at.cost!==dist.get(ak))continue;
  if(at.x===end.x&&at.y===end.y){const route=[];let k=ak;while(k!==key(sx,sy)){const [x,y]=k.split(',').map(Number);route.unshift({x,y});k=previous.get(k);}return route;}
  for(const [dx,dy] of [[1,0],[0,1],[-1,0],[0,-1]]){const x=at.x+dx,y=at.y+dy,k=key(x,y);if(!terrainOK(x,y)||blocked.has(k))continue;const cost=at.cost+1/(roads.get(k)||1);if(cost<(dist.get(k)??Infinity)){dist.set(k,cost);previous.set(k,ak);open.push({x,y,cost});}}
 }return null;
}
function reachable(town,extra=null){const blocked=blockedCells(town,{extra}),seen=new Set();if(blocked.has('14,9'))return seen;const open=[{x:14,y:9}];seen.add('14,9');for(let i=0;i<open.length;i++){const p=open[i];for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const x=p.x+dx,y=p.y+dy,k=key(x,y);if(terrainOK(x,y)&&!blocked.has(k)&&!seen.has(k)){seen.add(k);open.push({x,y});}}}return seen;}
function accessible(town,extra=null,seen=reachable(town,extra)){return [...town.buildings.filter(b=>b.kind!=='fire'),...town.queue.filter(q=>['build','move'].includes(q.type)),...(extra?[extra]:[])].every(b=>{const p=entryOf(b);return seen.has(key(p.x,p.y));});}

export function placementStatus(g,kind,x,y,rotation=0,ignore=null){
 if(!Object.hasOwn(buildingDefs,kind)||!Number.isInteger(rotation)||rotation<0||rotation>1)return {ok:false,reason:'시설과 방향을 확인하세요.'};
 const b={kind,x,y,rotation};if(!footprint(b).every(p=>terrainOK(p.x,p.y)))return {ok:false,reason:'물과 지도의 가장자리에는 놓을 수 없습니다.'};
 const blocked=blockedCells(g.town,{ignore}),roads=new Set([...g.town.roads,...g.town.queue.flatMap(q=>q.cells||[])].map(p=>key(p.x,p.y)));
 if(footprint(b).some(p=>blocked.has(key(p.x,p.y))||roads.has(key(p.x,p.y))))return {ok:false,reason:'건물·청사진·길과 겹칩니다.'};
 if(g.residents.some(r=>r.alive&&!g.expedition?.team.includes(r.id)&&r.motion&&footprint(b).some(p=>Math.round(r.motion.x)===p.x&&Math.round(r.motion.y)===p.y)))return {ok:false,reason:'주민이 서 있는 칸입니다. 잠시 기다리거나 다른 위치를 고르세요.'};
 const seen=reachable(g.town,b);if(!accessible(g.town,b,seen)||g.residents.some(r=>r.alive&&!g.expedition?.team.includes(r.id)&&r.motion&&!seen.has(key(Math.round(r.motion.x),Math.round(r.motion.y)))))return {ok:false,reason:'출입구 또는 야영지로 이어지는 통로가 막힙니다.'};return {ok:true,reason:'출입구와 이동 경로를 확인했습니다.'};
}
function canOrder(g){return !journeyFrozen(g)&&!g.event&&!g.gameOver&&g.town.queue.length<3;}
function reserve(g,cost){if(Object.entries(cost).some(([k,n])=>g[k]<n))return false;for(const [k,n] of Object.entries(cost))g[k]-=n;return true;}
function append(g,q){g.town.queue.push({id:g.town.nextId++,...q,progress:0});g.town.revision++;return true;}
export function queueBuilding(g,kind,x,y,rotation=0){
 if(!canOrder(g)||!facilityIds.includes(kind)||g.facilities[kind]>0||g.town.queue.some(q=>q.kind===kind&&q.type==='build')||!placementStatus(g,kind,x,y,rotation).ok)return false;
 const d=buildingDefs[kind];if(!reserve(g,d.cost))return false;return append(g,{type:'build',kind,x,y,rotation,cost:{...d.cost},work:d.work});
}
export function queueUpgrade(g,kind){
 const b=g.town.buildings.find(b=>b.kind===kind);if(!canOrder(g)||!b||!facilityIds.includes(kind)||b.level>=3||g.town.queue.some(q=>q.buildingId===b.id))return false;
 const cost={wood:18*b.level,...(b.level>=2?{records:1}:{})};if(!reserve(g,cost))return false;return append(g,{type:'upgrade',buildingId:b.id,kind,cost,work:40+20*b.level});
}
export function queueMove(g,id,x,y,rotation=0){
 const b=g.town.buildings.find(b=>b.id===id);if(!canOrder(g)||!b||b.kind==='fire'||g.town.queue.some(q=>q.buildingId===id)||!placementStatus(g,b.kind,x,y,rotation,id).ok)return false;
 const cost={wood:4};if(!reserve(g,cost))return false;return append(g,{type:'move',buildingId:id,kind:b.kind,x,y,rotation,cost,work:25});
}
export function queueDemolish(g,id){
 const b=g.town.buildings.find(b=>b.id===id);if(!canOrder(g)||!b||!facilityIds.includes(b.kind)||g.town.queue.some(q=>q.buildingId===id))return false;
 if(b.kind==='dorm'&&g.residents.filter(r=>r.alive).length>townCapacity(g)-g.facilities.dorm*2)return false;
 return append(g,{type:'demolish',buildingId:id,kind:b.kind,cost:{},work:20});
}
export function roadLine(a,b){const cells=[];let x=a.x,y=a.y;cells.push({x,y});while(x!==b.x){x+=Math.sign(b.x-x);cells.push({x,y});}while(y!==b.y){y+=Math.sign(b.y-y);cells.push({x,y});}return cells;}
export function roadStatus(g,cells,kind='dirt'){
 if(!['dirt','paved','remove'].includes(kind)||!Array.isArray(cells)||cells.length<1||cells.length>40||new Set(cells.map(p=>key(p.x,p.y))).size!==cells.length)return {ok:false,reason:'한 번에 1~40칸의 길을 지정하세요.'};
 const blocked=blockedCells(g.town);if(cells.some((p,i)=>!terrainOK(p.x,p.y)||blocked.has(key(p.x,p.y))||(i>0&&Math.abs(p.x-cells[i-1].x)+Math.abs(p.y-cells[i-1].y)!==1)))return {ok:false,reason:'길이 건물·물과 겹치거나 연결되지 않았습니다.'};
 const occupied=new Set(g.town.queue.flatMap(q=>(q.cells||[]).map(p=>key(p.x,p.y))));if(cells.some(p=>occupied.has(key(p.x,p.y))))return {ok:false,reason:'이미 예약된 길 공사가 있습니다.'};
 const filtered=cells.filter(p=>{const old=g.town.roads.find(r=>r.x===p.x&&r.y===p.y);return kind==='remove'?!!old:kind==='paved'?old?.kind!=='paved':!old;});
 return filtered.length?{ok:true,cells:filtered,cost:kind==='paved'?{wood:filtered.length}:{},work:filtered.length*(kind==='paved'?4:2),reason:`${filtered.length}칸 · ${kind==='paved'?'자재 '+filtered.length:'자재 소모 없음'}`}:{ok:false,reason:'변경할 길이 없습니다.'};
}
export function queueRoad(g,cells,kind='dirt'){
 if(!canOrder(g))return false;const status=roadStatus(g,cells,kind);if(!status.ok||!reserve(g,status.cost))return false;return append(g,{type:'road',roadKind:kind,cells:status.cells,cost:status.cost,work:status.work});
}
export function queueCraft(g,item){
 const d=equipment[item];if(!canOrder(g)||!d?.cost||!['shield','kit'].includes(item)&&g.facilities.workshop===0||!reserve(g,d.cost))return false;
 return append(g,{type:'craft',item,cost:{...d.cost},work:24});
}
export function cancelWork(g,id){
 if(journeyFrozen(g)||g.event)return false;const i=g.town.queue.findIndex(q=>q.id===id);if(i<0)return false;const q=g.town.queue[i];for(const [k,n] of Object.entries(q.cost))g[k]+=Math.floor(n*(1-q.progress/q.work));g.town.queue.splice(i,1);g.town.revision++;return true;
}
export function prioritizeWork(g,id){if(journeyFrozen(g)||g.event)return false;const i=g.town.queue.findIndex(q=>q.id===id);if(i<=0)return false;g.town.queue.unshift(...g.town.queue.splice(i,1));g.town.revision++;return true;}
export function townCapacity(g){return Math.min(12,g.town?.legacy?6+g.level*2:4+g.facilities.dorm*2+(g.level-1)*2);}
const resourceTargets=new WeakMap();
function fallbackTarget(town,role){
 let cache=resourceTargets.get(town);if(!cache||cache.revision!==town.revision){cache={revision:town.revision,targets:{}};resourceTargets.set(town,cache);}
 if(cache.targets[role])return cache.targets[role];const blocked=blockedCells(town),choices=role==='농사'?[{x:4,y:5},{x:4,y:9},{x:20,y:7},{x:2,y:2},{x:14,y:9}]:role==='건설'?[{x:7,y:8},{x:7,y:9},{x:20,y:8},{x:14,y:9}]:role==='치료'?[{x:15,y:9},{x:14,y:9}]:[{x:14,y:9}];
 return cache.targets[role]=choices.find(p=>!blocked.has(key(p.x,p.y))&&findPath(town,{x:14,y:9},p,blocked)!==null)||{x:14,y:9};
}
export function workTarget(g,r,role){
 const q=g.town.queue[0];if(role==='건설'&&q){
  if(q.type==='road')return q.cells[0];if(q.type==='build'||q.type==='move')return entryOf({kind:q.kind,x:q.x,y:q.y,rotation:q.rotation});
  if(q.type==='craft'&&!g.facilities.workshop)return entryOf(g.town.buildings.find(b=>b.kind==='table'));
  if(q.type!=='craft'){const b=g.town.buildings.find(b=>b.id===q.buildingId);if(b)return entryOf(b);}
 }
 const kind={농사:'farm',건설:'workshop',치료:'clinic',휴식:r.hp<95&&g.facilities.clinic>0?'clinic':'dorm',배움:'school',가르침:'school',교류:'lounge'}[role];
 const b=g.town.buildings.find(b=>b.kind===kind);if(b)return entryOf(b);
 return role==='교류'?entryOf(g.town.buildings.find(b=>b.kind==='table')):fallbackTarget(g.town,role);
}
export function travelStep(g,r,target){
 const m=r.motion??={x:14,y:9,path:[],revision:-1,target:''};m.prevX=m.x;m.prevY=m.y;const signature=key(target.x,target.y);
 if(m.target!==signature||m.revision!==g.town.revision){const route=findPath(g.town,m,target);const start={x:Math.round(m.x),y:Math.round(m.y)};m.path=route?((Math.hypot(m.x-start.x,m.y-start.y)>.001)?[start,...route]:route):[];m.target=signature;m.revision=g.town.revision;}
 let budget=.6;while(m.path.length&&budget>0){const next=m.path[0],road=g.town.roads.find(p=>p.x===next.x&&p.y===next.y),speed=road?.kind==='paved'?1.65:road?1.3:1;
  const distance=Math.hypot(next.x-m.x,next.y-m.y),step=Math.min(distance,budget*speed);if(distance<.001){m.path.shift();continue;}m.x+=(next.x-m.x)/distance*step;m.y+=(next.y-m.y)/distance*step;budget-=step/speed;if(step>=distance-.0001)m.path.shift();
 }m.arrived=Math.hypot(m.x-target.x,m.y-target.y)<.03;return m.arrived;
}
function baseRole(r){return r.routine==='recover'?'휴식':r.routine==='socialize'?'교류':r.job;}
export function advanceTown(g,home,hooks){
 const hurt=home.some(r=>r.hp<90||r.injury>.2),eligible=home.filter(r=>r.autonomy&&r.age>=16&&!r.retired&&r.hp>=45);
 const doctor=hurt&&g.medicine>.5?eligible.filter(r=>!r.manualRole||r.job==='치료').sort((a,b)=>(b.job==='치료')-(a.job==='치료')||b.hp-a.hp)[0]:null;
 const farmer=g.food<18?eligible.filter(r=>!r.manualRole||r.job==='농사').sort((a,b)=>(b.job==='농사')-(a.job==='농사')||b.skill-a.skill)[0]:null;
 for(const r of home){let role=baseRole(r);
  if(!g.town.legacy&&r.autonomy&&r.age>=16&&!r.retired){if(r===farmer)role='농사';else if(r===doctor)role='치료';else if(!r.manualRole&&g.operatingPolicy==='build'&&g.town.queue.length&&role!=='휴식')role='건설';else if(!r.manualRole&&g.operatingPolicy==='recover'&&r!==doctor)role='휴식';}
  r.workRole=role;r.workLabel=g.town.legacy?role:role==='농사'&&!g.facilities.farm?'야외 채집':role==='건설'?g.town.queue.length?g.town.queue[0].type==='craft'?'장비 제작':'공사':'자재 수집':role;r.townWorking=false;const arrived=travelStep(g,r,workTarget(g,r,role));const q=g.town.queue[0];
  if(role==='건설'&&q&&arrived){r.townWorking=true;q.progress=Math.min(q.work,q.progress+(1+r.skill*.45)*(r.background==='carpenter'?1.15:1));
   if(q.progress>=q.work){complete(g,q,hooks,r);g.town.queue.shift();g.town.revision++;}
  }
 }
}
function complete(g,q,hooks,worker){
 const b=g.town.buildings.find(b=>b.id===q.buildingId);
 if(q.type==='build'){g.town.buildings.push({id:'b'+q.id,kind:q.kind,x:q.x,y:q.y,rotation:q.rotation,level:1});g.facilities[q.kind]=1;}
 if(q.type==='upgrade'&&b){b.level++;g.facilities[b.kind]=b.level;}
 if(q.type==='move'&&b){b.x=q.x;b.y=q.y;b.rotation=q.rotation;}
 if(q.type==='demolish'&&b){g.town.buildings=g.town.buildings.filter(p=>p.id!==b.id);g.facilities[b.kind]=0;g.wood+=Math.floor((buildingDefs[b.kind].cost.wood||0)*.4);}
 if(q.type==='road')for(const p of q.cells){g.town.roads=g.town.roads.filter(r=>r.x!==p.x||r.y!==p.y);if(q.roadKind!=='remove')g.town.roads.push({...p,kind:q.roadKind});}
 if(q.type==='craft')g.inventory[q.item]++;
 if(['build','upgrade'].includes(q.type))hooks.recordGoal(g,worker.id,'build',1);
 hooks.log(g,`${q.type==='craft'?equipment[q.item].name:q.type==='road'?'길':buildingDefs[q.kind]?.name||'시설'} ${q.type==='move'?'이설':q.type==='demolish'?'철거':'작업'} 완료 · ${worker.name}가 마무리했다.`,'story');
}
export function validateTown(g){
 const t=g.town,int=(v,a=0,b=1e9)=>Number.isInteger(v)&&v>=a&&v<=b;
 if(!t||t.version!==1||typeof t.legacy!=='boolean'||!int(t.nextId,1)||!int(t.revision)||!Array.isArray(t.buildings)||t.buildings.length>15||!Array.isArray(t.roads)||t.roads.length>448||!Array.isArray(t.queue)||t.queue.length>3)return false;
 const ids=new Set(),occupied=new Set();for(const b of t.buildings){if(typeof b.id!=='string'||!/^([a-z]+(?:-[a-z]+)?|b[0-9]+)$/.test(b.id)||ids.has(b.id)||!Object.hasOwn(buildingDefs,b.kind)||!int(b.rotation,0,1)||!int(b.level,1,3)||!footprint(b).every(p=>terrainOK(p.x,p.y)&&!occupied.has(key(p.x,p.y))))return false;ids.add(b.id);for(const p of footprint(b))occupied.add(key(p.x,p.y));}
 for(const id of facilityIds){const matches=t.buildings.filter(b=>b.kind===id);if(matches.length>1||g.facilities[id]!== (matches[0]?.level||0))return false;}
 const roads=new Set();for(const p of t.roads){const k=key(p.x,p.y);if(!terrainOK(p.x,p.y)||occupied.has(k)||roads.has(k)||!['dirt','paved'].includes(p.kind))return false;roads.add(k);}
 const queueIds=new Set(),reservedRoads=new Set();for(const q of t.queue){
  if(!int(q.id,1,t.nextId-1)||queueIds.has(q.id)||!['build','upgrade','move','demolish','road','craft'].includes(q.type)||!Number.isFinite(q.work)||q.work<=0||!Number.isFinite(q.progress)||q.progress<0||q.progress>=q.work||!q.cost||Object.entries(q.cost).some(([k,n])=>!['wood','medicine','records'].includes(k)||!int(n)))return false;queueIds.add(q.id);
  if(['upgrade','move','demolish'].includes(q.type)&&!ids.has(q.buildingId))return false;
  if(['build','move'].includes(q.type)){const own=q.type==='move'?new Set(footprint(t.buildings.find(b=>b.id===q.buildingId)).map(p=>key(p.x,p.y))):new Set();if(!Object.hasOwn(buildingDefs,q.kind)||!int(q.rotation,0,1)||!footprint(q).every(p=>terrainOK(p.x,p.y)&&(!occupied.has(key(p.x,p.y))||own.has(key(p.x,p.y)))&&!roads.has(key(p.x,p.y))&&!reservedRoads.has(key(p.x,p.y))))return false;for(const p of footprint(q))occupied.add(key(p.x,p.y));}
  if(q.type==='road'&&(!Array.isArray(q.cells)||q.cells.length<1||q.cells.length>40||!['dirt','paved','remove'].includes(q.roadKind)||q.cells.some(p=>!terrainOK(p.x,p.y)||occupied.has(key(p.x,p.y)))))return false;
  if(q.type==='craft'&&!equipment[q.item]?.cost)return false;
  const b=t.buildings.find(b=>b.id===q.buildingId);
  if(['upgrade','demolish','move'].includes(q.type)&&q.kind!==b.kind)return false;
  if(['build','upgrade','demolish'].includes(q.type)&&!facilityIds.includes(q.kind))return false;
  if(q.type==='build'&&(g.facilities[q.kind]!==0||t.queue.filter(p=>p.type==='build'&&p.kind===q.kind).length!==1))return false;
  if(q.type==='upgrade'&&b.level>=3)return false;
  const expected=q.type==='build'?buildingDefs[q.kind].cost:q.type==='upgrade'?{wood:18*b.level,...(b.level>=2?{records:1}:{})}:q.type==='move'?{wood:4}:q.type==='craft'?equipment[q.item].cost:q.type==='road'&&q.roadKind==='paved'?{wood:q.cells.length}:{};
  const expectedWork=q.type==='build'?buildingDefs[q.kind].work:q.type==='upgrade'?40+20*b.level:q.type==='move'?25:q.type==='demolish'?20:q.type==='craft'?24:q.cells.length*(q.roadKind==='paved'?4:2);
  if(q.work!==expectedWork||Object.keys(q.cost).length!==Object.keys(expected).length||Object.entries(expected).some(([k,n])=>q.cost[k]!==n))return false;
  if(q.cells){if(new Set(q.cells.map(p=>key(p.x,p.y))).size!==q.cells.length||q.cells.some(p=>reservedRoads.has(key(p.x,p.y))))return false;for(const p of q.cells)reservedRoads.add(key(p.x,p.y));}
 }
 return ['balanced','build','recover'].includes(g.operatingPolicy)&&g.residents.every(r=>(r.manualRole===undefined||typeof r.manualRole==='boolean')&&(r.workRole===undefined||['농사','건설','치료','휴식','배움','가르침','교류'].includes(r.workRole))&&(r.workLabel===undefined||['농사','건설','치료','휴식','배움','가르침','교류','야외 채집','자재 수집','장비 제작','공사'].includes(r.workLabel)))&&g.residents.every(r=>!r.motion||Number.isFinite(r.motion.x)&&Number.isFinite(r.motion.y)&&r.motion.x>=0&&r.motion.x<28&&r.motion.y>=0&&r.motion.y<16&&Array.isArray(r.motion.path)&&r.motion.path.length<=448&&r.motion.path.every(p=>terrainOK(p.x,p.y))&&typeof r.motion.target==='string'&&/^\d+,\d+$/.test(r.motion.target)&&Number.isInteger(r.motion.revision)&&r.motion.revision>=-1&&r.motion.revision<=t.revision&&typeof r.motion.arrived==='boolean'&&(!r.workRole||['농사','건설','치료','휴식','배움','가르침','교류'].includes(r.workRole)));
}

export function spawnResidents(g){for(const r of g.residents){if(r.motion)continue;const p=g.town.legacy?workTarget(g,r,r.job):{x:13+r.id%4,y:9};r.motion={...p,path:[],target:key(p.x,p.y),revision:g.town.revision,arrived:true,prevX:p.x,prevY:p.y};}}
