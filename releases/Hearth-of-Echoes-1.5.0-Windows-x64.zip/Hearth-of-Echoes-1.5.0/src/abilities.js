export const abilityDefs={cultivation:{name:'재배·채집',group:'생활',role:'농사'},construction:{name:'건설·제작',group:'생활',role:'건설'},medicine:{name:'의술',group:'생활',role:'치료'},education:{name:'연구·교육',group:'생활',role:'배움'},social:{name:'사교',group:'생활',role:'교류'},melee:{name:'근접',group:'원정'},ranged:{name:'사격',group:'원정'},defense:{name:'방어',group:'원정'},scouting:{name:'정찰',group:'원정'},will:{name:'의지',group:'원정'}};
export const traitDefs={
 deft:{name:'손재주',text:'건설·제작 효율 +12% / 근접 공격 -5%',work:{construction:1.12},attack:{melee:.95}},
 green:{name:'푸른 손',text:'재배·채집 효율 +15% / 사격 공격 -6%',work:{cultivation:1.15},attack:{ranged:.94}},
 healer:{name:'돌보는 손',text:'의술 효율 +15% / 건설 효율 -6%',work:{medicine:1.15,construction:.94}},
 scholar:{name:'학구적',text:'연구·교육 효율 +18% / 재배 효율 -6%',work:{education:1.18,cultivation:.94}},
 friendly:{name:'붙임성',text:'실제 위로 효과 +18% / 방어 기술 효율 -6%',work:{social:1.18,defense:.94}},
 hardy:{name:'튼튼한 몸',text:'받는 전투 피해 -10% / 분야 경험 획득 -10%',damage:.9,learning:.9},
 steady:{name:'평정심',text:'받는 전투 스트레스 -15% / 근접 공격 -5%',stress:.85,attack:{melee:.95}},
 swift:{name:'가벼운 발',text:'실제 이동 속도 +12% / 받는 전투 피해 +8%',travel:1.12,damage:1.08},
 marksman:{name:'정밀한 조준',text:'사격 공격 +12% / 근접 공격 -8%',attack:{ranged:1.12,melee:.92},excludes:'brawler'},
 brawler:{name:'근접 감각',text:'근접 공격 +12% / 사격 공격 -8%',attack:{melee:1.12,ranged:.92},excludes:'marksman'},
 lightSleep:{name:'얕은 잠',text:'정찰 효율 +15% / 휴식 피로 회복 -15%',work:{scouting:1.15},rest:.85},
 shy:{name:'낯가림',text:'연구·교육 효율 +12% / 실제 위로 효과 -15%',work:{education:1.12,social:.85},excludes:'friendly'},
};
export const masteryDefs=Object.fromEntries(Object.entries(abilityDefs).map(([key,d])=>[key,{name:d.name+' 전문',text:d.name+' 분야 효과 +10% · 해당 분야 경험 +15%'}]));
const keys=Object.keys(abilityDefs),traitKeys=Object.keys(traitDefs),clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
function random(seed){let state=seed>>>0;return ()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};}
export const experienceNeeded=level=>600+level*300;
export function createProfile(seed,id,r,{child=false}={}){
 const rng=random((seed^Math.imul(id+1,2246822519))>>>0),levels={},aptitudes={},xp={};
 for(const key of keys){levels[key]=child?Math.floor(rng()*2):clamp(Math.floor(r.skill||2)+Math.floor(rng()*4)-1,1,6);aptitudes[key]=Math.floor(rng()*3);xp[key]=0;}
 const strength={farmer:'cultivation',carpenter:'construction',herbalist:'medicine',keeper:'social'}[r.background]||keys[id%keys.length];if(!child)levels[strength]=Math.max(5,levels[strength]);aptitudes[strength]=2;
 const traits=[];while(traits.length<2){const key=traitKeys[Math.floor(rng()*traitKeys.length)];if(!traits.includes(key)&&traits.every(t=>traitDefs[t].excludes!==key&&traitDefs[key].excludes!==t))traits.push(key);}
 return {version:1,levels,xp,aptitudes,traits,mastery:null,legacySkill:0,legacyFields:[]};
}
export function validProfile(p){return !!p&&p.version===1&&keys.every(key=>Number.isInteger(p.levels?.[key])&&p.levels[key]>=0&&p.levels[key]<=10&&Number.isFinite(p.xp?.[key])&&p.xp[key]>=0&&p.xp[key]<experienceNeeded(p.levels[key])&&Number.isInteger(p.aptitudes?.[key])&&p.aptitudes[key]>=0&&p.aptitudes[key]<=2)&&[p.levels,p.xp,p.aptitudes].every(v=>v&&Object.keys(v).length===10)&&Array.isArray(p.traits)&&p.traits.length===2&&new Set(p.traits).size===2&&p.traits.every(t=>Object.hasOwn(traitDefs,t)&&!p.traits.includes(traitDefs[t].excludes))&&Number.isFinite(p.legacySkill??0)&&(p.legacySkill??0)>=0&&(p.legacySkill??0)<=14&&Array.isArray(p.legacyFields||[])&&(p.legacyFields||[]).every(k=>keys.includes(k))&&(p.mastery===null||Object.hasOwn(masteryDefs,p.mastery)&&p.levels[p.mastery]>=6);}
export const abilitiesActive=g=>g.campaign?.mode==='settlement';
export function traitFactor(r,kind,key=null){let value=1;for(const id of r.profile?.traits||[]){const def=traitDefs[id];value*=key?(def[kind]?.[key]||1):(def[kind]||1);}return clamp(value,.7,1.4);}
export function fieldLevel(g,r,key){return abilitiesActive(g)?r.profile.levels[key]:r.skill;}
export function fieldSkill(g,r,key){if(!abilitiesActive(g))return r.skill;return Math.max(1.5+.75*r.profile.levels[key],r.profile.legacyFields?.includes(key)?r.profile.legacySkill:0);}
export function fieldFactor(g,r,key){return !abilitiesActive(g)?1:traitFactor(r,'work',key)*(r.profile.mastery===key?1.1:1);}
export function practice(g,r,key,amount=1){
 if(!abilitiesActive(g)||!r.alive||r.age<6||!Object.hasOwn(abilityDefs,key)||!Number.isFinite(amount)||amount<=0)return false;
 const p=r.profile;if(p.levels[key]>=10){p.xp[key]=0;return false;}p.xp[key]+=Math.min(30,amount)*(g.facilities?.school&&g.development?.specializations.school==='apprentice'&&!g.expedition?.team.includes(r.id)?1.15:1)*(g.development?.projects.includes('archive')&&['scouting','will'].includes(key)?1.15:1)*(1+p.aptitudes[key]*.3)*traitFactor(r,'learning')*(p.mastery===key?1.15:1);let gained=false;
 while(p.levels[key]<10&&p.xp[key]>=experienceNeeded(p.levels[key])){p.xp[key]-=experienceNeeded(p.levels[key]);p.levels[key]++;gained=true;}
 if(p.levels[key]===10)p.xp[key]=0;return gained;
}
export function chooseMastery(g,id,key){const r=g.residents[id];if(!abilitiesActive(g)||g.event||g.crisis.ready||g.gameOver||g.expedition?.team.includes(id)||!r?.alive||r.age<16||r.profile.mastery!==null||!Object.hasOwn(masteryDefs,key)||r.profile.levels[key]<6)return false;r.profile.mastery=key;return true;}
export function strengths(r){return Object.entries(r.profile.levels).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));}

export function preserveExperience(r){const work={농사:'cultivation',건설:'construction',치료:'medicine',배움:'education',가르침:'education',교류:'social'}[r.job],combat={guardian:'melee',ranger:'ranged',healer:'medicine',scout:'scouting'}[r.combatClass];r.profile.legacySkill=Math.max(r.profile.legacySkill||0,Math.min(14,r.skill));r.profile.legacyFields=[...new Set([...(r.profile.legacyFields||[]),work,combat,...(r.combatClass==='guardian'?['defense']:[])].filter(Boolean))];}
export function scoutingCover(g,team){return !abilitiesActive(g)?0:Math.min(.08,Math.max(...team.map(id=>fieldSkill(g,g.residents[id],'scouting')*fieldFactor(g,g.residents[id],'scouting')))*.008);}
export function rewardPractice(g,r,key,amount=180){for(let remaining=Math.max(0,Math.min(600,amount));remaining>0;remaining-=30)practice(g,r,key,Math.min(30,remaining));}
export const roleField=role=>({농사:'cultivation',건설:'construction',치료:'medicine',배움:'education',가르침:'education',교류:'social',휴식:'education'}[role]||'education');
