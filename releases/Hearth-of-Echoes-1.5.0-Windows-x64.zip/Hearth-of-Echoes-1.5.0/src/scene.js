import {terrainAt} from './terrain.js';
import {wrapText} from './map-camera.js';
import {effectiveRole} from './settlement.js';
import {away} from './game.js';
import {GRID,buildingDefs,sizeOf,entryOf,footprint,placementStatus,roadStatus} from './town.js';
import {appearance,appearanceChoices,drawHead} from './appearance.js';
export const colors=appearanceChoices.coat;
const cache=new Map(),townIds=new WeakMap(),C=GRID.cell;let nextTownId=1;
function primitives(c){return {
 rect:(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);},
 ellipse:(x,y,rx,ry,color)=>{c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fill();},
 line:(x,y,tx,ty,color,width=2)=>{c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.beginPath();c.moveTo(x,y);c.lineTo(tx,ty);c.stroke();},
 polygon:(points,color)=>{c.fillStyle=color;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fill();},
};}
function drawBuilding(c,b){
 const {rect,ellipse,line,polygon}=primitives(c),{w:gw,h:gh}=sizeOf(b),x=b.x*C+5,y=b.y*C+8,w=gw*C-10,h=gh*C-16;
 ellipse(x+w/2+6,y+h+4,w*.5,10,'#324c3433');
 if(b.kind==='fire'){for(let i=0;i<9;i++){const a=i/9*Math.PI*2;ellipse(x+15+Math.cos(a)*15,y+15+Math.sin(a)*9,5,4,'#c6c09e');}line(x+4,y+16,x+25,y+6,'#74573f',5);return;}
 if(b.kind==='tent'){polygon([[x-4,y+h],[x+w*.55,y-3],[x+w+4,y+h]],'#b6ad7e');polygon([[x+w*.55,y-3],[x+w*.55,y+h],[x+w+4,y+h]],'#87967b');polygon([[x+w*.55,y+15],[x+w*.55-18,y+h],[x+w*.55+18,y+h]],'#536450');line(x-4,y+h,x+w+4,y+h,'#d4c89f',3);return;}
 if(b.kind==='table'){rect(x+8,y+16,w-16,12,'#a68b5e');rect(x+14,y+28,7,14,'#7c6a4a');rect(x+w-22,y+28,7,14,'#7c6a4a');ellipse(x+33,y+17,8,4,'#c8c4a0');rect(x+6,y+3,w-12,6,'#8f7955');return;}
 if(b.kind==='crate'){rect(x+4,y+3,w-8,h,'#9e8155');line(x+4,y+3,x+w-4,y+h,'#c5ad7b',4);line(x+w-4,y+3,x+4,y+h,'#c5ad7b',4);return;}
 if(b.kind==='farm'){
  rect(x,y,w,h,'#7f7150');for(let row=0;row<4;row++)for(let col=0;col<6;col++){const px=x+12+col*(w-20)/6,py=y+14+row*(h-16)/4;rect(px-3,py+2,12,7,'#947a50');ellipse(px+3,py-2,5,8,b.level>1?'#b6c67b':'#91ac69');line(px+3,py-9,px+3,py+5,'#d1d6a0',1.5);}line(x,y+h,x+w,y+h,'#c9b384',4);return;
 }
 const roofs={workshop:'#7c8e89',clinic:'#7e9a85',dorm:'#af9672',lounge:'#9e7a61',school:'#789e99'};
 rect(x,y,w,h,'#a79874');rect(x+4,y+2,w-8,h-2,'#d2bd96');for(let i=x+12;i<x+w-4;i+=17)rect(i,y+8,1,h-12,'#b9a67e');
 polygon([[x-7,y+5],[x+w/2,y-28],[x+w+7,y+5]],roofs[b.kind]);line(x-7,y+5,x+w+7,y+5,'#d8c8a3',4);
 for(const wx of [x+14,x+w-35]){rect(wx-2,y+29,24,23,'#a59772');rect(wx,y+31,20,18,'#78978d');line(wx+10,y+31,wx+10,y+49,'#ded3b2',2);}
 if(b.rotation%2){rect(x+w-17,y+h/2-10,17,27,'#796b4b');}else{rect(x+w/2-12,y+h-29,24,29,'#796b4b');rect(x+w/2-9,y+h-26,18,26,'#9c8960');}
 if(b.kind==='clinic'){rect(x+w/2-5,y+21,10,25,'#e8e4bf');rect(x+w/2-12,y+28,24,10,'#e8e4bf');}
 if(b.kind==='workshop'){rect(x+12,y-20,15,26,'#788477');rect(x+8,y-23,23,5,'#b1b59d');}
 if(b.kind==='school'){rect(x+w/2-15,y+28,30,23,'#78906e');line(x+w/2,y+30,x+w/2,y+48,'#e2d9aa',2);}
 if(b.level>1){rect(x+w-13,y-20,2,27,'#6e7055');polygon([[x+w-11,y-19],[x+w+9,y-13],[x+w-11,y-6]],b.level===3?'#d9c786':'#b7cd8b');}
}
function background(g){
 if(!townIds.has(g.town))townIds.set(g.town,nextTownId++);const key=[townIds.get(g.town),g.world,g.level,g.town.revision].join(':');if(cache.has(key))return cache.get(key);
 const canvas=document.createElement('canvas');canvas.width=1120;canvas.height=650;const c=canvas.getContext('2d'),{rect,ellipse,line}=primitives(c);
 let seed=17+g.world*97;const rnd=()=>{seed=seed*16807%2147483647;return seed/2147483647;};
 rect(0,0,1120,650,['#8b9a77','#9a9578','#81998c'][g.world]);for(let i=0;i<1500;i++)rect(rnd()*1120,rnd()*650,2+rnd()*3,1+rnd()*2,['#758b6c','#9fa980','#bac493'][i%3]);
 if(!g.town.terrain){
 ellipse(1010,180,94,84,'#739484');ellipse(1010,178,79,68,'#8fb4a7');ellipse(1010,173,60,52,'#a0c1b0');for(let i=0;i<15;i++)line(965+rnd()*90,130+rnd()*90,980+rnd()*75,140+rnd()*80,'#c2d4bc',1);
 for(let i=0;i<70;i++){const x=rnd()*1120,y=rnd()*650;if(x>45&&x<1080&&y>42&&y<600)continue;ellipse(x+8,y+18,28,13,'#294c3433');rect(x-4,y-8,8,30,'#73684a');ellipse(x,y-13,25,30,'#577753');ellipse(x-10,y-23,17,22,'#718f60');ellipse(x+8,y-31,16,20,'#8da873');}
 }else{
  for(let y=0;y<16;y++)for(let x=0;x<28;x++){const kind=terrainAt(g.town,x,y),cx=x*C+20,cy=y*C+20;if(kind==='water'){rect(x*C,y*C,C,C,'#7caaa2');ellipse(cx,cy,19,15,'#90b5aa');line(cx-10,cy,cx+10,cy,'#b1d0be',1);}else if(kind==='rock'){ellipse(cx+2,cy+7,18,13,'#4d625547');ellipse(cx,cy,17,16,'#7a8172');ellipse(cx-4,cy-5,9,7,'#a2a794');}else if(kind==='grove'){rect(cx-2,cy,4,15,'#776e4d');ellipse(cx,cy-4,13,16,'#527850');ellipse(cx-4,cy-11,9,10,'#78965e');}else if(kind==='ruin'){rect(cx-13,cy+2,24,9,'#8a8167');rect(cx-8,cy-5,12,11,'#ada183');line(cx-13,cy+13,cx+13,cy+13,'#6b7858',2);}if(!g.town.expanded&&(x===0||x===27||y===0||y===15)){rect(x*C,y*C,C,C,'#132b2455');line(x*C,y*C+35,x*C+35,y*C,'#b5c28e44',1);}}
 }
 for(const p of g.town.roads){rect(p.x*C+1,p.y*C+1,C-2,C-2,p.kind==='paved'?'#a8aaa0':'#bcb08e');if(p.kind==='paved'){line(p.x*C+3,p.y*C+19,p.x*C+36,p.y*C+19,'#889688',1);line(p.x*C+20,p.y*C+2,p.x*C+20,p.y*C+36,'#889688',1);}}
 for(const b of [...g.town.buildings].sort((a,b)=>a.y-b.y))drawBuilding(c,b);
 for(let i=0;i<Math.max(0,g.level-1);i++){rect(445+i*26,543,21,32,'#778b77');rect(448+i*26,540,15,8,'#c5b997');}
 cache.set(key,canvas);if(cache.size>4)cache.delete(cache.keys().next().value);return canvas;
}
export function buildingAt(g,x,y){const gx=Math.floor(x/C),gy=Math.floor(y/C);return [...g.town.buildings].reverse().find(b=>footprint(b).some(p=>p.x===gx&&p.y===gy));}
export function drawWorld(g,selected,options={}){
 const canvas=document.querySelector('#world');if(!canvas)return [];const c=canvas.getContext('2d'),{rect,ellipse,line,polygon}=primitives(c),motion=options.motion!==false,time=options.visualTime??g.time,ambient=motion?(options.ambientTime??time):0;
 c.clearRect(0,0,1120,650);const camera=options.camera||{zoom:1,x:0,y:0};c.save();c.translate(camera.x,camera.y);c.scale(camera.zoom,camera.zoom);c.drawImage(background(g),0,0);const positions=[],labels=[],uiScale=1120/Math.max(1,canvas.getBoundingClientRect().width);
 for(const q of g.town.queue){if(['build','move'].includes(q.type)){const b={kind:q.kind,x:q.x,y:q.y,rotation:q.rotation},{w,h}=sizeOf(b);rect(b.x*C,b.y*C,w*C,h*C,'#c2d5aa33');c.strokeStyle='#e0ddad';c.lineWidth=2;c.setLineDash([7,5]);c.strokeRect(b.x*C+2,b.y*C+2,w*C-4,h*C-4);c.setLineDash([]);line(b.x*C,b.y*C+h*C,b.x*C+w*C,b.y*C,'#d8d4a199',2);rect(b.x*C,b.y*C+h*C-6,w*C*q.progress/q.work,6,'#d2dd9b');}if(q.type==='road')for(const p of q.cells)rect(p.x*C+3,p.y*C+3,C-6,C-6,q.roadKind==='remove'?'#b9816866':'#d3c69566');}
 for(const [index,r] of g.residents.filter(r=>r.alive).entries()){
  if(away(g,r.id))continue;const role=effectiveRole(r),m=r.motion,t=time*.9+r.id*1.7;let gx=m?.x??14+(index%2)*.3,gy=m?.y??9+Math.floor(index%4/2)*.3;
  const pose=options.poses?.get(r.id);if(pose){gx=pose.x;gy=pose.y;}
  const x=(gx+.5)*C+((r.id%3)-1)*10,y=(gy+.5)*C+Math.floor(r.id%6/3)*12;positions.push({id:r.id,x,y});labels.push({name:r.name,x,y,walking:m&&!m.arrived});
  c.save();c.translate(x,y);const scale=r.age<6?.6:r.age<16?.8:1;c.scale(scale,scale);ellipse(2,14,14,6,'#253e3b40');if(selected===r.id){c.strokeStyle='#f3dfa2';c.lineWidth=2;c.beginPath();c.ellipse(0,13,18,8,0,0,Math.PI*2);c.stroke();}
  const step=motion?Math.sin(t*3)*(m&&!m.arrived?3:1):0;rect(-7,7,5,8+step,'#46534a');rect(3,7,5,8-step,'#46534a');
  c.fillStyle=appearanceChoices.coat[appearance(r).coat];c.beginPath();c.roundRect(-11,-7,22,21,[8,8,4,4]);c.fill();rect(-2,-3,4,15,'#d5cca6');
  c.save();c.translate(-10,-25);c.scale(.34,.34);drawHead(c,r);c.restore();const swing=motion?Math.sin(t*2.5)*3:0;
  if(role==='건설'){line(10,2,19,-6+swing,'#9e855e',3);rect(15,-12+swing,12,5,'#b8c3ab');}if(role==='농사'){rect(8,2,14,10,'#ac8b58');ellipse(12,1,4,4,'#adc277');ellipse(18,1,4,4,'#c3cf91');}
  if(role==='치료'){rect(8,1,13,11,'#d9ddbf');line(14,3,14,10,'#678b70',2);line(11,6,17,6,'#678b70',2);}if(role==='배움'||role==='가르침'){rect(7,0,16,10,'#b9c297');line(15,1,15,9,'#718668',1);}if(role==='휴식'&&(!m||m.arrived)){c.fillStyle='#e8edcb';c.font='10px system-ui';c.fillText('z',14,-25-(motion?Math.sin(t)*2:0));}c.restore();
 }
 const night=options.weather===false?0:Math.max(0,Math.cos(((g.time%60)/60-.8)*Math.PI*2))*(options.contrast ? .22 : .40);
 if(night){rect(0,0,1120,650,`rgba(23,38,59,${night})`);for(const b of g.town.buildings.filter(b=>['clinic','workshop','dorm','lounge','school'].includes(b.kind))){const {w}=sizeOf(b);for(const wx of [b.x*C+28,(b.x+w)*C-29]){const wy=b.y*C+47,glow=c.createRadialGradient(wx,wy,1,wx,wy,42);glow.addColorStop(0,'#eed09155');glow.addColorStop(1,'#eed09100');c.fillStyle=glow;c.fillRect(wx-42,wy-42,84,84);rect(wx-7,wy-7,15,13,'#e5cc92');}}}
 const fire=c.createRadialGradient(580,336,2,580,336,72);fire.addColorStop(0,'#edbf7155');fire.addColorStop(1,'#edbf7000');c.fillStyle=fire;c.fillRect(506,262,148,148);const flicker=motion?Math.sin(ambient*8)*2:0;ellipse(580,335,8+flicker*.4,14+flicker,'#db9e55');ellipse(581,338,4,9,'#f6dd95');
 if(motion)for(let i=0;i<5;i++){const phase=(ambient*.45+i*.2)%1;ellipse(580+Math.sin(i+phase*8)*10,329-phase*37,1,2,`rgba(246,214,130,${1-phase})`);}
 if(options.weather!==false){if(g.crisis.kind==='winter'&&g.crisis.warned){for(let i=0;i<70;i++)ellipse((i*97+ambient*13)%1120,(i*53+ambient*21)%650,1.5,2,'#e3ead4aa');}else if(g.world===2){c.globalAlpha=.07;for(let i=0;i<5;i++)ellipse((i*270+ambient*8)%1400-100,220+i*65,240,26,'#d5e4d8');c.globalAlpha=1;}else for(let i=0;i<13;i++)ellipse((i*87+ambient*5)%1120,70+(i*43)%500+Math.sin(ambient*.7+i)*4,1,1,'#e0db9b66');}
 const p=options.placement;if(p){c.strokeStyle='#e3ead92a';c.lineWidth=1;for(let x=0;x<=28;x++)line(x*C,0,x*C,640,'#eef1d826',1);for(let y=0;y<=16;y++)line(0,y*C,1120,y*C,'#eef1d826',1);
  if(p.type==='road'&&p.cells){const valid=roadStatus(g,p.cells,p.roadKind).ok;for(const a of p.cells)rect(a.x*C+2,a.y*C+2,C-4,C-4,valid?'#b5e19a88':'#df9e7c88');}
  else if(p.x!==undefined){const valid=placementStatus(g,p.kind,p.x,p.y,p.rotation||0,p.buildingId||null).ok,{w,h}=sizeOf(p);rect(p.x*C,p.y*C,w*C,h*C,valid?'#b5e19a88':'#df9e7c88');c.strokeStyle=valid?'#e0edbb':'#f3c6a0';c.lineWidth=3;c.strokeRect(p.x*C,p.y*C,w*C,h*C);const e=entryOf(p);polygon([[(e.x+.5)*C,(e.y+.2)*C],[(e.x+.2)*C,(e.y+.7)*C],[(e.x+.8)*C,(e.y+.7)*C]],'#f4ecc3');}
 }
 if(options.showPaths!==false){const r=g.residents.find(r=>r.id===selected&&r.alive&&!away(g,r.id)),start=positions.find(p=>p.id===selected);if(r?.motion?.path.length&&start){c.strokeStyle='#f2df9c';c.lineWidth=2/camera.zoom;c.setLineDash([5/camera.zoom,5/camera.zoom]);c.beginPath();c.moveTo(start.x,start.y);for(const point of r.motion.path)c.lineTo((point.x+.5)*C,(point.y+.5)*C);c.stroke();c.setLineDash([]);}}
 c.restore();
 const screen=(x,y)=>({x:x*camera.zoom+camera.x,y:y*camera.zoom+camera.y});
 if(options.labels!==false){const caption=(text,x,y)=>{c.font='11px system-ui';c.textAlign='center';const width=c.measureText(text).width;rect(x-width/2-7,y-12,width+14,20,'#20362ce8');c.fillStyle='#edf0d4';c.fillText(text,x,y+1);};for(const b of g.town.buildings.filter(b=>b.kind!=='fire')){const {w,h}=sizeOf(b);const point=screen((b.x+w/2)*C,(b.y+h)*C);caption(`${buildingDefs[b.kind].name}${g.facilities[b.kind]?' Lv.'+b.level:''}`,point.x,point.y+13);}for(const r of labels){const point=screen(r.x,r.y);caption((r.walking?'↝ ':'')+r.name,point.x,point.y+30);}}
 if(options.bubbles!==false&&!p){const boxes=[];for(const bubble of options.dialogue||[]){const person=positions.find(r=>r.id===bubble.who);if(!person)continue;const point=screen(person.x,person.y);if(point.x<0||point.x>1120||point.y<0||point.y>650)continue;c.font=(14*uiScale)+'px system-ui';c.textAlign='left';const textWidth=Math.min(290*uiScale,1080-24*uiScale),lines=wrapText(text=>c.measureText(text).width,bubble.text,textWidth),width=textWidth+24*uiScale,height=(lines.length*23+24)*uiScale,x=Math.max(8,Math.min(1112-width,point.x-width/2));let y=point.y-height-39;if(y<8)y=point.y+38;y=Math.max(8,Math.min(642-height,y));for(const box of boxes)if(x<box.x+box.width&&x+width>box.x&&y<box.y+box.height&&y+height>box.y)y=Math.max(8,box.y-height-12);c.fillStyle='#f1edd9';c.strokeStyle='#8a9a73';c.lineWidth=1;c.beginPath();c.roundRect(x,y,width,height,9);c.fill();c.stroke();line(Math.max(x+12,Math.min(x+width-12,point.x)),y+(y>point.y?0:height),point.x,point.y-22,'#f1edd9',3);c.fillStyle='#263d33';lines.forEach((text,i)=>c.fillText(text,x+12*uiScale,y+(25+i*23)*uiScale));boxes.push({x,y,width,height});}if(options.bubbleBoxes)options.bubbleBoxes.push(...boxes);}

 return positions;
}
