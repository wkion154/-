export const crisisTypes={
  winter:{name:'긴 백야의 겨울',description:'강과 길이 얼어붙기 전에 먹을 것과 튼튼한 지붕을 준비해야 합니다.',required:10,weights:{supplies:2,shelter:2,medicine:1,scouting:1},facilities:{dorm:1,farm:1}},
  blight:{name:'재빛 곰팡이',description:'저장고와 식수에 병해가 번집니다. 의약품과 사전 조사가 공동체를 지킵니다.',required:12,weights:{supplies:2,shelter:1,medicine:3,scouting:2},facilities:{clinic:2,farm:1}},
  siege:{name:'안개 속의 포위',description:'안개 속에서 다가오는 무리를 막아야 합니다. 방비와 정보가 중요합니다.',required:13,weights:{supplies:1,shelter:3,medicine:1,scouting:3},facilities:{workshop:2,lounge:1}},
};
export const preparationTypes={
  supplies:{name:'식량 비축',cost:{food:20}},shelter:{name:'방비 보강',cost:{wood:20}},
  medicine:{name:'구호 물자',cost:{medicine:3}},scouting:{name:'사전 조사',cost:{records:1}},
};
export const endingTypes={
  beacon:{title:'불씨를 지킨 사람들',success:true,description:'성소를 밝히고 다가온 위기를 견뎠습니다. 남겨진 지식이 다음 터전의 길잡이가 됩니다.',gift:'다음 터전 기록 +2'},
  shelter:{title:'서로의 지붕',success:true,description:'거대한 승전 대신 일상의 준비로 위기를 견뎠습니다. 사람들을 먹이고 쉬게 할 곳을 지켜냈습니다.',gift:'다음 터전 식량 +15'},
  pilgrimage:{title:'성소 너머의 새벽',success:true,description:'성소의 종을 울린 사람들은 위기가 닥치기 전에 다음 터전으로 불씨를 옮겼습니다.',gift:'생산 계승 보너스 +5%'},
  evacuation:{title:'불씨를 품고 떠난 사람들',success:false,description:'이 터전을 떠나기로 했습니다. 지붕은 남겨 두지만 살아온 이야기와 사람의 경험은 이어집니다.',gift:'기록과 선택한 주민 보존 · 승리 보너스 없음'},
  ruin:{title:'지키지 못한 터전',success:false,description:'준비가 부족해 방어선이 무너졌습니다. 다친 주민들과 기록을 챙겨 새로운 시작을 준비합니다.',gift:'기록과 선택한 주민 보존 · 승리 보너스 없음'},
  lastLight:{title:'마지막 불빛',success:false,description:'마지막 주민의 삶도 끝났습니다. 이곳에서 살아간 사람들의 기록으로 새로운 공동체를 시작할 수 있습니다.',gift:'공동체 기록 보존 · 새 주민 여섯 명으로 시작'},
};
export function createCrisis(world,start=0){
  return {kind:['winter','blight','siege'][world],startedAt:start,deadline:start+1800,warned:0,ready:false,resolved:false,sandbox:false,
    preparations:{supplies:0,shelter:0,medicine:0,scouting:0}};
}
export function journeyFrozen(g){return Boolean(g.gameOver||g.crisis?.ready||g.ending&&!g.crisis.sandbox);}
export function crisisReadiness(g){
  const def=crisisTypes[g.crisis.kind],checks=[];
  for(const [id,weight] of Object.entries(def.weights))checks.push({label:preparationTypes[id].name,points:g.crisis.preparations[id]*weight});
  for(const [id,weight] of Object.entries(def.facilities))checks.push({label:{dorm:'숙소 개선',farm:'밭 개선',clinic:'의무실 개선',workshop:'작업장 개선',lounge:'공동 식당 개선'}[id],points:(g.facilities[id]-1)*weight});
  checks.push({label:'피난처 확장',points:g.level>=2?1:0},{label:'성소의 불빛',points:g.cleared?2:0});
  const required=def.required+Math.min(g.legacyPoints,3)*2;
  return {checks,score:checks.reduce((n,c)=>n+c.points,0),required};
}
export const EARLY_CRISIS_SECONDS=600;
export function crisisWait(g){return Math.max(0,g.crisis.startedAt+EARLY_CRISIS_SECONDS-g.time);}
export function canConfront(g){
  return !g.ending&&!g.gameOver&&!g.crisis.resolved&&!g.event&&!g.expedition&&(g.crisis.ready||crisisWait(g)===0&&(g.cleared||Object.values(g.crisis.preparations).reduce((n,v)=>n+v,0)>=2));
}
export function eligibleHeirs(g){const alive=g.residents.filter(r=>r.alive&&!r.farewellNoted),adults=alive.filter(r=>r.age>=16);return g.ending&&(!g.ending.success||!adults.length)?alive:adults;}
export function endingSnapshot(g){
  return {population:g.residents.filter(r=>r.alive).length,children:g.residents.filter(r=>r.alive&&r.age<16).length,
    memorials:g.residents.filter(r=>!r.alive).length,expeditions:g.expeditions,
    goals:g.residents.reduce((n,r)=>n+r.completedGoals.length,0),
    stories:g.residents.slice(-12).map(r=>({id:r.id,name:r.name,age:r.age,generation:r.generation,alive:r.alive,memory:r.history[0]}))};
}
export function advanceCrisis(g,{log,retreat}){
  const c=g.crisis;if(c.resolved||c.ready||g.ending||g.gameOver)return;
  const left=c.deadline-g.time;
  const warning=left<=60?2:left<=600?1:0;
  if(warning>c.warned){c.warned=warning;log(g,`${crisisTypes[c.kind].name} · ${warning===2?'위기가 코앞에 닥쳤다.':'조짐이 뚜렷해졌다. 비축과 시설을 확인하자.'}`,'story');}
  if(left<=0){c.ready=true;if(g.expedition)retreat(g,'다가온 위기에 대응하기 위해 귀환');log(g,`${crisisTypes[c.kind].name}가 닥쳤다. 시간은 최종 결정을 기다린다.`,'story');}
}
export function validateJourney(g,{finite,int,validId}){
  const c=g.crisis;if(!c||!Object.hasOwn(crisisTypes,c.kind)||c.kind!==['winter','blight','siege'][g.world]
    ||!finite(c.startedAt)||c.startedAt>g.time||!finite(c.deadline)||c.deadline!==c.startedAt+1800||!int(c.warned,0,2)
    ||['ready','resolved','sandbox'].some(k=>typeof c[k]!=='boolean')
    ||!c.preparations||Object.keys(c.preparations).length!==4||Object.keys(preparationTypes).some(k=>!int(c.preparations[k],0,3))
    ||(g.gameOver&&!g.ending)||(c.ready&&Boolean(g.expedition))||c.ready&&c.resolved||c.sandbox&&(!c.resolved||!g.ending?.success)||c.resolved!==Boolean(g.ending))return false;
  if(g.ending){const e=g.ending,s=e.snapshot;
    if(!Object.hasOwn(endingTypes,e.kind)||e.success!==endingTypes[e.kind].success||!finite(e.at)||e.at>g.time
      ||!finite(e.score)||!int(e.required,1)||(['beacon','shelter'].includes(e.kind)&&e.score<e.required)||(e.kind==='ruin'&&e.score>=e.required)||!s||!int(s.population,0,12)||!int(s.children,0,12)||s.children>s.population
      ||!int(s.memorials,0,256)||!int(s.expeditions)||!int(s.goals)||!Array.isArray(s.stories)||s.stories.length>12
      ||s.stories.some(r=>!validId(r.id)||typeof r.name!=='string'||!int(r.age,0,200)||!int(r.generation,1)||typeof r.alive!=='boolean'||typeof r.memory!=='string'))return false;
  }else if(g.ending!==null)return false;
  return !g.legacy.some(j=>j.outcome!==undefined&&j.outcome!==null&&!Object.hasOwn(endingTypes,j.outcome));
}
