import {icon} from './ui-art.js';
import {facilities,facilityCost,goalTypes,activityLabel} from './settlement.js';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function needsPanel(g,r,away){
  if(!r.alive)return '';
  return `<section class="needs-panel"><div class="needs-heading"><strong>오늘의 생활</strong><small>${esc(activityLabel(r))}</small><button data-autonomy="${r.id}" class="${r.autonomy?'active':''}" ${away||g.event?'disabled':''}>${r.autonomy?'자율 휴식':'역할 고정'}</button></div>
    <div class="need-meters">${[['hunger','배고픔'],['fatigue','피로'],['loneliness','외로움']].map(([id,name])=>`<div><span>${name}<b>${Math.floor(r.needs[id])}</b></span><div class="bar need ${r.needs[id]>=70?'critical':''}"><i style="width:${r.needs[id]}%"></i></div></div>`).join('')}</div>
    <small class="needs-help">낮을수록 편안합니다. 피로 80부터 자율 휴식, 외로움 75부터 교류합니다. 피로·배고픔 85 이상이면 출정할 수 없습니다.</small></section>`;
}
export function goalPanel(g,r,away){
  const goal=r.personalGoal,def=goalTypes[goal.kind];
  return `<section class="goal-panel"><div><strong>${goal.done?'✧ 이룬 목표':'작은 바람'}</strong><span>${esc(def.name)}</span><small>${goal.done?'달성':`${Math.floor(goal.progress*10)/10} / ${def.target} ${def.unit}`}</small></div>
    <div class="bar"><i style="width:${goal.progress/def.target*100}%"></i></div><p>${def.description}</p>
    ${r.alive?`<label for="personal-goal">다음 목표</label><select id="personal-goal" ${away||g.event?'disabled':''}>${Object.entries(goalTypes).map(([id,type])=>`<option value="${id}" ${goal.kind===id?'selected':''} ${r.completedGoals.includes(id)?'disabled':''}>${type.name}${r.completedGoals.includes(id)?' ✓':''}</option>`).join('')}</select>
    <small>목표별 보상은 평생 한 번: 숙련 +1 · 스트레스 -12 · 기록 +1. 변경하면 미완료 진행은 초기화됩니다.</small>`:`<small>평생 이룬 목표 ${r.completedGoals.length}개</small>`}</section>`;
}
export function facilitiesContents(g){
  return `<small>사람들이 살아갈 조건</small><h2>시설과 공동체 생활</h2><p class="description">전체 확장은 주민 정원과 공통 효율을, 개별 시설은 특정 생활을 개선합니다. 각 시설은 3단계까지이며 다음 터전에서는 초기화됩니다.</p>
    <div class="facility-grid">${Object.entries(facilities).map(([id,def])=>{
      const level=g.facilities[id],cost=facilityCost(g,id),can=level<3&&!g.event&&!g.gameOver&&Object.entries(cost).every(([k,n])=>g[k]>=n);
      return `<article><div class="facility-icon">${icon(id)}</div><h3>${def.name} <span>Lv.${level}</span></h3><p>${def.bonus(level)}</p><small>${def.description}</small>
        <button data-facility="${id}" ${can?'':'disabled'}>${level===3?'개선 완료':`개선 · 자재 ${cost.wood}${cost.records?' · 기록 '+cost.records:''}`}</button></article>`;
    }).join('')}</div><div class="life-guidance"><h3>주민은 스스로 쉬고 다시 일합니다</h3><p>자율 휴식 중에도 지정 역할은 바뀌지 않습니다. 피로가 30 이하가 되면 복귀합니다. 교류는 외로움 35 이하까지 이어집니다. 반드시 역할을 유지해야 하는 주민은 상세 화면에서 자율 휴식을 끌 수 있습니다.</p><p>개인 목표와 후속 사건은 생애 기록에 남습니다. 한 번의 갈등이나 배움 지원이 이후의 이야기로 이어집니다.</p></div><button data-action="close-modal">피난처로 돌아가기</button>`;
}
