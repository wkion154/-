import {effectiveRole} from './settlement.js';
import {away} from './game.js';
export const colors=['#9caa74','#b68868','#7b9e9e','#bdad7d','#9a8ca6','#929fbb'];
const sites=[
 {id:'lounge',name:'공동 식당',x:220,y:132,w:180,h:100,roof:'#9a7960'},
 {id:'clinic',name:'의무실',x:650,y:130,w:170,h:104,roof:'#7d9481'},
 {id:'workshop',name:'작업장',x:218,y:440,w:185,h:94,roof:'#7e8b8b'},
 {id:'dorm',name:'숙소',x:660,y:440,w:180,h:100,roof:'#ac926d'},
 {id:'school',name:'배움터',x:875,y:442,w:122,h:90,roof:'#789491'},
];
const cache=new Map();
function primitives(c){return {
 rect:(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);},
 ellipse:(x,y,rx,ry,color)=>{c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fill();},
 line:(x,y,tx,ty,color,width=2)=>{c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.beginPath();c.moveTo(x,y);c.lineTo(tx,ty);c.stroke();},
 polygon:(points,color)=>{c.fillStyle=color;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fill();},
};}
function background(g){
 const key=[g.world,g.level,...Object.keys(g.facilities).sort().map(id=>g.facilities[id])].join(':');if(cache.has(key))return cache.get(key);
 const canvas=document.createElement('canvas');canvas.width=1120;canvas.height=650;
 const c=canvas.getContext('2d'),{rect,ellipse,line,polygon}=primitives(c);
 let seed=17+g.world*97;const rnd=()=>{seed=seed*16807%2147483647;return seed/2147483647;};
 rect(0,0,1120,650,['#869573','#969274','#7d9588'][g.world]);
 for(let i=0;i<1400;i++){const x=rnd()*1120,y=rnd()*650;rect(x,y,2+rnd()*3,1+rnd()*2,['#728769','#99a27e','#bac094'][i%3]);}
 ellipse(1004,223,85,65,'#6e897e');ellipse(1004,219,70,52,'#89a99f');ellipse(1004,215,57,39,'#94b5ab');
 for(let i=0;i<10;i++)line(963+rnd()*75,190+rnd()*55,980+rnd()*68,190+rnd()*55,'#b2c9b6',1);
 const path=(points,w)=>{c.strokeStyle='#b6ad8d';c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.stroke();};
 path([[148,353],[960,353]],44);path([[380,209],[380,570]],30);path([[732,212],[732,585]],30);path([[551,353],[551,650]],38);path([[919,353],[919,568]],23);
 for(let i=0;i<130;i++){const x=155+rnd()*790,y=342+rnd()*24;ellipse(x,y,1+rnd()*2,1,'#a2997d');}
 function tree(x,y,k){ellipse(x+10,y+21,31*k,13*k,'#294d3b24');rect(x-4*k,y-10*k,8*k,34*k,'#736b4c');ellipse(x,y-14*k,27*k,31*k,'#557553');ellipse(x-12*k,y-22*k,19*k,23*k,'#68865b');ellipse(x+9*k,y-33*k,18*k,23*k,'#7b9566');ellipse(x+5*k,y-38*k,11*k,13*k,'#91a678');}
 for(let i=0;i<60;i++){const x=rnd()*1120,y=rnd()*650;if(x>165&&x<1000&&y>75&&y<585)continue;if(x>920&&y>140&&y<300)continue;tree(x,y,.65+rnd()*.55);}
 for(const s of sites){
  const {x,y,w,h,roof,id}=s,level=g.facilities[id];
  ellipse(x+w/2+12,y+h+6,w*.6,18,'#344d3430');
  rect(x,y,w,h,'#8d8d71');rect(x+5,y+4,w-10,h-4,'#d2bd94');
  for(let a=x+14;a<x+w-5;a+=17)rect(a,y+8,1,h-14,'#baa67e');
  rect(x,y+h-8,w,8,'#a29474');
  polygon([[x-10,y+8],[x+w/2,y-39],[x+w+10,y+8]],roof);polygon([[x-10,y+8],[x+w/2,y-39],[x+w/2,y+8]],'#ffffff0c');
  line(x-10,y+8,x+w+10,y+8,'#d4c4a1',5);line(x-9,y+6,x+w/2,y-39,'#cab992',3);
  rect(x+w/2-14,y+h-34,28,34,'#6c6147');rect(x+w/2-10,y+h-30,20,30,'#8b7a54');ellipse(x+w/2+6,y+h-15,2,2,'#d3c391');
  for(const wx of [x+16,x+w-40]){rect(wx-3,y+34,29,27,'#ab9c77');rect(wx,y+37,23,20,'#6a8881');line(wx+11,y+37,wx+11,y+57,'#ded1a7',2);line(wx,y+46,wx+23,y+46,'#ded1a7',2);}
  if(id==='clinic'){rect(x+w/2-6,y+22,12,30,'#e4dfbd');rect(x+w/2-15,y+31,30,12,'#e4dfbd');}
  if(id==='workshop'){rect(x+12,y-26,18,33,'#777d70');rect(x+8,y-29,26,6,'#a4a58c');rect(x+15,y+h+10,48,14,'#806b4d');rect(x+50,y+h+5,25,14,'#a8ad99');}
  if(id==='school'){rect(x+w/2-18,y+31,36,24,'#72866c');line(x+w/2,y+34,x+w/2,y+51,'#d8d2a7',2);}
  if(level>1){rect(x+w-16,y-29,3,38,'#6c6651');polygon([[x+w-13,y-28],[x+w+10,y-22],[x+w-13,y-15]],level===3?'#d0bb76':'#b5c18c');}
 }
 rect(454,112,138,133,'#6d6549');
 for(let row=0;row<6;row++)for(let col=0;col<6;col++){const x=465+col*21,y=126+row*20;rect(x,y,13,7,'#8e7750');ellipse(x+6,y-3,5,8,g.facilities.farm>1?'#b2bd74':'#93ad68');line(x+6,y-11,x+6,y+1,'#c3ce8b',2);}
 for(let i=0;i<6;i++){rect(450+i*28,103,5,16,'#d4bd8c');rect(450+i*28,246,5,14,'#d4bd8c');}line(450,108,595,108,'#c5ad7d',3);line(450,250,595,250,'#c5ad7d',3);
 ellipse(551,355,51,29,'#777e61');for(let i=0;i<10;i++){const a=i/10*Math.PI*2;ellipse(551+Math.cos(a)*25,351+Math.sin(a)*14,7,5,'#c2bca0');}
 line(536,353,568,344,'#806449',7);line(540,342,562,357,'#73553e',6);
 rect(480,401,36,9,'#927953');rect(589,401,36,9,'#927953');
 for(let i=0;i<6;i++){const x=145+i%2*21,y=485+Math.floor(i/2)*16;ellipse(x,y,14,9,'#9a9c87');ellipse(x-4,y-3,8,5,'#b7b9a0');}
 cache.set(key,canvas);if(cache.size>3)cache.delete(cache.keys().next().value);return canvas;
}
export function drawWorld(g,selected,options={}){
 const canvas=document.querySelector('#world');if(!canvas)return [];
 const c=canvas.getContext('2d'),{rect,ellipse,line,polygon}=primitives(c),motion=options.motion!==false;
 const time=options.visualTime??g.time,ambient=motion?(options.ambientTime??time):0;
 c.clearRect(0,0,1120,650);c.drawImage(background(g),0,0);
 const positions=[],labels=[];
 for(const [index,r] of g.residents.filter(r=>r.alive).entries()){
  if(away(g,r.id))continue;
  const role=effectiveRole(r),anchors={'농사':[516,287],'건설':[321,393],'치료':[730,282],'휴식':[764,580],'배움':[918,569],'가르침':[891,569],'교류':[551,407]};
  const [ax,ay]=anchors[role],t=time*.9+r.id*1.7;
  const x=ax+(motion?Math.sin(t*.28)*14:0)+((index%4)-1)*16,y=ay+(motion?Math.cos(t*.25)*7:0)+Math.floor(index/4)*6;
  positions.push({id:r.id,x,y});labels.push({name:r.name,x,y});
  c.save();c.translate(x,y);const size=r.age<6 ? .6 : r.age<16 ? .8 : 1;c.scale(size,size);
  ellipse(3,14,14,6,'#253e3b35');if(selected===r.id){c.strokeStyle='#f1de9f';c.lineWidth=2;c.beginPath();c.ellipse(0,13,18,8,0,0,Math.PI*2);c.stroke();}
  const step=motion?Math.sin(t*3)*2:0;rect(-7,7,5,8+step,'#46534a');rect(3,7,5,8-step,'#46534a');
  c.fillStyle=colors[r.id%colors.length];c.beginPath();c.roundRect(-11,-7,22,21,[8,8,4,4]);c.fill();rect(-2,-3,4,15,'#c9c49a');
  ellipse(0,-16,10,11,'#e2be95');ellipse(0,-22,10,6,r.age>=60?'#d1d0b5':r.id%2?'#745746':'#3e463c');rect(-4,-16,2,2,'#344238');rect(3,-16,2,2,'#344238');
  const swing=motion?Math.sin(t*2.5)*3:0;
  if(role==='건설'){line(10,2,19,-6+swing,'#9e855e',3);rect(15,-12+swing,12,5,'#a7b5a1');}
  if(role==='농사'){rect(8,2,14,10,'#ac8b58');ellipse(12,1,4,4,'#a9bb72');ellipse(18,1,4,4,'#b9c686');}
  if(role==='치료'){rect(8,1,13,11,'#d2d6b7');line(14,3,14,10,'#678b70',2);line(11,6,17,6,'#678b70',2);}
  if(role==='배움'||role==='가르침'){rect(7,0,16,10,'#b9c297');line(15,1,15,9,'#718668',1);}
  if(role==='휴식'){c.fillStyle='#dce4be';c.font='10px system-ui';c.fillText('z',14,-25-(motion?Math.sin(t)*2:0));}
  if(role==='교류'){ellipse(18,-25,10,6,'#d9dfb8');ellipse(17,-24,1,1,'#6d8063');ellipse(21,-24,1,1,'#6d8063');}
  c.restore();
 }
 const night=options.weather===false?0:Math.max(0,Math.cos(((g.time%60)/60-.8)*Math.PI*2))*(options.contrast ? .22 : .43);
 if(night){rect(0,0,1120,650,`rgba(23,38,59,${night})`);for(const s of sites)for(const wx of [s.x+27,s.x+s.w-29]){const glow=c.createRadialGradient(wx,s.y+48,1,wx,s.y+48,48);glow.addColorStop(0,'#eed09155');glow.addColorStop(1,'#eed09100');c.fillStyle=glow;c.fillRect(wx-48,s.y,96,96);rect(wx-9,s.y+39,18,15,'#e5cc92');}}
 const fire=c.createRadialGradient(551,343,2,551,343,72);fire.addColorStop(0,'#e9bb7055');fire.addColorStop(1,'#e9bb7000');c.fillStyle=fire;c.fillRect(477,269,148,148);
 const flicker=motion?Math.sin(ambient*8)*2:0;ellipse(551,341,8+flicker*.4,14+flicker,'#d89f57');ellipse(552,344,4,9,'#f4dc93');
 if(motion){
  for(const s of sites.filter(s=>s.id==='lounge'||s.id==='workshop'))for(let i=0;i<5;i++){const phase=(ambient*.18+i*.21)%1;c.globalAlpha=(1-phase)*.22;ellipse(s.x+23+Math.sin(phase*5+i)*9,s.y-30-phase*65,8+phase*12,5+phase*7,'#dde2ca');}c.globalAlpha=1;
  for(let i=0;i<5;i++){const phase=(ambient*.45+i*.2)%1;ellipse(550+Math.sin(i+phase*8)*10,333-phase*37,1,2,`rgba(246,214,130,${1-phase})`);}
 }
 if(options.weather!==false){
  if(g.crisis.kind==='winter'&&g.crisis.warned){for(let i=0;i<70;i++){const x=(i*97+ambient*13)%1120,y=(i*53+ambient*21)%650;ellipse(x,y,1.5,2,'#e3ead4aa');}}
  else if(g.world===2){c.globalAlpha=.07;for(let i=0;i<5;i++)ellipse((i*270+ambient*8)%1400-100,220+i*65,240,26,'#d5e4d8');c.globalAlpha=1;}
  else{for(let i=0;i<13;i++){const x=(i*87+ambient*5)%1120,y=70+(i*43)%500+Math.sin(ambient*.7+i)*4;ellipse(x,y,1,1,'#e0db9b66');}}
 }
 if(options.labels!==false){
  const caption=(text,x,y)=>{c.font='12px system-ui';c.textAlign='center';const width=c.measureText(text).width;rect(x-width/2-9,y-14,width+18,22,'#20362cde');c.fillStyle='#e5e8ca';c.fillText(text,x,y+1);};
  for(const s of sites)caption(`${s.name} Lv.${g.facilities[s.id]}`,s.x+s.w/2,s.y+s.h+27);
  caption(`밭 Lv.${g.facilities.farm}`,523,263);
  for(const r of labels){c.font='11px system-ui';c.textAlign='center';const width=c.measureText(r.name).width;rect(r.x-width/2-5,r.y+23,width+10,17,'#20392ee8');c.fillStyle='#eef0d4';c.fillText(r.name,r.x,r.y+35);}
 }
 return positions;
}
