import {setJob,setCombatClass,canExpedition,away} from './game.js';
import {journeyFrozen} from './journey.js';
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const tutorialPages=[
 {title:'첫 목표는 안개 숲에서 무사히 돌아오기',icon:'♧',body:'주민 여섯 명이 스스로 일하는 피난처입니다. 당신은 누가 일하고, 누가 원정을 가고, 어떻게 쉴지를 정합니다. 전투에서 직접 공격 버튼을 누르지는 않습니다.',steps:['먼저 거점에 농사·건설·치료 담당을 남깁니다.','나머지 세 명을 안개 숲에 보내고, 갈림길에서는 안전한 우회로를 고릅니다.','돌아오면 체력과 스트레스를 회복합니다. 처음에는 여기까지 해 보면 됩니다.'],note:'튜토리얼을 읽는 동안 게임 시간은 멈춥니다. 언제든 상단 「처음 하는 법」에서 다시 볼 수 있습니다.'},
 {title:'어디를 누르면 되나요?',icon:'☀',body:'화면 왼쪽은 주민 목록, 가운데는 정착지와 선택한 주민의 상세 정보, 오른쪽은 원정 편성입니다.',steps:['왼쪽 주민 이름을 누른 뒤, 가운데 아래 「생활 초점」에서 농사·건설·치료·휴식을 고릅니다.','상단 Ⅱ 또는 Space로 멈추고 생각하세요. 1×로 시작하고 익숙해지면 2×·4×·8×를 사용합니다.','생활과 전투는 시간이 흘러야 진행됩니다. 선택 창과 도움말을 열면 잠시 멈춥니다.'],note:'식량은 모두가 먹고, 자재는 장비·시설에 쓰며, 의약품은 치료에 씁니다. 중요한 선택은 자동 모드에서도 직접 확인해야 할 수 있습니다.',action:'tutorial-resident',label:'주민 상세를 직접 살펴보기'},
 {title:'처음에는 이 배치로 해 보세요',icon:'⌂',body:'생활 초점과 원정 직업은 서로 다릅니다. 농부도 원정에서는 수호자가 될 수 있습니다. 원정을 간 사람은 거점 일을 하지 않으므로, 세 가지 생산 담당을 남겨야 합니다.',steps:['거점에 남는 세 명은 각각 치료·농사·건설을 맡습니다.','원정대는 전방 수호자 → 후방 척후병 → 후방 치유사 순으로 편성합니다.','「추천 배치 적용」은 이 역할만 정하고 게임을 일시정지합니다. 출정·구매·자원 지급은 하지 않습니다.'],note:'추천 배치는 첫 회차의 첫 원정 전, 초기 성인 여섯 명이 건강하고 사건이 없을 때만 사용할 수 있습니다.',setup:true},
 {title:'이제 첫 원정을 보내 보세요',icon:'➶',body:'오른쪽 「경계 너머로」에서 지역을 안개 숲, 방침을 신중으로 정합니다. 이름에 체크된 사람이 원정대입니다. 세 명만 선택할 수 있습니다.',steps:['추천 배치를 썼다면 세 명이 이미 선택되어 있습니다. 직접 바꾸려면 선택된 이름을 눌러 해제하고 다른 사람을 누르세요.','편성 순서의 첫 사람이 전방입니다. 수호자의 「전방으로」를 누르면 선봉으로 옮길 수 있습니다.','「원정 출발 · 식량 8」을 누르고 1× 또는 2×로 진행하세요. 첫 원정에는 추가 장비가 필수는 아닙니다.','갈림길이 나오면 「안전한 우회로」를 선택하세요. 전투는 자동입니다. 위험하면 「지금 귀환시키기」로 돌아올 수 있습니다.'],note:'의약품 최대 3개를 구급약으로 챙깁니다. 체력 35 미만 또는 스트레스 85 이상이면 자동 철수합니다. 갈림길을 고르기 전에는 원정대가 기다립니다.',action:'tutorial-expedition',label:'원정 편성으로 가서 직접 해 보기'},
 {title:'귀환했다면 다음 출정보다 회복부터',icon:'✚',body:'철수해도 이미 챙긴 자재는 가져옵니다. 첫 시도에 완주하지 못해도 주민을 회복하고 장비를 준비하면 다시 도전할 수 있습니다.',steps:['귀환한 세 명의 생활 초점을 「휴식」으로 바꾸세요. 스트레스·피로가 내려가고 체력이 조금씩 회복됩니다.','거점의 치료 담당은 의약품으로 부상자를 치료합니다. 처음에는 체력 95 이상, 스트레스 25 이하 정도까지 기다리는 편이 편합니다.','「장비·유물」에서 방패를 제작한 뒤, 주민 상세의 장비 칸에서 착용하세요. 제작만 하면 보관함에 남습니다.','숲을 완주하면 등불을 얻고 채석장·수로가 열립니다. 둘은 필수 경로가 아니라 다음 탐사를 준비하는 선택지입니다.'],note:'갈등·악몽 같은 선택이 뜨면 비용과 결과를 읽고 결정하세요. 부상과 스트레스를 둔 채 연속 출정하면 자동 철수가 잦아집니다.',action:'tutorial-resident',label:'주민의 몸과 마음 확인하기'},
 {title:'그다음에는 무엇을 하나요?',icon:'✧',body:'생활 → 탐사 → 회복 → 장비·시설 개선을 반복합니다. 더 강해지면 성소에 도전하거나, 탐험 없이 물자를 모아 공동체를 지킬 수도 있습니다.',steps:['상단 「위기 대비」에서 대응 점수가 목표 이상이 되도록 물자를 투입합니다. 창고에 갖고만 있는 자원은 점수에 포함되지 않습니다.','위기는 게임 시간 30분 뒤 도착합니다. 10분 이후에는 조건을 갖춰 일찍 대응할 수 있습니다. 부족하면 피해를 감수한 방어와 대피 중 선택합니다.','가족 맞이와 아이 교육은 여유가 생긴 뒤 해도 됩니다. 성소 공략 후 다음 터전으로 계승하거나, 성공 결말 뒤 이곳에 남아 다음 세대를 키울 수 있습니다.','게임을 끄기 전 「저장」을 누르세요. PC·브라우저를 옮길 때는 「화면·소리 → 저장 내보내기」로 보관하세요.'],note:'처음에는 가족·시설·모든 지역을 한꺼번에 챙기려 하지 않아도 됩니다. 안개 숲 출정과 귀환 후 회복부터 익혀 보세요.',action:'tutorial-crisis',label:'위기 대비 화면 살펴보기'},
];
export function canApplyTutorialSetup(g){
 return g.cycle===1&&g.expeditions===0&&!g.expedition&&!g.event&&!journeyFrozen(g)&&g.residents.slice(0,6).length===6&&g.residents.slice(0,6).every(r=>canExpedition(g,r.id));
}
export function applyTutorialSetup(g){
 if(!canApplyTutorialSetup(g))return false;
 for(const [id,role] of [[0,'휴식'],[1,'휴식'],[2,'휴식'],[3,'치료'],[4,'농사'],[5,'건설']])setJob(g,id,role);
 for(const [id,kind] of [[0,'guardian'],[1,'scout'],[2,'healer']])setCombatClass(g,id,kind);
 g.speed=0;return [0,1,2];
}
export function tutorialContents(g,index){
 const step=Math.max(0,Math.min(tutorialPages.length-1,index)),p=tutorialPages[step];
 const setup=p.setup?`<div class="tutorial-assignment">${g.residents.slice(0,6).map((r,i)=>`<span><strong>${esc(r.name)}</strong><small>${['전방 수호자','후방 척후병','후방 치유사','거점 · 치료','거점 · 농사','거점 · 건설'][i]}</small></span>`).join('')}</div><button data-action="tutorial-setup" ${canApplyTutorialSetup(g)?'':'disabled'}>추천 배치 적용 · 일시정지로 연습</button><small>${canApplyTutorialSetup(g)?'현재 생활 초점과 원정 직업을 위 배치로 바꿉니다.':'현재는 적용 조건이 맞지 않습니다. 설명을 참고해 원하는 주민을 직접 배치하세요.'}</small>`:'';
 return `<small>처음 하는 법 · ${step+1} / ${tutorialPages.length}</small><h2>${p.icon} ${p.title}</h2><nav class="tutorial-pages" aria-label="튜토리얼 단계">${tutorialPages.map((s,i)=>`<button data-tutorial-page="${i}" ${i===step?'aria-current="step"':''} title="${s.title}">${i+1}</button>`).join('')}</nav><p>${p.body}</p><ol class="tutorial-instructions">${p.steps.map(s=>`<li>${s}</li>`).join('')}</ol>${setup}<p class="tutorial-note">${p.note}</p>${p.action?`<button data-action="${p.action}">${p.label} ↗</button>`:''}<div class="tutorial-navigation"><button data-action="tutorial-prev" ${step===0?'disabled':''}>이전</button>${step<tutorialPages.length-1?'<button data-action="tutorial-next" class="primary">다음</button>':'<button data-action="tutorial-finish" class="primary">설명 마치고 직접 해 보기</button>'}<button data-action="tutorial-finish">게임으로 돌아가기</button></div>`;
}
export function tutorialHomeResident(g){return g.residents.find(r=>r.alive&&!away(g,r.id))?.id??g.residents[0].id;}
