import {equipment} from './combat.js';
import {facilities} from './settlement.js';
import {preparationTypes,crisisTypes} from './journey.js';
import {buildingDefs,townCapacity} from './town.js';
import {portraitSVG} from './appearance.js';
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number=n=>Number(n).toFixed(1).replace(/\.0$/,'');
export function commandPreview(g,d,team=[],selected=0){
 if(d.action==='retire'){const r=g.residents[selected];return {title:r.name+'가 현역에서 은퇴할까요?',description:r.job+' → 가르침. 나이·경험·기억은 유지하고 다음 세대를 돕습니다.',detail:'은퇴 후에는 원정에 출정할 수 없습니다.',label:'현역 은퇴·가르침으로 전환'};}
 if(d.action==='retreat'&&g.expedition){const e=g.expedition;return {title:'현재 원정을 마치고 돌아올까요?',description:`확보한 자재 ${Math.floor(e.loot)}과 남은 구급약을 가져와 귀환합니다.`,detail:'현재 탐사의 남은 지점은 중단됩니다. 아직 완주하지 않았다면 이번 원정의 지역 완주 보상은 얻지 못합니다.',label:'원정 중단·귀환'};}
 if(d.personalGoal){const r=g.residents[+d.residentId];return {title:r.name+'의 개인 목표를 바꿀까요?',description:'현재 미완료 목표 진행 '+r.personalGoal.progress.toFixed(1)+' → 0. 달성한 목표의 기록과 보상 이력은 유지합니다.',detail:'새 목표를 실제로 진행해야 다음 보상을 받을 수 있습니다.',label:'진행 초기화·새 목표 선택'};}
 if(d.action==='upgrade')return {title:'피난처를 확장할까요?',cost:{wood:25*g.level},description:`피난처 ${g.level} → ${g.level+1}단계. 주민 정원 ${townCapacity(g)} → ${townCapacity({...g,level:g.level+1})}명.`,detail:`농사·자재 수집·휴식에 적용되는 기본 계수 ${Math.round((1+(g.level-1)*.2+Math.min(10,g.legacyPoints)*.05)*100)}% → ${Math.round((1+g.level*.2+Math.min(10,g.legacyPoints)*.05)*100)}%. 실제 생산과 회복은 피로·부상·시설 등의 영향도 받습니다.`,label:'자재를 써서 확장'};
 if(d.action==='depart')return {title:'이 원정대를 출발시킬까요?',people:team.map(id=>`<span>${portraitSVG(g.residents[id])}<strong>${esc(g.residents[id].name)}</strong><small>${esc(g.residents[id].combatClass==='guardian'?'수호자':g.residents[id].combatClass==='healer'?'치유사':g.residents[id].combatClass==='ranger'?'사수':'척후병')}</small></span>`).join(''),cost:{food:2+team.length*2,medicine:Math.min(team.length,Math.floor(g.medicine))},description:`출정 ${team.length}명: ${team.map(id=>g.residents[id].name).join(', ')}.`,detail:`거점 잔류: ${g.residents.filter(r=>r.alive&&!team.includes(r.id)).map(r=>r.name+' · '+r.job).join(', ')||'없음'}. 출정자는 생활 일을 하지 않습니다. 체력 35 미만·스트레스 85 이상 또는 장기전 한도로 자동 철수할 수 있습니다.`,label:'이 편성으로 출발'};
 if(d.facility){const f=facilities[d.facility],level=g.facilities[d.facility];return {title:f.name+'을 개선할까요?',cost:{wood:18*level,...(level>=2?{records:1}:{})},description:f.bonus(level)+' → '+f.bonus(level+1),detail:g.town.legacy?'확정하면 개선합니다.':'재료를 예약하고 건설 담당이 개선 작업을 완성해야 적용됩니다.',label:g.town.legacy?'시설 개선':'개선 작업 예약'};}
 if(d.craft){const item=equipment[d.craft];return {title:item.name+' 제작을 진행할까요?',cost:item.cost,description:item.description||'원정 장비를 제작합니다.',detail:g.town.legacy?'완성 뒤 주민의 장비 칸에서 착용하세요.':'건설 담당이 작업을 완성한 뒤 보관함에 들어갑니다. 이후 주민에게 착용해야 효과가 납니다.',label:g.town.legacy?'장비 제작':'제작 작업 예약'};}
 if(d.demolishBuilding){const b=g.town.buildings.find(b=>b.id===d.demolishBuilding);if(b)return {title:buildingDefs[b.kind].name+'을 철거할까요?',description:`작업 20 후 철거됩니다. 기본 자재 ${Math.floor((buildingDefs[b.kind].cost.wood||0)*.4)}을 회수합니다.`,detail:'완성된 시설의 기능을 잃습니다. 필요한 잠자리가 부족해지는 숙소 철거는 실행할 수 없습니다.',label:'철거 작업 예약'};}
 if(d.prepare){const def=preparationTypes[d.prepare];return {title:def.name+'에 물자를 투입할까요?',cost:def.cost,description:`대비 횟수 ${g.crisis.preparations[d.prepare]} → ${g.crisis.preparations[d.prepare]+1} / 3. 대응 점수 +${crisisTypes[g.crisis.kind].weights[d.prepare]}.`,detail:'투입한 물자는 대비용으로 소비되며 돌려받지 않습니다.',label:'이 물자를 대비에 투입'};}
 if(d.cancelWork){const q=g.town.queue.find(q=>q.id===+d.cancelWork);if(q)return {title:'예약 작업을 취소할까요?',description:`진행 ${number(q.progress)} / ${q.work}. 미사용 재료 반환: ${Object.entries(q.cost).map(([key,n])=>`${{wood:'자재',food:'식량',medicine:'의약품',records:'기록'}[key]} ${Math.floor(n*(1-q.progress/q.work))}`).join(', ')||'없음'}.`,detail:'이미 사용한 재료와 진행도는 복구하지 않습니다.',label:'작업 취소·미사용 재료 반환'};}
 return null;
}
