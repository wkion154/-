import {GameClock,displayPosition} from './motion.js';
import {camera,toWorld,zoomAt,pan,clockReading} from './map-camera.js';
import {DialogueDisplay} from './dialogue-display.js';
import {commandPreview} from './command-preview.js';
import {confirmationContents} from './confirm-view.js';
import {decorateHelp,installTooltips,traitHelp} from './ui-help.js';
import {titleContents} from './title-view.js';
import {socialTeaser,socialContents} from './social-view.js';
import {atmosphere,requestConversation} from './social.js';
import {portraitSVG,defaultAppearance} from './appearance.js';
import {makeDraft,validDraft,rerollDraft} from './founders.js';
import {foundersContents,customizeContents} from './founders-view.js';
import {queueBuilding,queueRoad,queueMove,queueDemolish,cancelWork,prioritizeWork,roadLine,GRID} from './town.js';
import {townTools,constructionContents,workQueueContents,buildingContents,placementInfo} from './town-view.js';
import {icon,illustration} from './ui-art.js';
import {captureOutcome,outcomeChanges,outcomeLine,amount} from './outcomes.js';
import {previewChoice,previewResolution} from './choice-preview.js';
import {changeList} from './change-view.js';
import {helpTopics,readHelpProgress,helpCenter,coachCard,helpRevision} from './menu-help.js';
import {tutorialPages,tutorialContents,applyTutorialSetup,tutorialHomeResident} from './tutorial.js';
import {areas,areaUnlocked} from './areas.js';
import {readPreferences,capturePresentation,presentationChanges,tutorialSteps} from './presentation.js';
import {Soundscape} from './audio.js';
import {settingsContents} from './settings-view.js';
import {
  visitorReadiness,welcomeSurvivor,declineSurvivor,createGame,tick,day,depart,retreat,decide,upgrade,away,serialize,restore,log,customizeResident,setOperatingPolicy,
  eventView,connections,world,journeySummary,nextJourney,living,capacity,
  lifeStage,availableRoles,setJob,canExpedition,needsDecision,familyLinks,
  familyReadiness,welcomeChild,assignMentor,retireResident,YEAR_SECONDS,setCombatClass,craftEquipment,equipResident,activateRelic,chooseRoute,upgradeFacility,setAutonomy,setPersonalGoal,contributeCrisis,beginCrisis,resolveCrisis,continueSettlement,
} from './game.js';
import {battlePanel,loadoutPanel,formationView,armoryContents,relicLabel} from './combat-view.js';
import {crisisStrip,crisisContents,endingContents} from './journey-view.js';
import {journeyFrozen,eligibleHeirs,endingTypes} from './journey.js';
import {needsPanel,goalPanel,facilitiesContents} from './settlement-view.js';
import {activityLabel} from './settlement.js';
import {combatClasses,equipment} from './combat.js';
import {drawWorld,colors,buildingAt} from './scene.js';

// Keep the storage key stable; restore() migrates older snapshots in memory.
const KEY='hearth-save-v1';
const PREFERENCE_KEY='hearth-preferences-v1';
const HELP_KEY='hearth-menu-help-v1';
let helpProgress=readHelpProgress(readStorage(HELP_KEY)),activeCoach=null,coachReturn=null;
const gameClock=new GameClock(),mapCamera=camera(),dialogueDisplay=new DialogueDisplay();
let mapExpanded=false,showPaths=true,pointerGesture=null,suppressMapClick=false,spaceHeld=false,pendingCommand=null,bubbleHover=false,bubblePointer=null,bubbleBoxes=[],lastUiFrame=0;
let section='town',decisionPeek=false,lastOutcome=null,atTitle=true,founderReturnTitle=false;
const preferences=readPreferences(readStorage(PREFERENCE_KEY),globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
const audio=new Soundscape();
let presented=null,feedback={},feedbackUntil=0,lastSpeed=1,lastFrame=0;
let hasSaved=Boolean(readStorage(KEY));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function readStorage(key){try{return localStorage.getItem(key);}catch{return null;}}
function freshGame(){return createGame(globalThis.crypto?.getRandomValues(new Uint32Array(1))[0]??(Date.now()>>>0));}
let g,loadWarning='',pendingImport=null;
try{const raw=localStorage.getItem(KEY);g=raw?restore(raw):freshGame();}
catch{g=freshGame();loadWarning='저장을 읽지 못했습니다. 기존 파일은 자동으로 덮어쓰지 않습니다. 이전 저장을 복구하거나 새 게임을 선택하세요.';}
let selected=living(g)[0]?.id??0,team=g.town.legacy?[0,1,2]:canExpedition(g,0)&&canExpedition(g,2)?[0,2]:living(g).filter(r=>canExpedition(g,r.id)).slice(0,2).map(r=>r.id),policy='신중',target='숲';
let view=g.expedition?'expedition':'settlement';
let modal=null,heirId=0,guardians=[],familyMode='adoption';
let tutorialPage=0,founderIndex=0,founderDraft=null,creatorHeir=null,pendingJourney=null,editingResident=null,placement=null,selectedBuilding=null;
const DRAFT_KEY='hearth-founders-draft-v1';
if(!readStorage(KEY)&&!loadWarning){try{const draft=JSON.parse(readStorage(DRAFT_KEY));founderDraft=validDraft(draft)?draft:makeDraft(g.seed);}catch{founderDraft=makeDraft(g.seed);}}
function storeDraft(){if(founderDraft)try{localStorage.setItem(DRAFT_KEY,JSON.stringify(founderDraft));}catch{}}
function currentLook(){return modal==='customize'?editingResident:founderIndex===0&&creatorHeir?creatorHeir:founderDraft?.founders[founderIndex];}
function openFounders(journey=null){
 pendingJourney=journey;creatorHeir=null;founderIndex=0;founderReturnTitle=atTitle;founderDraft=makeDraft(journey?journey.seed:(crypto.getRandomValues(new Uint32Array(1))[0]));
 if(!journey){try{const draft=JSON.parse(readStorage(DRAFT_KEY));if(validDraft(draft))founderDraft=draft;}catch{}}
 if(journey?.heir){creatorHeir=structuredClone(journey.heir);founderDraft.locked[0]=true;}activeCoach=null;modal='founders';storeDraft();
}

let dirty=false,lastPersist=Date.now(),positions=[];
function save(manual=false){
  if(modal==='founders'||atTitle&&!hasSaved){if(manual)toast('개척단을 확정한 뒤 게임을 저장합니다. 기존 저장은 유지됩니다.');return;}
  try{
    const previous=localStorage.getItem(KEY);
    if(previous){try{restore(previous);localStorage.setItem(KEY+'-backup',previous);}catch{}}
    localStorage.setItem(KEY,serialize(g));dirty=false;hasSaved=true;lastPersist=Date.now();
    if(manual){loadWarning='';toast('피난처의 기록을 저장했습니다.');}
  }catch{toast('저장 공간에 접근할 수 없습니다. 브라우저 설정을 확인하세요.');}
}
function exportSave(){
  const url=URL.createObjectURL(new Blob([serialize(g)],{type:'application/json'}));
  const link=document.createElement('a');link.href=url;link.download=`hearth-cycle-${g.cycle}-day-${day(g)}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
  toast('현재 진행을 저장 파일로 내보냈습니다.');
}
function importSave(){
  const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.id='save-file';input.hidden=true;document.body.append(input);
  input.addEventListener('cancel',()=>input.remove(),{once:true});
  input.addEventListener('change',async()=>{
    const file=input.files?.[0];input.remove();if(!file)return;
    try{if(file.size>2*1024*1024)throw Error('too large');pendingImport=restore((await file.text()).replace(/^\uFEFF/,''));modal='import-confirm';render();}
    catch{pendingImport=null;toast('지원하지 않거나 손상된 저장 파일입니다. 현재 진행은 유지됩니다.');}
  },{once:true});input.click();
}
function toast(text){
  document.querySelector('.toast')?.remove();const el=document.createElement('div');
  el.className='toast';el.setAttribute('role','status');el.textContent=text;document.body.append(el);setTimeout(()=>el.remove(),3500);
}
function storePreferences(){
  try{localStorage.setItem(PREFERENCE_KEY,JSON.stringify(preferences));}catch{toast('이 브라우저에서 설정을 보존할 수 없습니다.');}
  document.documentElement.classList.toggle('reduced-motion',!preferences.motion);document.documentElement.classList.toggle('full-motion',preferences.motion);
  document.documentElement.classList.toggle('high-contrast',preferences.contrast);
}
function configureAudio(){audio.configure(preferences).catch(()=>toast('소리를 재생할 수 없습니다. 소리 설정을 다시 확인하세요.'));}
function drawScene(now=performance.now()){
  const advancing=!atTitle&&!modal&&g.speed&&!journeyFrozen(g)&&!needsDecision(g);
  const alpha=journeyFrozen(g)||needsDecision(g)?1:gameClock.accumulator;
  const poses=new Map(g.residents.map(r=>[r.id,displayPosition(g,r,alpha)]));
  const canvas=document.querySelector('#world');if(mapExpanded&&canvas){const parent=canvas.parentElement,w=Math.min(parent.clientWidth,parent.clientHeight*1120/650);canvas.style.width=w+'px';canvas.style.height=w*650/1120+'px';}else if(canvas){canvas.style.width='';canvas.style.height='';}
  bubbleBoxes=[];const dialogue=dialogueDisplay.update(g,now,Boolean(modal)||!g.speed||bubbleHover||document.hidden);
  positions=drawWorld(g,selected,{...preferences,visualTime:g.time+alpha,ambientTime:now/1000,placement,advancing,poses,camera:mapCamera,showPaths,dialogue,bubbleBoxes});bubbleHover=Boolean(bubblePointer&&bubbleBoxes.some(b=>bubblePointer.x>=b.x&&bubblePointer.x<=b.x+b.width&&bubblePointer.y>=b.y&&bubblePointer.y<=b.y+b.height));
}

function guidePanel(){
  if(!preferences.guide||g.ending||g.cycle>1)return '';
  const steps=tutorialSteps(g),current=steps.find(s=>!s.done),done=steps.filter(s=>s.done).length;
  return `<section class="first-steps" aria-label="플레이 안내"><div><small>첫 불빛을 위한 안내 · ${done}/${steps.length}</small><h3>${current?current.title:'첫 준비를 마쳤습니다'}</h3><p>${current?current.text:'이제 사람들의 삶과 다음 세대를 돌보며 성소와 위기에 도전하세요.'}</p></div>${button('tutorial','처음 하는 법 · 따라하기',false,'primary')}${current?`<button data-guide="${current.action}">${current.label} ↗</button>`:''}<button data-action="hide-guide" aria-label="초반 안내 숨기기">×</button></section>`;
}
function focusState(){const el=document.activeElement;if(!el||el===document.body)return null;return {id:el.id,data:{...el.dataset},dialog:Boolean(el.closest('[role=dialog]'))};}
function restoreFocus(state,previousDialog){
  const dialog=document.querySelector('[role=dialog]');document.querySelector('main').inert=Boolean(dialog);
  let target=state?.id?document.getElementById(state.id):null;
  if(!target&&state&&Object.keys(state.data).length)target=[...document.querySelectorAll('button')].find(el=>Object.entries(state.data).every(([key,value])=>el.dataset[key]===value)&&Boolean(el.closest('[role=dialog]'))===state.dialog);
  if(dialog&&previousDialog!==dialog.getAttribute('aria-label'))target=dialog.querySelector('button:not(:disabled),input:not(:disabled),select:not(:disabled)');
  if(target&&!target.disabled)target.focus({preventScroll:true});
}
const portrait=r=>`<div class="portrait ${r.age<16?'child':''} ${r.age>=60?'elder':''}">${portraitSVG(r)}</div>`;
const signed=n=>`${n>0?'+':''}${n}`;
function button(action,label,disabled=false,classes=''){
  return `<button data-action="${action}" ${disabled?'disabled':''} class="${classes}">${label}</button>`;
}
function resourcePanel(){
  return [['식량','food',g.food],['자재','wood',g.wood],['의약품','medicine',g.medicine],['공동체 기록','records',g.records]]
    .map(([label,key,value])=>`<div class="resource" data-resource="${key}">${icon(key)}<span>${label}</span><b>${amount(value)}</b>${g.town.queue.some(q=>q.cost[key])?`<small class="resource-reserved">예약 ${amount(g.town.queue.reduce((n,q)=>n+Math.floor((q.cost[key]||0)*(1-q.progress/q.work)),0))}</small>`:''}</div>`).join('');
}
function decisionPending(){return needsDecision(g)||g.crisis.ready;}
function inspectionLocked(){return decisionPeek&&decisionPending();}
function readOnlyButton(b){
  if(b.dataset.section||b.dataset.person!==undefined||b.dataset.view||b.dataset.memorial!==undefined||b.dataset.endingPerson!==undefined||b.dataset.replayHelp||b.dataset.guide||b.dataset.tutorialPage!==undefined)return true;
  return ['save','export-save','settings','sound','help','help-center','close-modal','close-journal','close-legacy','tutorial','tutorial-prev','tutorial-next','tutorial-finish','tutorial-resident','tutorial-expedition','tutorial-crisis','hide-guide','journal','memorial','family','facilities','armory','crisis','ending','resume-decision','coach-prev','coach-next','coach-finish','coach-skip','reset-menu-help','dismiss-outcome','construction','cancel-placement','social','title','map-expand','map-reset','map-zoom-in','map-zoom-out','map-paths'].includes(b.dataset.action);
}
function storeHelp(){try{localStorage.setItem(HELP_KEY,JSON.stringify(helpProgress));}catch{toast('안내 확인 이력을 저장하지 못했습니다.');}}
function finishCoach(){if(activeCoach){helpProgress.seen[activeCoach.id]=helpRevision(activeCoach.id);storeHelp();}activeCoach=null;if(modal==='coach'){modal=coachReturn;coachReturn=null;}}
function offerCoach(id,force=false){
  if(!helpTopics[id]||(!force&&(!preferences.menuHints||helpProgress.seen[id]||decisionPending())))return;
  activeCoach={id,page:0};
  if(force){coachReturn='help-center';modal='coach';}
  else if(!modal){coachReturn=null;modal='coach';}
}
function toolbar(){
  const clock=clockReading(g.time),clockText=`${clock.day}일째 · ${String(clock.hours).padStart(2,'0')}:${String(clock.minutes).padStart(2,'0')}`;
  const controls=`<div class="time-controls" aria-label="시간 조절">${button('pause',icon('pause')+'<span>정지</span>',false,g.speed===0?'active':'')}${[1,2,4,8].map(n=>`<button data-speed="${n}" class="${g.speed===n?'active':''}" aria-label="${n}배속">${n}×</button>`).join('')}</div>`;
  return `<div class="hud"><header class="top"><div class="brand">${icon('town','brand-icon')}<div><h1>잔향의 피난처 <em>1.4.0</em></h1><small>${g.cycle}번째 여정 · ${day(g)}일 · ${living(g).length}명의 삶</small></div></div><div class="resources">${resourcePanel()}</div></header>
  <nav class="toolbar" aria-label="주요 메뉴"><div class="primary-nav">${[['town','마을'],['expedition','원정'],['people','사람들'],['records','기록'],['settings','설정']].map(([id,label])=>`<button data-section="${id}" ${id==='settings'?'data-action="settings"':''} class="${section===id?'active':''}" ${section===id?'aria-current="page"':''}>${icon(id)}${label}</button>`).join('')}</div>${controls}<div class="world-clock" data-help="게임 속 시각입니다. 하루는 게임 시간 60초이며 1초마다 24분씩 흐릅니다. 생애·위기 속도와 현실 시각은 별개입니다."><strong>${clock.hours>=6&&clock.hours<18?icon('sun'):icon('rest')}${clockText}</strong><small>${inspectionLocked()?'선택 대기':modal?'안내·창 확인 중':g.speed?g.speed+'배속 진행':'일시정지'}</small></div><div class="quick-controls">${button('save',icon('save')+'저장')}${button('tutorial',icon('help')+'처음 하는 법')}${button('help-center','도움말')}</div>
  <div class="context-nav"><div ${section==='town'?'':'hidden'}>${button('construction',icon('build')+'건설·길')}${button('facilities',icon('town')+'시설·생활')}${button('armory',icon('shield')+'장비·유물')}</div><div ${section==='expedition'?'':'hidden'}><span>생활 역할과 원정 직업은 별개입니다 · 전방 1명 / 후방 1~2명</span>${button('armory','장비 준비')}</div><div ${section==='people'?'':'hidden'}>${button('social','대화·기억')}${button('family',icon('family')+'가족 맞이',g.gameOver)}${button('journal',icon('records')+'생애·관계')}${button('memorial',icon('candle')+'추모')}</div><div ${section==='records'?'':'hidden'}>${button('journal','선택한 주민의 생애')}${button('memorial','추모 기록')}${(g.cleared||g.ending)?button('legacy','여정 계승',g.expedition||g.event||g.crisis.ready,'active'):''}</div><div ${section==='settings'?'':'hidden'}>${button('sound',preferences.sound?'♫ 소리 켜짐':'♪ 소리 꺼짐')}${button('auto-events',`선택: ${g.autoEvents?'자동':'직접'}`,false,g.autoEvents?'active':'')}${button('reset','새 게임')}</div><small>${inspectionLocked()?'선택 대기 · 정보만 확인할 수 있습니다':g.speed===0?'일시정지 · 배속을 누르면 진행합니다':`${g.speed}배속 진행 중 · Space로 잠시 멈추기`}</small></div></nav></div>`;
}
function peekBar(){if(!inspectionLocked())return '';const title=needsDecision(g)?eventView(g).title:'위기 최종 대응';return `<aside class="decision-dock" role="status">${icon('pause')}<div><strong>선택 대기 중 · 시간은 멈춰 있습니다</strong><span>${esc(title)} · 주민·기록·마을을 확인한 뒤 다시 열어 결정하세요.</span></div>${button('resume-decision',icon('eye')+'선택 창 다시 열기',false,'primary')}</aside>`;}
function outcomePanel(){if(!lastOutcome)return '';return `<section class="outcome-panel"><div><span>${icon('check')}실제 반영 결과</span><strong>${esc(lastOutcome.title)}</strong></div><details><summary>변화 ${lastOutcome.rows.length}개 펼쳐 보기</summary>${changeList(lastOutcome.rows)}</details><button data-action="dismiss-outcome" aria-label="결과 요약 숨기기">×</button><small>중요한 선택의 전후 수치는 불 곁의 기록에 보존됩니다.</small></section>`;}

function residentsPanel(){
  return `<aside class="panel population"><div class="panel-title"><h2>우리의 사람들</h2><small>${living(g).length} / ${capacity(g)}</small></div>
    <div class="residents">${living(g).map(r=>`<button class="resident ${r.id===selected?'selected':''}" data-person="${r.id}">
      ${portrait(r)}<div class="person-info"><strong>${esc(r.name)}</strong> <small style="display:inline">${r.age}세</small>
      <small><i class="dot"></i>${away(g,r.id)?'원정 중':activityLabel(r)} · ${lifeStage(r)}</small>
      <div class="bar risk-gauge" style="--risk:35%"><i style="width:${r.hp}%"></i></div><div class="bar stress risk-gauge" style="--risk:85%"><i style="width:${r.stress}%"></i></div></div></button>`).join('')}</div>
    <div class="sidebar-foot"><small>자라나는 이야기</small><p>${Math.floor(g.time/g.yearSeconds)+1}번째 생애의 해</p>
    <small>기본 속도 ${g.yearSeconds/60}분 = 생애 1년<br>16세 성인 · 60세 은퇴 선택<br>자연사 전에는 항상 멈춥니다.</small></div></aside>`;
}
function settlementPanel(){
  return `<section class="panel map-panel ${mapExpanded?'map-expanded':''}"><div class="scene-top"><h2>${world(g).name} <small>${world(g).description}</small></h2>
    <button class="upgrade" data-action="upgrade" ${g.gameOver||g.event||g.wood<25*g.level||g.level>=4?'disabled':''}>${g.level>=4?'확장 완료':`확장 · 자재 ${25*g.level}`} / Lv.${g.level}</button></div>
    ${townTools(g,placement)}<div class="map-controls"><button data-action="map-expand">${icon('eye')}${mapExpanded?'작게 보기 · Esc':'지도 크게 보기'}</button><button data-action="map-zoom-out" aria-label="지도 축소">−</button><strong>${Math.round(mapCamera.zoom*100)}%</strong><button data-action="map-zoom-in" aria-label="지도 확대">＋</button><button data-action="map-reset">전체 보기</button><button data-action="map-paths" aria-pressed="${showPaths}">이동 경로 ${showPaths?'켜짐':'꺼짐'}</button><small>${placement?'클릭: 배치 · 가운데 버튼/Space+드래그: 지도 이동':'휠: 확대 · 드래그: 지도 이동 · 클릭: 대상 선택'}</small></div><div class="scene"><canvas id="world" width="1120" height="650" aria-label="주민과 아이들이 함께 살아가는 숲속 정착지"></canvas>
    <div class="scene-tag"><b>● 함께 살아가는 터전</b> · ${esc(atmosphere(g))}</div></div>
    <div class="legend"><span>텐트에서 마을로 · 길은 실제 이동을 돕습니다</span><span>주민·시설을 누르면 상세 정보</span></div>${workQueueContents(g)}</section>${socialTeaser(g)}`;
}
function familyDescription(r){
  const links=familyLinks(g,r.id),parts=[];
  if(links.guardians.length)parts.push(`보호자: ${links.guardians.map(p=>`${p.name}${p.alive?'':' (추모)'}`).join(', ')}`);
  if(links.children.length)parts.push(`자녀: ${links.children.map(p=>p.name).join(', ')}`);
  if(links.previous.length)parts.push(`이전 터전의 가족: ${links.previous.join(', ')}`);
  return parts.map(esc).join('<br>')||'아직 맺어진 가족이 없습니다.';
}
function detailPanel(r){
  const mentorCandidates=living(g).filter(p=>p.id!==r.id&&p.age>=16&&p.skill>=2);
  return `<section class="panel detail"><div class="detail-head">${portrait(r)}<div><h2>${esc(r.name)} <small>${r.age}세 · ${r.generation}세대</small></h2>
    <small><span tabindex="0" data-help="${esc(traitHelp(r))}">${esc(r.trait)} ⓘ</span> · 숙련 ${r.skill} · ${lifeStage(r)}</small></div>${r.alive?button('customize','꾸미기',g.event||g.gameOver):''}<span class="badge" style="margin-left:auto">${!r.alive?'추모':away(g,r.id)?'원정 중':r.job}</span></div>
    <div class="detail-grid"><div>${needsPanel(g,r,away(g,r.id))}<div class="stats"><div class="stat" tabindex="0" data-help="체력 · 거점에서 치료·휴식으로 회복합니다. 출정은 45 이상, 전투에서 35 미만이면 자동 철수합니다."><span>${icon('heart')}체력 <b>${Math.floor(r.hp)}/100</b></span><div class="bar risk-gauge" style="--risk:35%"><i style="width:${r.hp}%"></i></div></div>
    <div class="stat" tabindex="0" data-help="스트레스 · 휴식과 위로로 낮춥니다. 85 이상이면 원정 전투에서 자동 철수합니다. 부상·피로·악몽도 함께 살펴보세요."><span>${icon('stress')}스트레스 <b>${Math.floor(r.stress)}/100</b></span><div class="bar stress risk-gauge" style="--risk:85%"><i style="width:${r.stress}%"></i></div></div></div>
    <div class="job-row"><label>생활 초점</label>${availableRoles(g,r).map(job=>`<button data-job="${job}" class="${r.job===job?'active':''}" ${g.event||away(g,r.id)?'disabled':''}>${icon(job)}${job}</button>`).join('')}</div>
    ${r.alive&&r.age>=6?`<div class="learning-row"><label for="mentor">스승</label><select id="mentor" ${g.event||away(g,r.id)?'disabled':''}><option value="">자동 연결</option>
      ${mentorCandidates.map(p=>`<option value="${p.id}" ${r.mentorId===p.id?'selected':''}>${esc(p.name)} · ${p.job}</option>`).join('')}</select><small>배움 ${Math.floor(r.education*100)}%</small></div>`:''}
    ${r.alive&&r.age>=55&&!r.retired?button('retire','현역 은퇴 · 가르침',g.event||away(g,r.id)):''}${loadoutPanel(g,r)}${goalPanel(g,r,away(g,r.id))}</div>
    <div class="biography">${esc(r.history[0])}<div class="family-summary">${familyDescription(r)}</div><small><span tabindex="0" data-help="부상은 생활 효율을 낮추며 치료로 회복합니다. 후유증은 스트레스 부담을 높이고 안정된 휴식이나 관련 사건으로 완화합니다.">부상 ${Math.ceil(r.injury)} · 후유증 ${r.trauma} ⓘ</span><br>
    ${!r.alive?`${r.deathDay}일째, 노환으로 세상을 떠났습니다.`:r.age<6?'보호자의 돌봄을 받습니다. 보호자의 농사·건설 생산 -15%.':r.job==='가르침'?'배움을 선택한 주민의 성장을 돕습니다.':r.job==='배움'?'스승이 가르침에 전념하면 더 빨리 배웁니다.':r.job==='치료'?'의약품으로 거점의 부상자를 치료합니다.':'경험과 선택이 생애에 남습니다.'}</small></div></div>
    <div class="connection-strip"><small>함께 살아가는 사람들</small>${connections(g,r.id).slice(0,3).map(c=>`<button data-person="${c.id}" class="relationship ${c.value<0?'negative':''}">${esc(c.name)}${c.alive?'':' †'} · ${c.label} ${signed(c.value)}</button>`).join('')}
    ${button('social','대화·기억 보기')}${button('journal','생애 전체 보기 ↗')}</div></section>`;
}
function expeditionPanel(){
  const e=g.expedition;
  return `<section class="panel"><div class="panel-title"><h2>경계 너머로</h2><small>${e?'탐사 진행 중':'원정대 편성'}</small></div><div class="exp-content">${e?`
    <h3>${areas[e.target].name}</h3><p class="description">${e.team.map(id=>esc(g.residents[id].name)).join(' · ')}<br>${e.policy} 방침 · 확보 자재 ${e.loot}</p>
    <div class="route">${[1,2,3,4,5].map(n=>`<i class="${e.node>=n?'done':''}">${n}</i>`).join('')}</div><div class="bar"><i style="width:${e.battle?e.battle.clock/2*100:e.choice?100:e.wait/4*100}%"></i></div>
    <div class="combat-report">${e.report[0]?`<strong>${esc(e.report[0].title)}</strong><p>${esc(e.report[0].text)}</p>`:'첫 탐사 지점으로 이동 중입니다.'}</div>
    <p class="description">보급 ${e.supplies} · 구급약 ${e.medkits}<br>전방: ${esc(g.residents[e.team[0]].name)} · 유물: ${relicLabel(g)}<br>체력 35 미만 또는 스트레스 85 이상이면 자동 철수합니다. 피로한 원정대는 공격력이 줄어듭니다.</p>${button('retreat','지금 귀환시키기',false,'primary')}`:`
    <p class="description">두 명 또는 세 명을 보냅니다. 남은 주민이 생산·건설·회복을 맡습니다.</p><div class="fields">
    <select id="target" aria-label="원정 지역">${Object.entries(areas).map(([id,area])=>`<option value="${id}" ${target===id?'selected':''} ${areaUnlocked(g,id)?'':'disabled'}>${area.name} · ${areaUnlocked(g,id)?area.difficulty:'숲 완주 후 개방'}</option>`).join('')}</select>
    <select id="policy" aria-label="원정 방침"><option ${policy==='신중'?'selected':''}>신중</option><option ${policy==='강행'?'selected':''}>강행</option></select></div>
    <p class="description">${areas[target].description} 완주: 기록 ${areas[target].rewardRecords}${areas[target].rewardMedicine?` · 의약품 ${areas[target].rewardMedicine}`:''} · 유물 발견</p><div class="team">${living(g).map(r=>`<button data-team="${r.id}" class="${team.includes(r.id)?'active':''}" ${!canExpedition(g,r.id)?'disabled':''}>${team.includes(r.id)?'✓ ':''}${esc(r.name)}${r.age<16?' (아이)':r.retired?' (은퇴)':''}</button>`).join('')}</div>
    ${formationView(g,team)}<small class="loadout-note">인원수만큼 구급약을 최대 3개까지 챙기며, 남은 약은 귀환 시 돌려줍니다. 유물: ${relicLabel(g)}</small>${button('depart','원정 출발 · 식량 '+(2+team.length*2),g.gameOver||g.event||![2,3].includes(team.length)||g.food<2+team.length*2,'primary')}
    <p class="notice">${![2,3].includes(team.length)?'출정 가능한 성인 두 명 또는 세 명을 선택하세요.':`거점 잔류 ${living(g).filter(r=>!team.includes(r.id)).map(r=>esc(r.name)+' · '+r.job).join(' / ')||'없음'} · 2인은 생산 유지, 3인은 전투 조합에 유리합니다.`}</p>`}</div></section>`;
}
function chroniclePanel(){
  return `<section class="panel journal"><div class="panel-title"><h2>불 곁의 기록</h2><small>최근 ${Math.min(100,g.log.length)}개</small></div><div id="chronicle-entries" class="entries" role="region" aria-label="불 곁의 기록 목록" tabindex="0">
  ${g.log.slice(0,100).map(l=>`<div class="entry ${l.kind}"><time>${Math.floor(l.time/60)+1}일째 · ${String(l.time%60).padStart(2,'0')}</time>${esc(l.text)}</div>`).join('')}</div></section>`;
}
function dialog(content,classes='',label='피난처 이야기'){
  return `<div class="overlay"><section class="modal ${classes}" role="dialog" aria-modal="true" aria-label="${label}">${content}</section></div>`;
}
function journalModal(r){
  return dialog(`<small>한 사람의 삶 · ${r.generation}세대 · ${lifeStage(r)}</small><h2>${esc(r.name)}의 이야기</h2><div class="journal-columns"><div><h3>삶에 남은 순간들</h3>
    <ol class="life-timeline">${r.history.map(h=>`<li>${esc(h)}</li>`).join('')}</ol></div><div><h3>가족과 배움</h3><p class="description">${familyDescription(r)}<br>${r.mentorId!==null?`스승: ${esc(g.residents[r.mentorId].name)}`:''}</p><h3>관계</h3>
    ${connections(g,r.id).filter(c=>c.alive||c.value!==0).map(c=>`<button data-person="${c.id}" class="relationship-row"><strong>${esc(c.name)}${c.alive?'':' †'}</strong><span>${c.label} · ${signed(c.value)}</span></button>`).join('')}
    <p class="description">관계 15 이상: 원정 피해·스트레스 감소.<br>친한 동료와 휴식: 스트레스 회복 +50%.<br>원정 직업은 생활 역할과 별개입니다. 아이와 은퇴한 스승도 삶의 주인공입니다.</p></div></div>${button('close-modal','피난처로 돌아가기')}`,'journal-modal','생애와 관계');
}
function familyModal(){
  const ready=familyReadiness(g,guardians,familyMode),candidates=living(g).filter(r=>r.age>=18&&r.age<70);
  const cost=Object.entries(ready.cost).map(([k,n])=>`${{food:'식량',wood:'자재',medicine:'의약품'}[k]} ${n}`).join(' · ');
  return dialog(`<small>다음 세대가 살아갈 곳</small><h2>새로운 가족 맞이하기</h2><div class="family-modes"><button data-family-mode="adoption" class="${familyMode==='adoption'?'active':''}">8세 아이 입양</button><button data-family-mode="birth" class="${familyMode==='birth'?'active':''}">0세 아이 출생</button></div>
    <p class="description">보호자를 선택하세요. 입양은 한 명 또는 두 명, 출생은 관계 35 이상의 두 명이 필요합니다. 현재 주민 ${living(g).length}/${capacity(g)}명.</p>
    <div class="heirs">${candidates.map(r=>`<button data-guardian="${r.id}" class="${guardians.includes(r.id)?'active':''}" ${away(g,r.id)?'disabled':''}>${guardians.includes(r.id)?'✓ ':''}${esc(r.name)}<small>${r.age}세 · ${r.job}</small></button>`).join('')}</div>
    <p class="notice">${esc(ready.reason)}</p><p class="description">필요 자원: ${cost}<br>6세부터 배움, 16세부터 성인의 삶을 시작합니다. 6세 미만 아이를 돌보는 보호자는 농사·건설 생산 효율이 15% 줄어듭니다.</p>
    ${button('welcome-child',familyMode==='birth'?'새 생명 맞이하기':'가족으로 맞이하기',!ready.allowed,'primary')}${button('close-modal','조금 더 준비하기')}`,'family-modal','가족 맞이하기');
}
function memorialModal(){
  const dead=g.residents.filter(r=>!r.alive);
  return dialog(`<small>여기서 살아간 사람들</small><h2>불 곁에 남은 이름</h2><p class="description">${dead.length?'한 사람의 끝이 그가 남긴 배움과 관계를 지우지는 않습니다.':'아직 떠나보낸 주민이 없습니다. 마지막 인사는 자동 모드에서도 직접 확인합니다.'}</p>
    <div class="memorial-list">${dead.map(r=>`<button data-memorial="${r.id}"><strong>${esc(r.name)} · ${r.age}세</strong><small>${r.generation}세대 · ${r.deathDay}일째 · 노환</small><p>${esc(r.history.find(h=>!h.includes('노환'))||r.history[0])}</p></button>`).join('')}</div>${button('close-modal','지금의 사람들에게 돌아가기')}`,'journal-modal','추모 기록');
}
function legacyModal(){
  const summary=journeySummary(g),eligible=eligibleHeirs(g),recordOnly=eligible.length===0&&Boolean(g.ending);
  if(!eligible.some(r=>r.id===heirId))heirId=eligible[0]?.id??-1;
  return dialog(`<small>한 여정의 끝, 다른 이야기의 시작</small><h2>불씨를 이어갈 사람</h2><p>${esc(summary.place)}에서 ${summary.days}일을 함께 살았습니다.<br>원정 ${summary.expeditions}회 · ${g.totalBirths}명의 새 가족 · 추모 ${g.residents.filter(r=>!r.alive).length}명</p>
    <div class="heirs">${living(g).map(r=>`<button data-heir="${r.id}" class="${heirId===r.id?'active':''}" ${!eligible.some(p=>p.id===r.id)?'disabled':''}>${esc(r.name)}<small>${r.age}세 · ${r.generation}세대 · 숙련 ${r.skill}</small></button>`).join('')}</div>
    <p class="description">성인 한 명의 숙련·나이·생애·가족 이름과 공동체 기록을 보존합니다. 착용 장비와 활성 유물 하나도 이어갑니다. 다른 가족이 함께 이동하지는 않습니다. 새 동료 세 명과 초기 자원으로 시작하며 관계는 초기화됩니다. 계승 주민은 치료받지만 젊어지지는 않습니다.<br>누적 생산 보너스 +${Math.min(10,g.legacyPoints+(g.ending&&!g.ending.success?0:1))*5}% (최대 50%).${g.ending&&!g.ending.success?' 대피·실패에서는 승리 보너스가 늘지 않습니다. 어린이가 계승하면 새 공동체에서 성장합니다.':''}${recordOnly?' 남겨진 기록과 함께 새로운 주민 네 명으로 시작합니다.':''}</p>
    <div class="past-journeys">${g.legacy.slice(-3).map(j=>`<small>${j.cycle}번째 · ${esc(j.place)} · ${j.days}일 · 원정 ${j.expeditions}회${j.outcome?` · ${endingTypes[j.outcome].title}`:''}</small>`).join('')}</div>
    ${button('continue-journey',heirId<0?(recordOnly?'기록을 이어 새 공동체로':'계승할 성인이 없습니다'):`${esc(g.residents[heirId].name)}와 다음 피난처로`,heirId<0&&!recordOnly,'primary')}${button('close-modal','아직 이곳에 머무르기')}`,'legacy-modal','여정의 계승');
}
function eventModal(){
  const ev=eventView(g),farewell=g.event.kind==='farewell',actors=[g.event.who,g.event.other].filter((id,i,a)=>id!==undefined&&a.indexOf(id)===i).map(id=>g.residents[id]);
  return dialog(`<div class="decision-heading"><small>${farewell?'마지막 인사 · 자동으로 진행되지 않습니다':'삶의 갈림길 · 선택 전후를 확인하세요'}</small>${button('peek-decision',icon('eye')+'배경 확인')}</div>${illustration(g.event.kind)}<div class="event-actors">${actors.map(r=>`<span>${portrait(r)}<strong>${esc(r.name)}</strong><small>${esc(r.trait)} · 체력 ${amount(r.hp)} · 스트레스 ${amount(r.stress)}</small></span>`).join('')}</div><h2>${esc(ev.title)}</h2><p>${esc(ev.text)}</p>
    ${farewell?`<ol class="life-timeline farewell-timeline">${rHistory(g.event.who)}</ol>`:''}
    <div class="decision-options">${ev.options.map((op,i)=>{const rows=op.available?previewChoice(g,i):null;return `<article class="decision-option"><button data-choice="${i}" ${op.available?'':'disabled'}><strong><span class="choice-number">${i+1}</span>${esc(op.label)}</strong>${op.available?changeList(rows,{compact:true}):`<small class="choice-blocked">현재 조건으로 선택할 수 없습니다 · ${esc(Object.entries(op.cost||{}).filter(([key,n])=>g[key]<n).map(([key,n])=>`${{food:'식량',wood:'자재',medicine:'의약품',records:'기록'}[key]} ${amount(g[key])} / 필요 ${n}`).join(' · ')||op.effects)}</small>`}</button>${rows?.length>5?`<details><summary>영향받는 모든 주민과 변화 펼치기</summary>${changeList(rows)}</details>`:''}</article>`;}).join('')}</div><small>수치는 비용·상하한·개인 목표 보상을 포함한 실제 처리 기준입니다. 선택은 생애 기록에 남습니다.</small>`,'decision-modal','삶의 갈림길');
}
function rHistory(id){return g.residents[id].history.slice(0,5).map(h=>`<li>${esc(h)}</li>`).join('');}

function helpModal(){
  if(!readStorage('hearth-intro'))return dialog(`<small>정착지 · 자동 원정 · 세대의 이야기</small><h2>처음 목표는 안개 숲에서 돌아오기</h2><p>주민은 자동으로 일하고 싸웁니다. 당신은 생활 역할과 원정대를 정하고, 귀환한 사람들의 몸과 마음을 돌봅니다.</p><ol class="tutorial-instructions"><li>마을 → 건설·길에서 첫 밭이나 작업대 위치를 정합니다.</li><li>첫 원정은 수호자·치유사 두 명을 보내고 두 명을 마을에 남겨 보세요.</li><li>안전한 길을 고르고, 돌아오면 휴식과 치료를 합니다.</li></ol>${button('tutorial','처음 하는 법 · 6단계로 따라하기',false,'primary')}${button('begin','설명 없이 바로 시작')}<small>안내를 읽는 동안 시간은 멈춥니다. 상단 「처음 하는 법」에서 언제든 다시 볼 수 있습니다.</small>`,'','플레이 안내');
  return dialog(`<small>한 세대가 남긴 불씨, 다음 세대의 삶</small><h2>이곳에서 다시 살아갑니다.</h2><p>생활 초점과 별도로 원정 직업·장비를 정하고 전방 1명, 후방 1~2명을 편성하세요. 장비·유물은 작업장에서 준비합니다. 표식과 사격, 방어와 치료를 조합하고 길의 분기에서 우회·지름길·야영을 선택하세요. 성소의 문지기를 쓰러뜨리면 이번 여정을 완료합니다.<br><br>「위기 대비」에서 다가오는 겨울·병해·포위에 필요한 물자를 투입하세요. 위기가 닥치면 최종 결정 전 시간이 멈춥니다. 준비가 충분하면 일찍 대응할 수도 있습니다.<br><br>「시설·생활」에서 생산·치료·교육을 개선하세요. 피로한 주민은 자율적으로 쉬고 돌아오며, 개인 목표를 이룰 수 있습니다.<br><br>「가족 맞이」로 아이를 돌보고, 배움과 가르침으로 경험을 전하세요. 아이는 16세에 진로를 고르고, 어른은 60세에 은퇴를 고민합니다.</p>
    ${button('tutorial','처음 하는 법 · 따라하기',false,'primary')}${button('begin','게임으로 돌아가기')}<small>기본 1배속: 하루 60초, 생애 1년 ${g.yearSeconds}초. 아이는 원정에 나가지 않습니다. 노환에 의한 마지막 인사는 자동 모드에서도 직접 확인합니다. 종료 중에는 시간이 흐르지 않습니다.</small>`,'','플레이 안내');
}
function render(){
  if(pointerGesture&&!modal&&!decisionPending())return;
  if(modal)hideTooltip();const oldCanvas=document.querySelector('#world');
  const focus=focusState(),previousDialog=document.querySelector('[role=dialog]')?.getAttribute('aria-label');
  const scroll=document.querySelector('.modal')?.scrollTop||0;
  if(!decisionPending())decisionPeek=false;
  const current=capturePresentation(g),changes=presentationChanges(presented,current);presented=current;
  if(changes.sounds.length){feedback=changes;feedbackUntil=performance.now()+700;for(const cue of changes.sounds)audio.play(cue);}
  const visibleFeedback=preferences.motion&&performance.now()<feedbackUntil?feedback:{};
  if(!g.expedition)view='settlement';
  if(g.expedition?.choice&&!g.autoEvents&&!decisionPeek&&section==='expedition')view='expedition';
  const r=g.residents[selected]||g.residents[0],oldScroll=document.querySelector('.entries')?.scrollTop||0;
  const listScroll=document.querySelector('.residents')?.scrollTop||0;
  if(!g.expedition)team=team.filter(id=>canExpedition(g,id));
  const message=g.gameOver?'마지막 불빛이 잦아들었습니다. 추모 기록을 돌아보고 새 여정을 시작할 수 있습니다.':g.cleared?'✧ 성소를 밝혔습니다. 이곳에서 다음 세대를 키우거나 「여정 계승」으로 새 터전을 향하세요.':g.totalBirths?'다음 세대가 자라고 있습니다. 배움과 가르침을 연결하고, 성인 원정대의 몸과 마음도 돌봐 주세요.':g.relics.includes('lantern')?'채석장과 수로가 열렸습니다. 주민을 회복하고 지역에 맞는 장비를 준비하세요.':'첫 목표 · 밭이나 작업대를 짓고, 두 명 또는 세 명을 안개 숲에 보내 보세요.';
  let overlay='';
  if(modal==='confirm-command'&&pendingCommand)overlay=dialog(confirmationContents(g,pendingCommand.preview),'command-modal','실행 확인');
  else if(modal==='founders'&&founderDraft)overlay=dialog(foundersContents(founderDraft,founderIndex,{heir:creatorHeir,canCancel:true,cancelLabel:founderReturnTitle?'타이틀로 돌아가기':'지금 게임으로 돌아가기'}),'founders-modal','개척단 네 명 고르기');
  else if(modal==='customize'&&editingResident)overlay=dialog(customizeContents(editingResident),'customize-modal','주민 꾸미기');
  else if(modal==='social')overlay=dialog(socialContents(g,selected),'social-modal','대화와 기억');
  else if(modal==='construction')overlay=dialog(constructionContents(g),'construction-modal','건설과 길');
  else if(modal==='building')overlay=dialog(buildingContents(g,selectedBuilding),'building-modal','선택한 시설');
  else if(modal==='import-confirm'&&pendingImport)overlay=dialog(`<h2>이 저장으로 이어서 할까요?</h2><p>${pendingImport.cycle}번째 여정 · ${day(pendingImport)}일째 · 생존 ${living(pendingImport).length}명<br>현재 진행을 교체합니다. 먼저 내보내기로 보관할 수 있습니다.</p>${button('export-save','현재 진행 내보내기')}${button('confirm-import','이 저장 불러오기',false,'primary')}${button('cancel-import','취소')}`,'','저장 불러오기 확인');
  else if(modal==='settings')overlay=dialog(settingsContents(preferences),'settings-modal','화면과 소리');
  else if(modal==='help')overlay=helpModal();
  else if(modal==='tutorial')overlay=dialog(tutorialContents(g,tutorialPage),'tutorial-modal',`처음 하는 법 · ${tutorialPage+1}단계`);
  else if(modal==='help-center')overlay=dialog(helpCenter(helpProgress),'help-center-modal','도움말·튜토리얼');
  else if(modal==='coach'&&activeCoach)overlay=dialog('','coach-modal','메뉴 안내');
  else if(!atTitle&&needsDecision(g)&&!decisionPeek)overlay=eventModal();
  else if(!atTitle&&g.crisis.ready&&!decisionPeek)overlay=dialog(`<div class="decision-heading"><small>공동체의 마지막 결정</small>${button('peek-decision',icon('eye')+'배경 확인')}</div>${crisisContents(g)}${['defend','evacuate'].map(choice=>`<details class="resolution-preview"><summary>${choice==='defend'?'방어':'대피'} 선택의 실제 변화</summary>${changeList(previewResolution(g,choice))}</details>`).join('')}`,'crisis-modal','위기 최종 대응');
  else if(modal==='legacy')overlay=legacyModal();
  else if(modal==='journal')overlay=journalModal(r);
  else if(modal==='family')overlay=familyModal();
  else if(modal==='facilities')overlay=dialog(facilitiesContents(g),'facilities-modal','시설과 생활');
  else if(modal==='armory')overlay=dialog(armoryContents(g),'armory-modal','작업장과 유물');
  else if(modal==='memorial')overlay=memorialModal();
  else if(modal==='crisis')overlay=dialog(crisisContents(g),'crisis-modal','위기 대비');
  else if(!atTitle&&(modal==='ending'||g.ending&&(!g.crisis.sandbox||g.gameOver)&&!modal))overlay=dialog(endingContents(g),'ending-modal','여정의 결말');
  else if(modal==='reset')overlay=dialog(`<h2>새로운 여정을 시작할까요?</h2><p>현재 주민과 가족, 추모·계승 기록이 초기화됩니다. 계승하려면 성소를 완료한 후 「여정 계승」을 사용하세요.</p>${button('confirm-reset','초기화하고 시작')}${button('close-modal','계속 살아가기')}`);
  if(activeCoach&&overlay)overlay=overlay.replace(/(<section[^>]*role="dialog"[^>]*>)/,`$1${coachCard(activeCoach.id,activeCoach.page)}`);
  document.querySelector('#app').innerHTML=`<main data-time="${g.time}" class="shell ${g.expedition?'on-expedition':''}">${toolbar()}
    ${crisisStrip(g)}${g.social.visitor?`<div class="visitor-notice">길가에 생존자가 기다립니다. 잠자리와 유지비를 확인하고 선택하세요. ${button('social','합류 조건 보기')}</div>`:''}${guidePanel()}${outcomePanel()}${!preferences.guide||g.cycle>1||g.ending?`<div class="guide">${message}</div>`:''}${loadWarning?`<p class="notice">${esc(loadWarning)} ${button('recover','이전 저장 복구')}</p>`:''}
    <section class="layout">${residentsPanel()}<div class="center"><nav class="view-tabs"><button data-view="settlement" class="${view==='settlement'?'active':''}">정착지</button><button data-view="expedition" class="${view==='expedition'?'active':''}" ${!g.expedition?'disabled':''}>원정 현장</button><small>${view==='expedition'?'거점의 일상은 계속됩니다':'주민의 하루를 살펴보세요'}</small></nav>${view==='expedition'?battlePanel(g,visibleFeedback):settlementPanel()}${detailPanel(r)}</div><aside class="right">${expeditionPanel()}${chroniclePanel()}</aside></section>
    <footer class="footer"><span>잔향의 피난처 · 다가오는 계절 / 계승 ${g.legacyPoints}회 · 생산 +${Math.min(10,g.legacyPoints)*5}%</span><span class="save-status" aria-label="게임 저장 상태">${loadWarning?'저장 중지':dirty?'변경 사항 있음 · 10초마다 자동 저장':hasSaved?'✓ 저장됨':'자동 저장 대기'} · 종료 중 진행 없음</span></footer></main>${overlay}${peekBar()}`;
  if(atTitle)document.querySelector('#app').innerHTML=titleContents(g,{canContinue:hasSaved&&!loadWarning,warning:loadWarning,hasDraft:Boolean(readStorage(DRAFT_KEY))})+overlay;
  document.documentElement.style.setProperty('--hud-height',((document.querySelector('.hud')?.getBoundingClientRect().height)||0)+'px');
  document.body.classList.toggle('at-title',atTitle);
  if(oldCanvas&&document.querySelector('#world'))document.querySelector('#world').replaceWith(oldCanvas);
  document.body.classList.toggle('map-is-expanded',mapExpanded&&!atTitle);decorateHelp(document.querySelector('#app'),g,selected);
  drawScene();
  const entries=document.querySelector('.entries');if(entries)entries.scrollTop=oldScroll;
  const list=document.querySelector('.residents');if(list)list.scrollTop=listScroll;
  const currentDialog=document.querySelector('[role=dialog]');if(currentDialog&&currentDialog.getAttribute('aria-label')===previousDialog)currentDialog.scrollTop=scroll;
  if(inspectionLocked())document.querySelectorAll('button').forEach(b=>{if(!readOnlyButton(b)){b.disabled=true;b.title='선택 창을 다시 열어 결정을 마친 뒤 사용할 수 있습니다.';}});
  if(inspectionLocked())document.querySelectorAll('select').forEach(el=>el.disabled=true);
  if(activeCoach)document.querySelector(helpTopics[activeCoach.id].target)?.classList.add('coach-highlight');
  document.body.classList.toggle('inspecting',inspectionLocked());
  restoreFocus(focus,previousDialog);
}
function openFamily(){
  const eligible=living(g).filter(r=>r.age>=18&&r.age<70&&!away(g,r.id));
  guardians=eligible.some(r=>r.id===selected)?[selected]:eligible.slice(0,1).map(r=>r.id);familyMode='adoption';modal='family';
}
function resetView(){gameClock.reset();mapExpanded=false;pendingCommand=null;Object.assign(mapCamera,camera());activeCoach=null;decisionPeek=false;lastOutcome=null;section='town';placement=null;selected=living(g)[0]?.id??0;team=living(g).filter(r=>canExpedition(g,r.id)).slice(0,g.town.legacy?3:2).map(r=>r.id);modal=null;}
function perform(action){
  if(action==='confirm-founders'){
    if(!validDraft(founderDraft)||creatorHeir&&!creatorHeir.name.trim()){toast('주민 네 명의 이름과 구성을 확인하세요.');return;}
    const next=pendingJourney?nextJourney(g,pendingJourney.heirId,{founders:founderDraft.founders}):createGame(founderDraft.seed,{founders:founderDraft.founders});
    if(!next)return;if(creatorHeir){next.residents[0].name=creatorHeir.name.trim();next.residents[0].appearance=structuredClone(creatorHeir.appearance);}
    atTitle=false;g=next;g.speed=0;founderDraft=null;pendingJourney=null;creatorHeir=null;resetView();if(!g.town.legacy&&g.cycle===1)team=[0,2];loadWarning='';dirty=true;save();modal='help';try{localStorage.removeItem(DRAFT_KEY);}catch{}return;
  }
  const menuSections={social:'people',facilities:'town',armory:'town',family:'people',journal:'records',memorial:'records',legacy:'records',settings:'settings'};
  if(menuSections[action])section=menuSections[action];
  switch(action){
    case 'confirm-command':{const command=pendingCommand;if(command){if(command.signature!==JSON.stringify(captureOutcome(g))){command.preview=commandPreview(g,command.dataset,team,selected);command.signature=JSON.stringify(captureOutcome(g));toast('상태가 달라져 확인 내용을 갱신했습니다. 다시 확인하세요.');break;}pendingCommand=null;modal=command.returnModal;const el=document.createElement('button');Object.assign(el.dataset,command.dataset);el.textContent=command.preview.title;handleButton(el,true);}break;}
    case 'cancel-command':if(pendingCommand){modal=pendingCommand.returnModal;pendingCommand=null;}break;
    case 'map-expand':mapExpanded=!mapExpanded;break;
    case 'map-reset':Object.assign(mapCamera,camera());break;
    case 'map-zoom-in':zoomAt(mapCamera,{x:560,y:325},1.25);break;
    case 'map-zoom-out':zoomAt(mapCamera,{x:560,y:325},.8);break;
    case 'map-paths':showPaths=!showPaths;break;
    case 'peek-decision':decisionPeek=true;activeCoach=null;modal=null;break;
    case 'resume-decision':decisionPeek=false;activeCoach=null;modal=null;break;
    case 'dismiss-outcome':lastOutcome=null;break;
    case 'help-center':modal='help-center';activeCoach=null;break;
    case 'reset-menu-help':helpProgress=readHelpProgress(null);storeHelp();toast('메뉴별 첫 안내 이력을 초기화했습니다. 게임 진행은 유지됩니다.');break;
    case 'coach-prev':if(activeCoach)activeCoach.page=Math.max(0,activeCoach.page-1);break;
    case 'coach-next':if(activeCoach)activeCoach.page=Math.min(2,activeCoach.page+1);break;
    case 'coach-finish':case 'coach-skip':finishCoach();break;
    case 'pause':if(g.speed){lastSpeed=g.speed;g.speed=0;}else g.speed=lastSpeed;gameClock.last=performance.now();dirty=true;break;
    case 'continue-game':if(atTitle&&hasSaved&&!loadWarning){atTitle=false;modal=!readStorage('hearth-intro')&&!decisionPending()?'help':null;gameClock.last=performance.now();}break;
    case 'title-new-game':openFounders();break;
    case 'title':mapExpanded=false;if(!loadWarning&&hasSaved)save();atTitle=true;modal=null;activeCoach=null;placement=null;decisionPeek=false;break;
    case 'settings':modal='settings';break;
    case 'construction':modal='construction';break;
    case 'customize':editingResident=structuredClone(g.residents[selected]);modal='customize';break;
    case 'confirm-customize':if(customizeResident(g,selected,editingResident)){modal=null;dirty=true;toast('이름과 외형을 적용했습니다.');}break;
    case 'cancel-founders':founderDraft=null;creatorHeir=null;pendingJourney=null;atTitle=founderReturnTitle;modal=null;break;
    case 'roll-founders':rerollDraft(founderDraft);storeDraft();break;
    case 'cancel-placement':placement=null;break;
    case 'rotate-placement':if(placement&&placement.type!=='road')placement.rotation=1-(placement.rotation||0);break;
    case 'confirm-placement':{
      if(!placement?.pinned)break;const p=placement,ok=p.type==='road'?queueRoad(g,p.cells,p.roadKind):p.type==='move'?queueMove(g,p.buildingId,p.x,p.y,p.rotation):queueBuilding(g,p.kind,p.x,p.y,p.rotation);
      if(ok){dirty=true;placement=null;toast('작업을 예약했습니다. 거점의 건설 담당자가 이동해 진행합니다.');}else toast('위치·재료·작업 대기열을 다시 확인하세요.');break;
    }
    case 'sound':preferences.sound=!preferences.sound;storePreferences();configureAudio();break;
    case 'hide-guide':preferences.guide=false;storePreferences();break;
    case 'save':save(true);break;
    case 'export-save':exportSave();break;
    case 'import-save':importSave();break;
    case 'cancel-import':pendingImport=null;modal='settings';break;
    case 'confirm-import':if(pendingImport){atTitle=false;g=pendingImport;pendingImport=null;g.speed=0;target='숲';resetView();view=g.expedition?'expedition':'settlement';presented=null;feedback={};loadWarning='';dirty=true;save(true);}break;
    case 'journal':modal='journal';break;
    case 'social':modal='social';break;
    case 'cancel-conversation':g.social.request=null;dirty=true;break;
    case 'welcome-survivor':{const r=welcomeSurvivor(g);if(r){selected=r.id;dirty=true;save();toast('새 동료가 합류했습니다. 생활 역할을 선택할 수 있습니다.');}else toast(visitorReadiness(g).reason);break;}
    case 'decline-survivor':if(declineSurvivor(g)){dirty=true;save();}break;
    case 'family':openFamily();break;
    case 'armory':modal='armory';break;
    case 'facilities':modal='facilities';break;
    case 'crisis':modal='crisis';break;
    case 'ending':modal='ending';break;
    case 'confront':if(beginCrisis(g)){modal=null;dirty=true;}break;
    case 'continue-home':if(continueSettlement(g)){modal=null;dirty=true;save();}break;
    case 'memorial':modal='memorial';break;
    case 'close-journal':case 'close-legacy':case 'cancel-reset':case 'close-modal':modal=null;break;
    case 'help':modal='help-center';activeCoach=null;break;
    case 'tutorial':tutorialPage=0;modal='tutorial';try{localStorage.setItem('hearth-intro','1');}catch{}break;
    case 'tutorial-prev':tutorialPage=Math.max(0,tutorialPage-1);break;
    case 'tutorial-next':tutorialPage=Math.min(tutorialPages.length-1,tutorialPage+1);break;
    case 'tutorial-finish':modal=null;break;
    case 'tutorial-setup':{const result=applyTutorialSetup(g);if(result){team=result;selected=0;target='숲';policy='신중';dirty=true;toast('추천 배치를 적용했습니다. 다음 설명을 읽거나 원정 편성으로 이동하세요.');}break;}
    case 'tutorial-resident':modal=null;selected=tutorialHomeResident(g);view='settlement';break;
    case 'tutorial-expedition':modal=null;if(g.expedition)view='expedition';break;
    case 'tutorial-crisis':modal='crisis';break;
    case 'begin':modal=null;try{localStorage.setItem('hearth-intro','1');}catch{}break;
    case 'depart':if(depart(g,team,policy,target)){view='expedition';section='expedition';}else toast('편성·체력·스트레스·식량을 확인하세요.');dirty=true;break;
    case 'retreat':retreat(g);dirty=true;break;
    case 'upgrade':upgrade(g);dirty=true;break;
    case 'retire':if(retireResident(g,selected)){dirty=true;toast('이제 다음 세대를 가르치는 삶을 시작합니다.');}break;
    case 'auto-events':g.autoEvents=!g.autoEvents;dirty=true;toast(g.autoEvents?'자원 안에서 자동 결정합니다. 마지막 인사는 직접 확인합니다.':'삶의 갈림길을 직접 결정합니다.');break;
    case 'legacy':modal='legacy';heirId=selected;break;
    case 'continue-journey':{const next=nextJourney(g,heirId);if(next)openFounders({seed:next.seed,heir:g.residents[heirId]?.alive?next.residents[0]:null,heirId});break;}
    case 'welcome-child':{const child=welcomeChild(g,guardians,familyMode);if(child){selected=child.id;modal=null;dirty=true;toast(`${child.name}의 이야기가 시작됩니다.`);}else toast(familyReadiness(g,guardians,familyMode).reason);break;}
    case 'reset':modal='reset';break;
    case 'confirm-reset':openFounders();break;
    case 'recover':try{g=restore(localStorage.getItem(KEY+'-backup'));resetView();loadWarning='';dirty=true;toast('이전 저장을 복원했습니다.');}catch{toast('복구 가능한 이전 저장이 없습니다.');}break;
  }
  if(!atTitle&&helpTopics[action]&&['settings','journal','family','armory','facilities','crisis','memorial','legacy','construction','customize','social'].includes(action))offerCoach(action);
}
function handleButton(b,confirmed=false){
  if(!b||b.disabled)return;
  if(inspectionLocked()&&!readOnlyButton(b)){toast('선택을 마친 뒤 진행할 수 있습니다.');return;}
  if(!confirmed){const preview=commandPreview(g,b.dataset,team,selected);if(preview){pendingCommand={dataset:{...b.dataset},preview,returnModal:modal,signature:JSON.stringify(captureOutcome(g))};activeCoach=null;modal='confirm-command';render();return;}}
  const track=b.dataset.cancelWork||b.dataset.demolishBuilding||b.dataset.choice!==undefined||b.dataset.resolution||b.dataset.prepare||b.dataset.facility||b.dataset.craft||['upgrade','depart','retreat','welcome-child','confirm-placement'].includes(b.dataset.action);
  const before=track?captureOutcome(g):null;
  if(b.dataset.section){section=b.dataset.section;activeCoach=null;if(section==='town'){view='settlement';offerCoach('town');}else if(section==='expedition'){if(g.expedition)view='expedition';offerCoach('expedition');}else if(section==='people'){if(!g.residents[selected]?.alive)selected=living(g)[0]?.id??0;offerCoach('resident');}else if(section==='records'){modal='journal';offerCoach('journal');}}
  if(b.dataset.founder!==undefined)founderIndex=+b.dataset.founder;
  if(b.dataset.rollFounder!==undefined){rerollDraft(founderDraft,+b.dataset.rollFounder);storeDraft();}
  if(b.dataset.lockFounder!==undefined){const i=+b.dataset.lockFounder;if(!(i===0&&creatorHeir))founderDraft.locked[i]=!founderDraft.locked[i];storeDraft();}
  if(b.dataset.swatch){const r=currentLook();if(r){r.appearance[b.dataset.swatch]=+b.dataset.value;storeDraft();}}
  if(b.dataset.placeKind){placement={type:'build',kind:b.dataset.placeKind,rotation:0,pinned:false};activeCoach=null;modal=null;view='settlement';section='town';}
  if(b.dataset.roadKind){placement={type:'road',roadKind:b.dataset.roadKind,pinned:false};activeCoach=null;modal=null;view='settlement';section='town';}
  if(b.dataset.moveBuilding){const bld=g.town.buildings.find(p=>p.id===b.dataset.moveBuilding);if(bld){placement={type:'move',kind:bld.kind,buildingId:bld.id,rotation:bld.rotation,pinned:false};modal=null;view='settlement';}}
  if(b.dataset.demolishBuilding){if(queueDemolish(g,b.dataset.demolishBuilding)){dirty=true;modal=null;toast('철거 작업을 예약했습니다. 미착수 작업은 대기열에서 취소할 수 있습니다.');}else toast('다른 작업이나 현재 거주 인원을 확인하세요.');}
  if(b.dataset.cancelWork&&cancelWork(g,+b.dataset.cancelWork))dirty=true;
  if(b.dataset.prioritizeWork&&prioritizeWork(g,+b.dataset.prioritizeWork))dirty=true;
  if(b.dataset.replayHelp){activeCoach=null;offerCoach(b.dataset.replayHelp,true);}
  if(b.dataset.action&&!['coach-prev','coach-next','coach-finish','coach-skip'].includes(b.dataset.action)&&!b.dataset.replayHelp)activeCoach=null;
  if(preferences.sound&&!audio.context)configureAudio();audio.play('click');
  if(b.dataset.person!==undefined){selected=+b.dataset.person;if(!modal)offerCoach('resident');}
  if(b.dataset.endingPerson!==undefined){selected=+b.dataset.endingPerson;modal='journal';}
  if(b.dataset.prepare&&contributeCrisis(g,b.dataset.prepare))dirty=true;
  if(b.dataset.resolution&&resolveCrisis(g,b.dataset.resolution)){modal=null;dirty=true;save();}
  if(b.dataset.view&&['settlement','expedition'].includes(b.dataset.view))view=b.dataset.view;
  if(b.dataset.memorial!==undefined){selected=+b.dataset.memorial;modal='journal';}
  if(b.dataset.heir!==undefined)heirId=+b.dataset.heir;
  if(b.dataset.speed){g.speed=+b.dataset.speed;lastSpeed=g.speed;gameClock.last=performance.now();dirty=true;}
  if(b.dataset.job&&setJob(g,selected,b.dataset.job))dirty=true;
  if(b.dataset.team!==undefined){const id=+b.dataset.team;if(canExpedition(g,id))team=team.includes(id)?team.filter(x=>x!==id):team.length<3?[...team,id]:team;}
  if(b.dataset.choice!==undefined){if(decide(g,+b.dataset.choice))dirty=true;}
  if(b.dataset.familyMode)familyMode=b.dataset.familyMode;
  if(b.dataset.guardian!==undefined){const id=+b.dataset.guardian;guardians=guardians.includes(id)?guardians.filter(x=>x!==id):guardians.length<2?[...guardians,id]:guardians;}
  if(b.dataset.front!==undefined){const index=team.indexOf(+b.dataset.front);if(index>0)[team[0],team[index]]=[team[index],team[0]];}
  if(b.dataset.personalGoal&&setPersonalGoal(g,+b.dataset.residentId,b.dataset.personalGoal))dirty=true;
  if(b.dataset.facility&&upgradeFacility(g,b.dataset.facility)){dirty=true;toast('시설을 개선했습니다. 생활과 작업의 효율이 높아집니다.');}
  if(b.dataset.autonomy!==undefined){const id=+b.dataset.autonomy;if(setAutonomy(g,id,!g.residents[id].autonomy))dirty=true;}
  if(b.dataset.craft&&craftEquipment(g,b.dataset.craft)){dirty=true;toast(g.town.legacy?'장비를 제작했습니다. 주민의 장비 칸에서 착용하세요.':'제작을 예약했습니다. 건설 담당이 완성한 뒤 장비 칸에서 착용하세요.');}
  if(b.dataset.relic!==undefined){if(activateRelic(g,b.dataset.relic||null))dirty=true;}
  if(b.dataset.route&&chooseRoute(g,b.dataset.route))dirty=true;
  if(b.dataset.guide){if(['facilities','crisis','construction'].includes(b.dataset.guide))modal=b.dataset.guide;else if(b.dataset.guide==='resident')selected=living(g)[0]?.id??0;else if(g.expedition)view='expedition';}
  if(b.dataset.tutorialPage!==undefined)tutorialPage=Number(b.dataset.tutorialPage);
  if(b.dataset.socialKind){const partner=+document.querySelector('#social-partner')?.value;if(requestConversation(g,selected,partner,b.dataset.socialKind)){dirty=true;modal=null;toast('두 주민이 교류 장소로 이동합니다. 시간을 진행해 주세요.');}else toast('두 주민의 상태와 요청 간격을 확인하세요. 같은 상대는 120초 뒤 다시 요청할 수 있습니다.');}
  if(b.dataset.action)perform(b.dataset.action);
  if(before){const rows=outcomeChanges(before,captureOutcome(g));if(rows.length){lastOutcome={title:b.querySelector('strong')?.textContent||b.textContent.trim().split('\n')[0],rows};if(b.dataset.choice===undefined)log(g,'변화 기록 · '+rows.map(outcomeLine).join(' · '),'story');}}
  render();
  if(b.dataset.section==='expedition'&&!modal)document.querySelector('.exp-content')?.scrollIntoView({block:'center',behavior:'instant'});
  if(b.dataset.action==='tutorial-resident')document.querySelector('.detail')?.scrollIntoView({block:'center',behavior:'instant'});
  if(b.dataset.action==='tutorial-expedition')document.querySelector('.exp-content')?.scrollIntoView({block:'center',behavior:'instant'});
  if(b.dataset.guide==='resident')document.querySelector('.detail')?.scrollIntoView({block:'center',behavior:preferences.motion?'smooth':'instant'});
  if(b.dataset.guide==='expedition')document.querySelector('.exp-content')?.scrollIntoView({block:'center',behavior:preferences.motion?'smooth':'instant'});
}
document.addEventListener('click',ev=>handleButton(ev.target.closest('button')));
document.addEventListener('change',ev=>{
  if(ev.target.dataset.pref){const key=ev.target.dataset.pref;if(Object.hasOwn(preferences,key)){preferences[key]=ev.target.checked;if(key==='menuHints'&&!preferences.menuHints)activeCoach=null;storePreferences();if(['sound','music','ambience'].includes(key))configureAudio();render();}return;}
  if(inspectionLocked())return;
  if(ev.target.dataset.look){const r=currentLook();if(r){r.appearance[ev.target.dataset.look]=+ev.target.value;storeDraft();render();}return;}
  if(ev.target.id==='operating-policy'){if(setOperatingPolicy(g,ev.target.value))dirty=true;render();return;}
  if(ev.target.id==='personal-goal'){const r=g.residents[selected];if(r.personalGoal.progress>0&&ev.target.value!==r.personalGoal.kind){const el=document.createElement('button');el.dataset.personalGoal=ev.target.value;el.dataset.residentId=selected;handleButton(el);return;}if(setPersonalGoal(g,selected,ev.target.value))dirty=true;render();}
  if(ev.target.id==='target'){target=ev.target.value;render();}
  if(ev.target.id==='policy')policy=ev.target.value;
  if(ev.target.id==='combat-class'){if(setCombatClass(g,selected,ev.target.value))dirty=true;render();}
  if(ev.target.id==='gear'){if(equipResident(g,selected,ev.target.value))dirty=true;render();}
  if(ev.target.id==='mentor'){if(assignMentor(g,selected,ev.target.value===''?null:+ev.target.value))dirty=true;render();}
});
function canvasScreenPoint(ev){const rect=ev.target.getBoundingClientRect();return {x:(ev.clientX-rect.left)/rect.width*1120,y:(ev.clientY-rect.top)/rect.height*650};}
function canvasPoint(ev){return toWorld(mapCamera,canvasScreenPoint(ev));}
function updatePlacement(p,pin=false){if(!placement)return;const cell={x:Math.floor(p.x/GRID.cell),y:Math.floor(p.y/GRID.cell)};
 if(placement.type==='road'){if(pin&&!placement.start){placement.start=cell;placement.cells=[cell];}else if(placement.start){placement.cells=roadLine(placement.start,cell);if(pin){placement.end=cell;placement.pinned=true;}}}
 else{placement.x=cell.x;placement.y=cell.y;if(pin)placement.pinned=true;}
 const tools=document.querySelector('.town-tools');if(tools)tools.outerHTML=townTools(g,placement);drawScene();
}
document.addEventListener('pointermove',ev=>{if(pointerGesture)return;if(ev.target.id==='world'&&placement&&!modal&&!inspectionLocked()&&!placement.pinned)updatePlacement(canvasPoint(ev));});
document.addEventListener('click',ev=>{
 if(suppressMapClick){suppressMapClick=false;return;}
 if(ev.target.id!=='world'||modal||needsDecision(g)&&!decisionPeek)return;const p=canvasPoint(ev);
 if(placement&&!inspectionLocked()){if(placement.pinned){placement.pinned=false;if(placement.type==='road'){placement.start=null;placement.end=null;}}updatePlacement(p,true);return;}
 const person=positions.find(a=>Math.hypot(a.x-p.x,a.y-p.y)<23);if(person){selected=person.id;render();return;}
 const building=buildingAt(g,p.x,p.y);if(building){selectedBuilding=building.id;modal='building';render();}
});

setInterval(()=>{if(!atTitle&&dirty&&!loadWarning&&Date.now()-lastPersist>10000)save();},1000);
document.addEventListener('input',ev=>{
  if(ev.target.id==='character-name'){const r=currentLook();if(r){r.name=ev.target.value;storeDraft();const label=document.querySelector('.founder-card.selected strong');if(label)label.textContent=r.name||'이름을 입력하세요';const caption=document.querySelector('.creator-preview>strong');if(caption)caption.textContent=r.name;const confirm=document.querySelector('[data-action=confirm-founders]');if(confirm)confirm.disabled=!validDraft(founderDraft)||!r.name.trim();const apply=document.querySelector('[data-action=confirm-customize]');if(apply)apply.disabled=!r.name.trim();}return;}

  if(ev.target.id==='volume'){preferences.volume=Number(ev.target.value)/100;audio.setVolume(preferences.volume);try{localStorage.setItem(PREFERENCE_KEY,JSON.stringify(preferences));}catch{}document.querySelector('#volume-output').textContent=`${ev.target.value}%`;}
});
document.addEventListener('keydown',ev=>{
  const dialog=document.querySelector('[role=dialog]');
  if(ev.key==='Tab'&&dialog){const controls=[...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled)')];if(controls.length){const first=controls[0],last=controls.at(-1);if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}}return;}
  if(ev.key==='Escape'&&document.querySelector('#game-tooltip')){ev.preventDefault();hideTooltip();return;}
  if(ev.key==='Escape'&&modal==='confirm-command'){ev.preventDefault();perform('cancel-command');render();return;}
  if(ev.key==='Escape'&&mapExpanded&&!modal){ev.preventDefault();mapExpanded=false;render();return;}
  if(ev.code==='Space'&&placement&&!modal&&document.querySelector('#world:hover')){spaceHeld=true;ev.preventDefault();return;}
  if(ev.code==='Space'&&pointerGesture){ev.preventDefault();return;}
  if(ev.repeat||ev.ctrlKey||ev.metaKey||ev.altKey)return;
  if(ev.key==='Escape'&&modal==='founders'){ev.preventDefault();perform('cancel-founders');render();return;}
  if(ev.key==='Escape'&&placement&&!modal&&!decisionPending()){ev.preventDefault();placement=null;render();return;}
  if(ev.key==='Escape'&&decisionPeek){ev.preventDefault();if(modal){modal=null;activeCoach=null;}else perform('resume-decision');render();return;}
  if(ev.key==='Escape'&&modal==='coach'){ev.preventDefault();finishCoach();render();return;}
  if(ev.key==='Escape'){if(modal==='settings'||modal==='help'||modal==='tutorial'||(!needsDecision(g)&&!g.crisis.ready)){ev.preventDefault();if(modal==='help')perform('begin');else{modal=null;activeCoach=null;}render();}return;}
  if(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName))return;
  const key=ev.key.toLowerCase();
  if(key==='m'){ev.preventDefault();perform('sound');render();return;}
  if(atTitle)return;
  if(key==='s'){ev.preventDefault();save(true);render();return;}
  if(modal||needsDecision(g)||journeyFrozen(g))return;
  if(ev.code==='Space'){ev.preventDefault();perform('pause');render();}
  else if(['1','2','4','8'].includes(key)){g.speed=Number(key);lastSpeed=g.speed;gameClock.last=performance.now();dirty=true;render();}
});
window.addEventListener('resize',()=>{const hud=document.querySelector('.hud');if(hud)document.documentElement.style.setProperty('--hud-height',hud.getBoundingClientRect().height+'px');});
document.addEventListener('visibilitychange',()=>{audio.visibility(document.hidden);if(!document.hidden){dialogueDisplay.update(g,performance.now(),true);gameClock.last=performance.now();}});
function animate(now){requestAnimationFrame(animate);
 const enabled=!document.hidden&&!atTitle&&!modal&&g.speed&&!journeyFrozen(g)&&!needsDecision(g);
 const result=gameClock.advance(now,g.speed,enabled,()=>{tick(g,1);dirty=true;return !journeyFrozen(g)&&!needsDecision(g);});
 if(result.stalled){g.speed=0;toast('화면 응답이 늦어져 일시정지했습니다. 배속을 눌러 이어가세요.');render();}
 if(result.steps&&(now-lastUiFrame>=180||decisionPending()||journeyFrozen(g))){lastUiFrame=now;if(document.activeElement?.tagName!=='SELECT')render();}
 if(!document.hidden&&!atTitle&&now-lastFrame>=33){lastFrame=now;drawScene(now);}
}
const hideTooltip=installTooltips();
storePreferences();requestAnimationFrame(animate);
window.addEventListener('pagehide',()=>{if(dirty&&!loadWarning)save();});
render();

document.addEventListener('wheel',ev=>{if(ev.target.id!=='world'||modal)return;ev.preventDefault();zoomAt(mapCamera,canvasScreenPoint(ev),Math.exp(-ev.deltaY*.0015));drawScene();const label=document.querySelector('.map-controls strong');if(label)label.textContent=Math.round(mapCamera.zoom*100)+'%';},{passive:false});
document.addEventListener('keydown',ev=>{if(ev.code==='Space'&&!['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName))spaceHeld=true;});
document.addEventListener('keyup',ev=>{if(ev.code==='Space')spaceHeld=false;});
window.addEventListener('blur',()=>{spaceHeld=false;pointerGesture=null;gameClock.last=null;});
document.addEventListener('pointerdown',ev=>{if(ev.target.id!=='world'||modal||![0,1].includes(ev.button))return;pointerGesture={id:ev.pointerId,x:ev.clientX,y:ev.clientY,lastX:ev.clientX,lastY:ev.clientY,panning:ev.button===1||spaceHeld||!placement,moved:false};ev.target.setPointerCapture(ev.pointerId);if(ev.button===1)ev.preventDefault();});
document.addEventListener('pointermove',ev=>{if(ev.target.id==='world'){const p=canvasScreenPoint(ev);bubblePointer=p;bubbleHover=bubbleBoxes.some(b=>p.x>=b.x&&p.x<=b.x+b.width&&p.y>=b.y&&p.y<=b.y+b.height);}else{bubblePointer=null;bubbleHover=false;}if(!pointerGesture||pointerGesture.id!==ev.pointerId)return;const a=pointerGesture;if(!a.moved&&Math.hypot(ev.clientX-a.x,ev.clientY-a.y)>6)a.moved=true;if(a.moved&&a.panning){const rect=ev.target.getBoundingClientRect();pan(mapCamera,(ev.clientX-a.lastX)*1120/rect.width,(ev.clientY-a.lastY)*650/rect.height);drawScene();}a.lastX=ev.clientX;a.lastY=ev.clientY;});
document.addEventListener('pointerup',ev=>{if(pointerGesture?.id!==ev.pointerId)return;suppressMapClick=pointerGesture.moved;pointerGesture=null;setTimeout(()=>suppressMapClick=false,0);});
document.addEventListener('pointercancel',()=>{pointerGesture=null;});
