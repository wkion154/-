import {extraBackgrounds,extraVoices} from './expansion-data.js';
import {createProfile,validProfile} from './abilities.js';
import {defaultAppearance,validAppearance} from './appearance.js';
export const backgrounds={
 farmer:{name:'작은 농장의 일꾼',text:'버려진 밭을 돌보며 먹을 것을 구해 왔다.',role:'농사',bonus:'식량 생산 +15%'},
 carpenter:{name:'떠돌이 목수',text:'여행길마다 지붕과 도구를 고쳐 주었다.',role:'건설',bonus:'자재 수집·건설 작업 +15%'},
 herbalist:{name:'변두리 약초꾼',text:'풀과 붕대로 사람들을 돌보며 살아왔다.',role:'치료',bonus:'의약품 수집·거점 치료 +15%'},
 keeper:{name:'옛 피난처의 돌보미',text:'낯선 사람들과 식탁을 나누며 긴 겨울을 견뎠다.',role:'휴식',bonus:'휴식 중 스트레스 회복 +15%'},
};
Object.assign(backgrounds,extraBackgrounds);
const pool=['유나','도윤','미루','하람','서린','노아','가온','재이','이솔','여울','은재','하늬','단우','나린','시우','보리','아람','해온','온유','수안'];
const traits=['다정함','용감함','호기심','신중함','끈기','낙천적',...Object.keys(extraVoices)];
function rng(seed){let state=seed>>>0;return ()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};}
export function generateFounder(seed,slot=0){
 const random=rng((seed+Math.imul(slot+1,2654435761))>>>0),pick=n=>Math.floor(random()*n);
 const a=defaultAppearance(slot);for(const [k,n] of Object.entries({hair:6,skin:6,hairColor:6,coat:8,face:4,accessory:4}))a[k]=pick(n);
 const background=Object.keys(backgrounds)[pick(Object.keys(backgrounds).length)];const r={name:pool[pick(pool.length)],age:18+pick(25),trait:traits[pick(traits.length)],skill:2+pick(3),background,appearance:a};r.profile=createProfile(seed,slot,r);return r;
}
export function validFounder(r){return !!r&&typeof r.name==='string'&&r.name.trim().length>0&&r.name.length<=24&&Number.isInteger(r.age)&&r.age>=16&&r.age<60&&traits.includes(r.trait)&&Number.isInteger(r.skill)&&r.skill>=2&&r.skill<=4&&Object.hasOwn(backgrounds,r.background)&&validAppearance(r.appearance)&&(r.profile===undefined||validProfile(r.profile));}
export function makeDraft(seed){return {version:1,seed:seed>>>0,roll:0,locked:[false,false,false,false],founders:Array.from({length:4},(_,i)=>generateFounder(seed,i))};}
export function rerollDraft(draft,slot=null){
 if(!validDraft(draft)||slot!==null&&(!Number.isInteger(slot)||slot<0||slot>3))return false;
 draft.roll++;for(let i=0;i<4;i++)if(!draft.locked[i]&&(slot===null||slot===i))draft.founders[i]=generateFounder((draft.seed+Math.imul(draft.roll,1013904223))>>>0,i);return true;
}
export function validDraft(d){return !!d&&d.version===1&&Number.isInteger(d.seed)&&d.seed>=0&&d.seed<=4294967295&&Number.isInteger(d.roll)&&d.roll>=0&&Array.isArray(d.locked)&&d.locked.length===4&&d.locked.every(v=>typeof v==='boolean')&&Array.isArray(d.founders)&&d.founders.length===4&&d.founders.every(validFounder);}
