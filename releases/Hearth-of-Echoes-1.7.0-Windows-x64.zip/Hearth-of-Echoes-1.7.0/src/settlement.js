import {extraFacilities,personaDefs} from './expansion-data.js';
import {extraGoalRows,metric,bonus as effectBonus} from './expansion-effects.js';
import {abilitiesActive,traitFactor,rewardPractice} from './abilities.js';
import {hasSpec,researchDefs,projectDefs} from './development-data.js';
// Settlement rules receive game hooks instead of importing the simulation.
export const facilities={
  farm:{name:'밭과 저장고',icon:'◒',description:'농사 생산 +25%씩',bonus:level=>level===0?'야외 채집 효율 65%':`경작 효율 ${100+(level-1)*25}%`},
  workshop:{name:'작업장',icon:'⚒',description:'건설 생산 +20%씩',bonus:level=>level===0?'야외 수집 효율 80%':`작업장 생산 효율 ${100+(level-1)*20}%`},
  clinic:{name:'의무실',icon:'✚',description:'치료·부상 회복 +25%씩',bonus:level=>level===0?'응급처치 효율 65%':`치료 효율 ${100+(level-1)*25}%`},
  dorm:{name:'숙소',icon:'☾',description:'휴식 중 피로 회복 +30%씩',bonus:level=>level===0?'야영 휴식 효율 80%':`피로 회복 효율 ${100+(level-1)*30}% · 잠자리 추가`},
  lounge:{name:'공동 식당',icon:'☕',description:'휴식·교류의 외로움 회복 +30%씩',bonus:level=>level===0?'야영 교류 효율 80%':`교류 회복 효율 ${100+(level-1)*30}%`},
  school:{name:'배움터',icon:'⌑',description:'배움 속도 +20%씩',bonus:level=>level===0?'자율 배움 효율 80%':`교육 효율 ${100+(level-1)*20}%`},
};
export const goalTypes={
  learn:{name:'새로운 것을 배우기',target:2,unit:'숙련',description:'목표를 정한 뒤 숙련 2 성장'},
  friend:{name:'마음을 나눌 친구',target:35,unit:'관계',description:'살아 있는 동료 한 명과 관계 35 달성'},
  explore:{name:'경계 너머의 길잡이',target:2,unit:'완주',description:'목표를 정한 뒤 원정 2회 완주'},
  build:{name:'더 좋은 보금자리',target:1,unit:'개선',description:'시설 건설 또는 개별 개선 작업에 참여'},
  care:{name:'누군가의 회복 돕기',target:20,unit:'치료',description:'거점에서 치료 역할로 다른 주민의 체력 20 회복'},
  family:{name:'다음 세대의 보호자',target:1,unit:'가족',description:'아이의 보호자가 되기'},
};
for(const [id,d] of Object.entries(extraFacilities))facilities[id]={name:d.name,icon:d.icon,description:Object.keys(d.effects).map(k=>({food:'식량 보조',wood:'자재 보조',heal:'치료 보조',rest:'휴식 보조',social:'교류 보조',cover:'정찰 보조',build:'공사 보조',attack:'전투 공격 보조',defense:'마을 방어 보조',questFood:'의뢰 보상 보조',upkeep:'식량 소비 절약',research:'연구 보조'})[k]).join(' · '),bonus:level=>level?Object.entries(d.effects).map(([k,v])=>`${{food:'식량',wood:'자재',build:'공사',rest:'휴식',heal:'치료',research:'연구',learning:'경험',social:'위로',cover:'정찰 완화',defense:'자동 방어',attack:'공격',questFood:'의뢰 식량',upkeep:'유지비 절약'}[k]} +${Number((v*level*(['food','wood','build','rest','heal','research','learning','social','cover','upkeep'].includes(k)?100:1)).toFixed(1))}${['food','wood','build','rest','heal','research','learning','social','cover','upkeep'].includes(k)?'%':''}`).join(' · '):'미건설'};
for(const [id,name,source,target,description] of extraGoalRows)goalTypes[id]={name,source,target,description,unit:'진행'};
export function facilityDefaults(){return Object.fromEntries(Object.keys(facilities).map(k=>[k,Object.hasOwn(extraFacilities,k)?0:1]));}
export function makeGoal(kind,skill,g=null){return {kind,progress:0,done:false,startSkill:skill,baseline:g?metric(g,goalTypes[kind]?.source):0};}
export function settlementDefaults(id,skill){
  return {needs:{hunger:12,fatigue:10,loneliness:12},autonomy:true,routine:'assigned',
    personalGoal:makeGoal(Object.keys(goalTypes)[id%6],skill),completedGoals:[]};
}
export function facilityCost(g,id){const level=g.facilities[id];return {wood:18*level,...(level>=2?{records:1}:{})};}
export function effectiveRole(r){return r.routine==='recover'?'휴식':r.routine==='socialize'?'교류':r.workRole||r.job;}
export function activityLabel(r){
 const actual=r.workRole||effectiveRole(r),label=r.workLabel||actual;
 if(r.routine==='recover'&&actual==='휴식')return `${r.job} → 자율 휴식`;
 if(r.routine==='socialize'&&actual==='교류')return `${r.job} → 교류`;
 return actual!==r.job?`${r.job} → 자동 ${label}`:label;
}
export function needEfficiency(r){return (r.needs.hunger>=80?.65:1)*(r.needs.fatigue>=70?.75:1);}
const clamp=n=>Math.max(0,Math.min(100,n));
export function updateNeeds(g,home,fed,{relationship,changeRelationship,log}){
  const atHome=new Set(home.map(r=>r.id));
  for(const r of g.residents.filter(r=>r.alive)){
    const limits=abilitiesActive(g)?personaDefs[r.trait]:null;const n=r.needs,isHome=atHome.has(r.id),before=r.routine;
    n.hunger=clamp(n.hunger+(!isHome||fed?-.22:.28));
    if(isHome){
      if(!r.autonomy)r.routine='assigned';
      else if((!g.town?.legacy&&(r.hp<90||r.stress>40||r.injury>.5||r.routine==='recover'&&(r.hp<95||r.stress>22)))||n.fatigue>=(limits?.fatigue||80)||r.routine==='recover'&&n.fatigue>30)r.routine='recover';
      else if(home.length>1&&(n.loneliness>=(limits?.social||75)||r.routine==='socialize'&&n.loneliness>35))r.routine='socialize';
      else r.routine='assigned';
      if(before!==r.routine&&r.routine!=='assigned')log(g,`${r.name}가 ${r.routine==='recover'?'지친 몸을 쉬게 한다':'동료와 이야기할 시간을 갖는다'}. 원래 역할은 유지된다.`,'story');
      const role=effectiveRole(r),rest=role==='휴식',social=role==='교류';
      n.fatigue=clamp(n.fatigue+(rest?-.32*(1+effectBonus(g,'rest'))*(g.facilities.dorm?1+(g.facilities.dorm-1)*.3:.8)*(abilitiesActive(g)?traitFactor(r,'rest'):1)*(hasSpec(g,'dorm','quiet')?1.25:1):social?-.1:role==='가르침'?.04:role==='배움'?.055:.09));
      const friend=home.some(o=>o.id!==r.id&&relationship(g,r.id,o.id)>=15);
      n.loneliness=clamp(n.loneliness+((social||rest&&friend)?-.20*(g.facilities.lounge?1+(g.facilities.lounge-1)*.3:.8):.045));
      if(social&&g.time%12===0&&g.social?.request?.who!==r.id&&g.social?.request?.other!==r.id){const partner=home.filter(o=>o.id!==r.id).sort((a,b)=>relationship(g,r.id,b.id)-relationship(g,r.id,a.id))[0];if(partner)changeRelationship(g,r.id,partner.id,2);}
    }else{
      r.routine='assigned';n.fatigue=clamp(n.fatigue+.14);n.loneliness=clamp(n.loneliness-.04);
    }
    r.stress=clamp(r.stress+(n.hunger>=80?.06:0)+(n.fatigue>=80?.04:0)+(n.loneliness>=75?.035:0));
  }
}
export function recordGoal(g,id,kind,amount){const goal=g.residents[id]?.personalGoal;if(goal&&!goal.done&&goal.kind===kind)goal.progress+=amount;}
export function updateGoals(g,{relationship,memory,log}){
  for(const r of g.residents.filter(r=>r.alive)){
    const goal=r.personalGoal;if(goal.done)continue;
    if(goal.kind==='learn')goal.progress=Math.max(0,r.skill-goal.startSkill);
    if(goal.kind==='friend')goal.progress=Math.max(0,...g.residents.filter(o=>o.alive&&o.id!==r.id).map(o=>relationship(g,r.id,o.id)));
    if(goal.kind==='family')goal.progress=g.residents.filter(o=>o.guardians.includes(r.id)).length;
    const def=goalTypes[goal.kind];if(def.source)goal.progress=Math.max(goal.progress,metric(g,def.source)-(goal.baseline||0));goal.progress=Math.min(def.target,goal.progress);
    if(goal.progress<def.target)continue;
    rewardPractice(g,r,{learn:'education',friend:'social',explore:'scouting',build:'construction',care:'medicine',family:'social'}[goal.kind]||'education',180);goal.done=true;r.completedGoals.push(goal.kind);r.stress=clamp(r.stress-12);r.skill++;g.records++;
    memory(g,r,`개인 목표 「${def.name}」를 이루었다. 자신의 삶에 작은 확신을 얻었다.`);
    log(g,`${r.name}의 목표 달성 · ${def.name}. 숙련 +1 · 스트레스 -12 · 기록 +1.`,'story');
  }
}
export function readyStory(g){
  const home=id=>g.residents[id]?.alive&&!g.expedition?.team.includes(id);
  return g.storyQueue.find(e=>e.due<=g.time&&home(e.who)&&home(e.other));
}
export function validateSettlement(g,{finite,int,validId}){
  if(!g.facilities||typeof g.facilities!=='object'||Array.isArray(g.facilities)||Object.keys(g.facilities).length!==Object.keys(facilities).length||Object.keys(facilities).some(k=>!int(g.facilities[k],0,3))
    ||!int(g.routineCount)||!Array.isArray(g.storyQueue)||g.storyQueue.length>24
    ||g.storyQueue.some(e=>!e||!['reconcile','trainingResult'].includes(e.kind)||!validId(e.who)||!validId(e.other)||e.who===e.other||!finite(e.due)))return false;
  return !g.residents.some(r=>!r.needs||Object.keys(r.needs).length!==3||['hunger','fatigue','loneliness'].some(k=>!finite(r.needs[k],0,100))
    ||typeof r.autonomy!=='boolean'||!['assigned','recover','socialize'].includes(r.routine)||(!r.autonomy&&r.routine!=='assigned')
    ||!r.personalGoal||!Object.hasOwn(goalTypes,r.personalGoal.kind)||!finite(r.personalGoal.progress,0,goalTypes[r.personalGoal.kind].target)
    ||typeof r.personalGoal.done!=='boolean'||!finite(r.personalGoal.startSkill,1)||(r.personalGoal.baseline!==undefined&&!int(r.personalGoal.baseline))
    ||!Array.isArray(r.completedGoals)||new Set(r.completedGoals).size!==r.completedGoals.length||r.completedGoals.some(k=>!Object.hasOwn(goalTypes,k))
    ||(r.personalGoal.done&&r.personalGoal.progress!==goalTypes[r.personalGoal.kind].target)||r.personalGoal.done!==r.completedGoals.includes(r.personalGoal.kind));
}

export function goalFeasible(g,kind){const d=goalTypes[kind];if(!d?.source)return true;if(g.campaign.mode!=='settlement')return false;const maximum={research:Object.keys(researchDefs).length,project:Object.keys(projectDefs).length,relic:27,visit:24,reputation:270}[d.source];return maximum===undefined||metric(g,d.source)+d.target<=maximum;}
