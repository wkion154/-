import {defensePolicies,extraFacilities,extraEquipment} from './expansion-data.js';
import {questDefs,factions} from './frontier-data.js';
import {questReward,defenseForecast} from './frontier.js';
import {resourceText} from './frontier-view.js';
import {researchDefs,projectDefs,specializationDefs} from './development-data.js';
import {masteryDefs,scoutingCover} from './abilities.js';
import {equipment,combatClasses} from './combat.js';
import {facilities} from './settlement.js';
import {preparationTypes,crisisTypes} from './journey.js';
import {buildingDefs,townCapacity} from './town.js';
import {portraitSVG} from './appearance.js';
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number=n=>Number(n).toFixed(1).replace(/\.0$/,'');
export function commandPreview(g,d,team=[],selected=0){
 if(d.claimQuest){const q=questDefs[d.claimQuest];if(q)return {title:q.name+' 의뢰 보상을 받을까요?',cost:q.cost,description:'보상 · '+resourceText(questReward(g,q.id))+' · '+factions[q.faction].name+' 평판 +2',detail:'납품 의뢰는 이때 재료를 소비합니다. 탐사·방어 목표는 수락 후 수행분만 인정하며 보상은 한 번 지급합니다.',label:'조건 확인·보상 수령'};}
 if(d.abandonQuest)return {title:'이 의뢰를 포기할까요?',description:'현재 의뢰를 취소합니다. 보상은 지급하지 않습니다.',detail:'다음 게시판에 다시 나올 수 있지만 새로 수락하면 탐사·방어 진행을 다시 셉니다.',label:'의뢰 포기'};
 if(d.factionTrade)return {title:factions[d.factionTrade].name+'와 보답 교역할까요?',cost:{wood:20,records:1},description:equipment[factions[d.factionTrade].gear].name+'을 보관함에 지급합니다. 주민에게 직접 착용해야 합니다.',detail:'이 세력과의 교역 완료 기록을 남깁니다.',label:'물자 지불·장비 받기'};
 if(d.defensePolicy){const copy=structuredClone(g);copy.frontier.raid.policy=d.defensePolicy;const x=defenseForecast(copy);return {title:'마을 방어 방침을 바꿀까요?',description:defensePolicies[d.defensePolicy].name+' · 현재 예상 방어 '+x.strength+' / 침입 '+x.threat,detail:'침입이 시작되기 전까지 다시 바꿀 수 있습니다. 전력은 침입 도착 시 확정하며 정면 방어는 패배 시 피해가 더 큽니다.',label:'이 방침으로 준비'};}
 if(d.action==='prepare-raid')return {title:'이번 침입 대비에 물자를 투입할까요?',cost:{wood:15,food:5},description:'이번 자동 방어력 +3 · 도착 전 최대 두 번.',detail:'계절 위기 대비와는 별도입니다. 물자는 소비하며 다음 침입에는 다시 준비합니다.',label:'이번 방어에 투입'};
 if(d.action==='enable-settlement')return {title:'같은 마을을 장기 정착 방식으로 전환할까요?',description:`주민·현재 나이·시설·지형은 유지합니다. 생애 속도 ${g.yearSeconds/60}분/년 → 300분/년. 분야 능력과 특성 효과를 적용합니다.`,detail:'진행 중 원정·선택이 있으면 전환할 수 없습니다. 이후 위기는 같은 마을의 계절 사건으로 이어집니다. 이전 방식으로 되돌리는 버튼은 없으므로 먼저 저장을 내보내 보관할 수 있습니다.',label:'기존 마을 보존·장기 정착 전환'};
 if(d.mastery)return {title:masteryDefs[d.mastery].name+'을 선택할까요?',description:masteryDefs[d.mastery].text,detail:'이 주민은 한 가지 전문 분야를 선택합니다. 확정 후 교체하지 않습니다.',label:'전문 분야 확정'};
 if(d.research){const r=researchDefs[d.research];return {title:r.name+' 연구를 시작할까요?',cost:r.cost,description:r.text,detail:`배움터에 도착한 배움·가르침 담당이 연구 작업 ${r.work}을 진행합니다. 비용은 예약하며 중단하면 미사용분만 반환합니다.`,label:'비용 예약·연구 시작'};}
 if(d.project){const r=projectDefs[d.project];return {title:r.name+' 사업을 시작할까요?',cost:r.cost,description:r.text,detail:`일반 공사를 마친 건설 담당이 실제 이동 후 작업 ${r.work}을 진행합니다. 자동 완성되지 않습니다.`,label:'비용 예약·사업 시작'};}
 if(d.specialize){const r=specializationDefs[d.specialize].options[d.option];return {title:r.name+'으로 전문화할까요?',cost:{wood:12,records:1},description:r.text,detail:'건설 담당이 작업 90을 완료해야 적용됩니다. 기존 전문화는 완성 전까지 유지합니다.',label:'전문화 작업 예약'};}
 if(d.cancelDevelopment){const task=g.development[d.cancelDevelopment];if(task){const r=(d.cancelDevelopment==='activeResearch'?researchDefs:projectDefs)[task.key];return {title:r.name+'을 중단할까요?',description:'반환: '+Object.entries(r.cost).map(([k,n])=>`${{wood:'자재',food:'식량',medicine:'의약품',records:'기록'}[k]} ${Math.floor(n*(1-task.progress/r.work))}`).join(', '),detail:'이미 사용한 비용과 진행도는 복구하지 않습니다.',label:'중단·미사용 비용 반환'};}}
 if(d.action==='retire'){const r=g.residents[selected];return {title:r.name+'가 현역에서 은퇴할까요?',description:r.job+' → 가르침. 나이·경험·기억은 유지하고 다음 세대를 돕습니다.',detail:'은퇴 후에는 원정에 출정할 수 없습니다.',label:'현역 은퇴·가르침으로 전환'};}
 if(d.action==='retreat'&&g.expedition){const e=g.expedition;return {title:'현재 원정을 마치고 돌아올까요?',description:`확보한 자재 ${Math.floor(e.loot)}·식량 ${e.lootFood||0}·의약품 ${e.lootMedicine}·기록 ${e.bonusRecords}과 남은 구급약 ${e.medkits}개를 가져와 귀환합니다.`,detail:'현재 탐사의 남은 지점은 중단됩니다. 아직 완주하지 않았다면 이번 원정의 지역 완주 보상은 얻지 못합니다.',label:'원정 중단·귀환'};}
 if(d.personalGoal){const r=g.residents[+d.residentId];return {title:r.name+'의 개인 목표를 바꿀까요?',description:'현재 미완료 목표 진행 '+r.personalGoal.progress.toFixed(1)+' → 0. 달성한 목표의 기록과 보상 이력은 유지합니다.',detail:'새 목표를 실제로 진행해야 다음 보상을 받을 수 있습니다.',label:'진행 초기화·새 목표 선택'};}
 if(d.action==='upgrade')return {title:'피난처를 확장할까요?',cost:{wood:25*g.level},description:`피난처 ${g.level} → ${g.level+1}단계. 주민 정원 ${townCapacity(g)} → ${townCapacity({...g,level:g.level+1})}명.`,detail:`농사·자재 수집·휴식에 적용되는 기본 계수 ${Math.round((1+(g.level-1)*.2+Math.min(10,g.legacyPoints)*.05)*100)}% → ${Math.round((1+g.level*.2+Math.min(10,g.legacyPoints)*.05)*100)}%. 실제 생산과 회복은 피로·부상·시설 등의 영향도 받습니다.`,label:'자재를 써서 확장'};
 if(d.action==='depart')return {title:'이 원정대를 출발시킬까요?',people:team.map(id=>`<span>${portraitSVG(g.residents[id])}<strong>${esc(g.residents[id].name)}</strong><small>${esc(combatClasses[g.residents[id].combatClass].name)}</small></span>`).join(''),cost:{food:2+team.length*2,medicine:Math.min(team.length,Math.floor(g.medicine))},description:`출정 ${team.length}명: ${team.map(id=>g.residents[id].name).join(', ')}.`,detail:`정찰 준비로 받는 전투 피해 ${(scoutingCover(g,team)*100).toFixed(1)}% 완화. 거점 잔류: ${g.residents.filter(r=>r.alive&&!team.includes(r.id)).map(r=>r.name+' · '+r.job).join(', ')||'없음'}. 출정자는 생활 일을 하지 않습니다. 체력 35 미만·스트레스 85 이상 또는 장기전 한도로 자동 철수할 수 있습니다.`,label:'이 편성으로 출발'};
 if(d.facility){const f=facilities[d.facility],level=g.facilities[d.facility];return {title:f.name+'을 개선할까요?',cost:{wood:18*level,...(level>=2?{records:1}:{})},description:f.bonus(level)+' → '+f.bonus(level+1),detail:g.town.legacy&&!extraFacilities[d.facility]?'확정하면 개선합니다.':'재료를 예약하고 건설 담당이 개선 작업을 완성해야 적용됩니다.',label:g.town.legacy?'시설 개선':'개선 작업 예약'};}
 if(d.craft){const item=equipment[d.craft];return {title:item.name+' 제작을 진행할까요?',cost:item.cost,description:item.description||'원정 장비를 제작합니다.',detail:g.town.legacy&&!extraEquipment[d.craft]?'완성 뒤 주민의 장비 칸에서 착용하세요.':'건설 담당이 작업을 완성한 뒤 보관함에 들어갑니다. 이후 주민에게 착용해야 효과가 납니다.',label:g.town.legacy?'장비 제작':'제작 작업 예약'};}
 if(d.demolishBuilding){const b=g.town.buildings.find(b=>b.id===d.demolishBuilding);if(b)return {title:buildingDefs[b.kind].name+'을 철거할까요?',description:`작업 20 후 철거됩니다. 기본 자재 ${Math.floor((buildingDefs[b.kind].cost.wood||0)*.4)}을 회수합니다.`,detail:'완성된 시설의 기능을 잃습니다. 필요한 잠자리가 부족해지는 숙소 철거는 실행할 수 없습니다.',label:'철거 작업 예약'};}
 if(d.prepare){const def=preparationTypes[d.prepare];return {title:def.name+'에 물자를 투입할까요?',cost:def.cost,description:`대비 횟수 ${g.crisis.preparations[d.prepare]} → ${g.crisis.preparations[d.prepare]+1} / 3. 대응 점수 +${crisisTypes[g.crisis.kind].weights[d.prepare]}.`,detail:'투입한 물자는 대비용으로 소비되며 돌려받지 않습니다.',label:'이 물자를 대비에 투입'};}
 if(d.cancelWork){const q=g.town.queue.find(q=>q.id===+d.cancelWork);if(q)return {title:'예약 작업을 취소할까요?',description:`진행 ${number(q.progress)} / ${q.work}. 미사용 재료 반환: ${Object.entries(q.cost).map(([key,n])=>`${{wood:'자재',food:'식량',medicine:'의약품',records:'기록'}[key]} ${Math.floor(n*(1-q.progress/q.work))}`).join(', ')||'없음'}.`,detail:'이미 사용한 재료와 진행도는 복구하지 않습니다.',label:'작업 취소·미사용 재료 반환'};}
 return null;
}
