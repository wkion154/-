export const WORLD={width:1120,height:650};
export function camera(){return {zoom:1,x:0,y:0};}
export function constrain(c){c.zoom=Math.max(1,Math.min(3,c.zoom));c.x=Math.max(WORLD.width*(1-c.zoom),Math.min(0,c.x));c.y=Math.max(WORLD.height*(1-c.zoom),Math.min(0,c.y));return c;}
export function toWorld(c,p){return {x:(p.x-c.x)/c.zoom,y:(p.y-c.y)/c.zoom};}
export function zoomAt(c,p,factor){const before=toWorld(c,p);c.zoom*=factor;constrain(c);c.x=p.x-before.x*c.zoom;c.y=p.y-before.y*c.zoom;return constrain(c);}
export function pan(c,dx,dy){c.x+=dx;c.y+=dy;return constrain(c);}
export function wrapText(measure,text,maxWidth){
 const lines=[];let line='';for(const word of String(text).split(/(\s+)/)){if(measure(line+word)<=maxWidth){line+=word;continue;}if(line.trim()){lines.push(line.trim());line='';}for(const char of word){if(measure(line+char)>maxWidth&&line){lines.push(line.trim());line='';}line+=char;}}if(line.trim())lines.push(line.trim());return lines.length?lines:[''];
}
export function clockReading(time){const minutes=((time%60)*24+288)%1440;return {hours:Math.floor(minutes/60),minutes:Math.floor(minutes%60),day:Math.floor(time/60)+1};}
