import {icon} from './ui-art.js';
import {portraitSVG} from './appearance.js';
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const card=(symbol,title,caption)=>`<div class="lesson-card">${icon(symbol)}<strong>${title}</strong><small>${caption}</small></div>`;
const arrow='<span class="lesson-arrow" aria-hidden="true">→</span>';
export function tutorialVisual(g,index){
 const people=g.residents.filter(r=>r.alive).slice(0,g.town.legacy?6:4),faces=people.map(r=>`<span class="lesson-person">${portraitSVG(r)}<b>${esc(r.name)}</b></span>`).join('');
 const panels=[
 `<div class="lesson-people">${faces}</div><div class="lesson-flow">${card('dice','① 네 사람 선택','새 게임에서 주사위·잠금')}${arrow}${card('town','② 나의 야영지','이름·외형을 꾸미고 확정')}${arrow}${card('flag','③ 함께 살아가기','건설·원정·회복을 결정')}</div>`,
 `<div class="lesson-layout">${card('people','① 왼쪽 · 주민','누구인지·몸과 마음 확인')}${card('town','② 가운데 · 마을','휠 확대 · 드래그 · 대상 클릭')}${card('shield','③ 오른쪽 · 원정','두 명 또는 세 명을 편성')}</div><div class="lesson-resources">${['food','wood','medicine','records'].map((id,i)=>card(id,['식량','자재','의약품','기록'][i],['생활·원정','건설·제작','치료·구급약','지식·대비'][i])).join('')}</div>`,
 `<div class="lesson-flow">${card('farm','① 시설 선택','밭이나 작업대')}${arrow}${card('eye','② 위치·입구 확인','지도에서 눌러 청사진 배치')}${arrow}${card('build','③ 작업 예약','건설 담당이 이동해 완공')}</div><div class="lesson-link">${icon('wood')} 예약 자재 <span>→</span> ${icon('build')} 담당 주민 <span>→</span> <div class="lesson-progress"><i></i></div> 완공</div>`,
 `<div class="lesson-people">${faces}</div><div class="lesson-layout">${card('shield','① 2인 또는 3인','첫 사람은 전방 · 나머지는 후방')}${card('food','② 보급 확인','2인 식량 6 / 3인 식량 8')}${card('town','③ 남은 사람 확인','거점의 농사·건설·치료')}</div><p class="lesson-link">${icon('flag')} 출정자는 마을 일을 쉽니다. 준비 후 자동 전투, 갈림길은 직접 선택합니다.</p>`,
 `<div class="lesson-flow">${card('heart','① 귀환자 확인','몸·마음·부상과 철수 이유')}${arrow}${card('kit','② 치료와 휴식','자율 회복 후 원래 업무 복귀')}${arrow}${card('chat','③ 다음을 준비','대화·장비·원정 회고')}</div><div class="lesson-threshold"><span>체력 <b>35 미만 → 철수</b></span><div class="lesson-meter"><i></i><em></em></div><span>스트레스 <b>85 이상 → 철수</b></span></div>`,
 `<div class="lesson-layout">${card('build','마을 발전','시설·길·제작·새 동료')}${card('flag','탐험과 발견','장비를 준비해 다음 지역으로')}${card('shield','위기 대비','물자 투입 → 대응 게이지')}</div><div class="lesson-flow">${card('food','보유 물자','창고 잔액')}${arrow}${card('hand','대비에 투입','실제 소비를 확인')}${arrow}${card('check','공동체 대응','점수가 실제로 증가')}</div>`
 ];
 return `<section class="tutorial-visual" aria-label="${index+1}단계 그림 안내">${panels[index]}</section>`;
}
