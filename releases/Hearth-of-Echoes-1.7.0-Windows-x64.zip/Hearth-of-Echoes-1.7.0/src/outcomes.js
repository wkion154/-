import {factions} from './frontier-data.js';
import {defensePolicies} from './expansion-data.js';
import {abilityDefs,abilitiesActive} from './abilities.js';
import {equipment} from './combat.js';
import {endingTypes} from './journey.js';
export const amount=value=>typeof value==='number'?new Intl.NumberFormat('ko-KR',{maximumFractionDigits:2}).format(value):String(value);
export function captureOutcome(g){return {
 expeditionLoot:g.expedition?{food:g.expedition.lootFood||0,wood:g.expedition.loot,medicine:g.expedition.lootMedicine,records:g.expedition.bonusRecords}:null,
 frontier:g.frontier?{reputation:{...g.frontier.reputation},completed:g.frontier.completed,prepared:g.frontier.raid.prepared,policy:g.frontier.raid.policy}:null,
 resources:Object.fromEntries(['food','wood','medicine','records'].map(k=>[k,g[k]])),inventory:{...g.inventory},relationships:{...g.relationships},
 residents:g.residents.map(r=>({...Object.fromEntries(['id','name','hp','stress','skill','injury','trauma','job','trait','retired','alive','gear'].map(k=>[k,r[k]])),abilityLevels:abilitiesActive(g)?{...r.profile.levels}:null,abilityXP:abilitiesActive(g)?{...r.profile.xp}:null,mastery:r.profile?.mastery||null})),
 season:g.campaign?.mode==='settlement'?g.campaign.season:null,
 goals:g.residents.reduce((n,r)=>n+r.completedGoals.length,0),ending:g.ending?.kind??null,
 };}
const resourceLabels={food:'식량',wood:'자재',medicine:'의약품',records:'공동체 기록'};
const stats={hp:'체력',stress:'스트레스',skill:'숙련',injury:'부상',trauma:'후유증',job:'생활 초점',trait:'기질',retired:'현역 상태',alive:'생애 상태',gear:'착용 장비'};
export function outcomeChanges(before,after){
 const rows=[];
 const add=(key,label,a,b,positive=true)=>{if(a===b)return;const numeric=typeof a==='number'&&typeof b==='number',delta=numeric?b-a:null;rows.push({key,label,before:a,after:b,delta,tone:numeric?((delta>0)===positive?'gain':'loss'):'neutral'});};
 if(before.expeditionLoot&&after.expeditionLoot)for(const [k,label] of Object.entries(resourceLabels))add('loot:'+k,'원정 전리품 · '+label,before.expeditionLoot[k],after.expeditionLoot[k]);
 if(before.frontier&&after.frontier){for(const [key,label] of Object.entries(factions).map(([id,d])=>[id,d.name]))add('reputation:'+key,label+' 평판',before.frontier.reputation[key],after.frontier.reputation[key]);add('quests','완료 의뢰',before.frontier.completed,after.frontier.completed);add('raid-prepared','침입 대비 물자 투입',before.frontier.prepared,after.frontier.prepared);add('defense-policy','방어 방침',defensePolicies[before.frontier.policy].name,defensePolicies[after.frontier.policy].name);}
 for(const [k,label] of Object.entries(resourceLabels))add(k,label,before.resources[k],after.resources[k]);
 for(const r of after.residents){const old=before.residents.find(p=>p.id===r.id);if(!old)continue;for(const [key,label] of Object.entries(stats))add(`${r.id}:${key}`,`${r.name} · ${key==='skill'&&r.abilityLevels?'기초 경험':label}`,old[key],r[key],!['stress','injury','trauma'].includes(key));}
 for(const r of after.residents){const old=before.residents.find(p=>p.id===r.id);if(!old?.abilityLevels||!r.abilityLevels)continue;for(const [key,def] of Object.entries(abilityDefs)){if(old.abilityLevels[key]!==r.abilityLevels[key])add('ability:'+r.id+':'+key,`${r.name} · ${def.name}`,old.abilityLevels[key],r.abilityLevels[key]);else if(old.abilityXP[key]!==r.abilityXP[key])add('experience:'+r.id+':'+key,`${r.name} · ${def.name} 경험`,Math.floor(old.abilityXP[key]),Math.floor(r.abilityXP[key]));}if(old.mastery!==r.mastery)add('mastery:'+r.id,`${r.name} · 전문 분야`,old.mastery?abilityDefs[old.mastery].name:'미선택',r.mastery?abilityDefs[r.mastery].name:'미선택');}
 for(const [key,value] of Object.entries(after.relationships)){const old=before.relationships[key]||0;if(value===old)continue;const ids=key.split(':').map(Number);add('relation:'+key,`${after.residents[ids[0]]?.name} ↔ ${after.residents[ids[1]]?.name} · 관계`,old,value);}
 for(const [key,value] of Object.entries(after.inventory))add('inventory:'+key,'보관 · '+(equipment[key]?.name||key),before.inventory[key]||0,value);
 if(before.season!==after.season)add('season','공동체 계절',before.season,after.season);
 if(before.goals!==after.goals)add('goals','완료한 개인 목표',before.goals,after.goals);
 if(before.ending!==after.ending)add('ending','여정의 결말',before.ending??'진행 중',after.ending??'진행 중');
 return rows;
}
export function outcomeValue(row,value){
 if(row.key.endsWith(':alive'))return value?'생존':'추모';
 if(row.key.endsWith(':retired'))return value?'은퇴':'현역';
 if(row.key.endsWith(':gear'))return equipment[value]?.name||value;
 if(row.key==='ending')return endingTypes[value]?.title||value;
 return amount(value);
}
export function outcomeLine(row){return `${row.label} ${outcomeValue(row,row.before)} → ${outcomeValue(row,row.after)}${row.delta!==null?` (${row.delta>0?'+':''}${amount(row.delta)})`:''}`;}
