// Presentation-only paths. They never enter the save or affect simulation decisions.
const traces=new WeakMap();
export function recordTravel(resident,time,points){traces.set(resident,{time,points});}
export function routePosition(points,fraction){
 const t=Math.max(0,Math.min(1,fraction));for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i];if(t<=b.t){const f=b.t===a.t?1:(t-a.t)/(b.t-a.t);return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f};}}return points.at(-1);
}
export function displayPosition(g,r,fraction=1){const trace=traces.get(r);return trace?.time===g.time?routePosition(trace.points,fraction):r.motion||{x:14,y:9};}
export class GameClock{
 constructor(){this.accumulator=0;this.last=null;}
 reset(now=null){this.accumulator=0;this.last=now;}
 advance(now,speed,enabled,step){
  const elapsed=this.last===null?0:Math.max(0,now-this.last);this.last=now;
  if(!enabled)return {steps:0,stalled:false};
  if(elapsed>2000)return {steps:0,stalled:true};
  this.accumulator+=elapsed/1000*speed;let steps=0;
  while(this.accumulator>=1&&steps<16){this.accumulator-=1;steps++;if(step()===false){this.accumulator=0;break;}}
  return {steps,stalled:false};
 }
}
