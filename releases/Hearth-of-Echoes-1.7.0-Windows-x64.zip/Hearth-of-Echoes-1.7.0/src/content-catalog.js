import {abilityDefs,traitDefs,masteryDefs} from './abilities.js';
import {researchDefs,specializationDefs,projectDefs} from './development-data.js';
import {backgrounds} from './founders.js';
import {voices,topics} from './social-content.js';
import {areas,discoveries} from './areas.js';
import {questDefs,factions,expeditionScenes,townScenes,sites} from './frontier-data.js';
import {eventTypes,worldConditions} from './content.js';
import {combatClasses,equipment,relics,enemies} from './combat.js';
import {facilities,goalTypes} from './settlement.js';
import {buildingDefs} from './town.js';
import {crisisTypes,preparationTypes} from './journey.js';
import {raidPatterns,defensePolicies,extraProjects} from './expansion-data.js';
const rows=o=>Object.entries(o).map(([id,d])=>({id,name:d.name||d.title||id,text:d.description||d.text||''}));
export function contentGroups(){return [
 ['연구',6,rows(researchDefs)],['주민 특성',12,rows(traitDefs)],['성격·기질',6,Object.entries(voices).map(([id,v])=>({id,name:id,text:v.join(' ')}))],['출신 배경',4,rows(backgrounds)],
 ['분야 능력',10,rows(abilityDefs)],['주민 전문 분야',10,rows(masteryDefs)],['정식 시설',6,rows(facilities)],['시설 전문화',12,Object.entries(specializationDefs).flatMap(([id,d])=>rows(d.options).map(r=>({...r,id:id+':'+r.id})))],['공동체 사업',6,rows(projectDefs)],['개인 목표',6,rows(goalTypes)],
 ['원정 지역',8,rows(areas)],['원정 직업',4,rows(combatClasses)],['적',9,rows(enemies)],['제작 장비',6,rows(Object.fromEntries(Object.entries(equipment).filter(([id])=>id!=='none')))],['유물',9,rows(relics)],
 ['의뢰',18,rows(questDefs)],['의뢰 목표 방식',6,[...new Set(Object.values(questDefs).map(q=>q.goal))].map(id=>({id,name:id,text:'해당 의뢰 목표의 실제 진행 경로'}))],['이웃 세력',3,rows(factions)],
 ['계절 위기',3,rows(crisisTypes)],['대비 물자',4,rows(preparationTypes)],['터전 조건',3,worldConditions.map((d,i)=>({id:String(i),name:d.name,text:d.description}))],
 ['원정 선택 사건',24,expeditionScenes.map(d=>({id:d.id,name:d.title,text:d.text}))],['마을 선택 사건',12,townScenes.map(d=>({id:d.id,name:d.title,text:d.text}))],['생활·성장 사건',12,Object.entries(eventTypes).map(([id,d])=>({id,name:d.title({name:'주민'},{name:'동료'}),text:d.text({name:'주민'},{name:'동료'})}))],
 ['원정 발견',7,rows(discoveries)],['대화 주제',15,rows(topics)],['대화 기본 발화',90,Object.entries(topics).flatMap(([id,d])=>d.lines.map((name,i)=>({id:id+':'+i,name,text:d.name})))],['대화 응답',60,Object.entries(topics).flatMap(([id,d])=>d.responses.map((name,i)=>({id:id+':'+i,name,text:d.name})))],
 ['자동 침입 유형',1,rows(raidPatterns)],['방어 방침',2,rows(defensePolicies)],['방비 사업',3,rows(Object.fromEntries(Object.entries(projectDefs).filter(([id,d])=>['palisade','watchtower','fieldaid'].includes(id)||d.raid||d.effects?.defense)))],
 ['건물 정의',10,rows(buildingDefs)],['탐사 장소명',32,Object.entries(sites).flatMap(([id,a])=>a.map((name,i)=>({id:id+':'+i,name,text:'장소명 변주 · 독립 자유 이동 지도 아님'})))],
 ];}
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function catalogContents(){return `<small>등록된 콘텐츠와 실제 규칙을 확인하는 도감</small><h2>콘텐츠 도감 · 1.7</h2><p>같은 이름의 수치 변형을 별도 종류로 세지 않습니다. 장소명은 독립 맵이 아니며, 문장은 조합에 쓰는 직접 쓴 기본 문장입니다. 각 게임 화면에서 실제 개방 조건과 적용 상태를 확인하세요.</p><div class="catalog-grid">${contentGroups().map(([name,old,entries])=>`<article data-catalog-group><h3>${name} <strong>${entries.length}</strong></h3><small>1.6의 ${old} → 목표 ${old*3}</small><details><summary>종류와 개성 보기</summary>${entries.map(d=>`<p data-content-entry><b>${esc(d.name)}</b><small>${esc(d.text)}</small></p>`).join('')}</details></article>`).join('')}</div><button data-action="close-modal">돌아가기</button>`;}
export function filterContent(root,query){const q=query.trim().toLocaleLowerCase();root.querySelectorAll('[data-content-entry]').forEach(e=>{e.hidden=Boolean(q&&!e.textContent.toLocaleLowerCase().includes(q));});root.querySelectorAll('article').forEach(e=>{e.hidden=e.hasAttribute('data-catalog-group')?[...e.querySelectorAll('[data-content-entry]')].every(p=>p.hidden):Boolean(q&&!e.textContent.toLocaleLowerCase().includes(q));});if(root.querySelector('[data-catalog-group]'))root.querySelectorAll('details').forEach(d=>{d.open=Boolean(q);});}
