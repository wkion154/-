import {extraBackgrounds} from './expansion-data.js';
import {bonus as effectBonus} from './expansion-effects.js';
import {researchDefs,projectDefs,specializationDefs,activeProjectReady} from './development-data.js';
import {fieldSkill,fieldFactor,abilitiesActive,practice} from './abilities.js';
import {journeyFrozen} from './journey.js';
const scholarFactor=r=>{const b=extraBackgrounds[r.background];return b?.role===r.workRole?b.factor:1;};
const enabled=g=>abilitiesActive(g)&&!journeyFrozen(g)&&!g.event;
const afford=(g,cost)=>Object.entries(cost).every(([k,n])=>g[k]>=n);
export function startResearch(g,key){const def=researchDefs[key],d=g.development;if(!enabled(g)||!def||!g.facilities.school||def.requires?.some(k=>!d.research.includes(k))||d.activeResearch||d.research.includes(key)||!afford(g,def.cost))return false;for(const [k,n] of Object.entries(def.cost))g[k]-=n;d.activeResearch={key,progress:0};return true;}
export function projectSponsor(g,key){const role=key==='roof'?'휴식':key==='boundary'?'건설':'배움';return g.residents.filter(r=>r.alive&&!g.expedition?.team.includes(r.id)&&r.age>=16).sort((a,b)=>(b.job===role)-(a.job===role)||a.id-b.id)[0];}
export function startProject(g,key){const def=projectDefs[key],d=g.development;if(!enabled(g)||!def||d.activeProject||d.projects.includes(key)||!d.research.includes(def.research)||def.facilities.some(k=>!g.facilities[k])||!afford(g,def.cost))return false;for(const [k,n] of Object.entries(def.cost))g[k]-=n;d.activeProject={key,progress:0,proposedBy:projectSponsor(g,key)?.id??0};return true;}
export function cancelDevelopment(g,type){if(!enabled(g)||!['activeResearch','activeProject'].includes(type))return false;const task=g.development[type];if(!task)return false;const def=(type==='activeResearch'?researchDefs:projectDefs)[task.key];for(const [k,n] of Object.entries(def.cost))g[k]+=Math.floor(n*(1-task.progress/def.work));g.development[type]=null;return true;}
export function advanceDevelopment(g,home,{log,memory}){
 if(!abilitiesActive(g))return;const d=g.development;
 if(g.time%60===0){const scholars=home.filter(r=>r.age>=6&&r.motion?.arrived&&['배움','가르침'].includes(r.workRole));if(scholars.length)g.records+=Math.min(.5,.1+scholars.reduce((n,r)=>n+fieldSkill(g,r,'education')*.04*scholarFactor(r),0));}
 if(d.activeResearch&&g.facilities.school){const task=d.activeResearch,def=researchDefs[task.key];for(const r of home.filter(r=>r.age>=6&&r.motion?.arrived&&['배움','가르침'].includes(r.workRole))){const bonus=(d.research.includes('archives')?1.2:1)*(d.projects.includes('archive')?1.15:1)*(d.specializations.school==='study'?1.25:1);task.progress+= (1+effectBonus(g,'research'))*(.25+fieldSkill(g,r,'education')*.08)*fieldFactor(g,r,'education')*bonus*scholarFactor(r);}
  if(task.progress>=def.work){d.research.push(task.key);d.activeResearch=null;g.records++;log(g,`연구 완료 · ${def.name}. ${def.text}.`,'story');}}
 if(activeProjectReady(g)){const task=d.activeProject,def=projectDefs[task.key];for(const r of home.filter(r=>r.age>=16&&r.workRole==='건설'&&r.motion?.arrived&&!r.townWorking&&!g.town.queue.length)){r.townWorking=true;task.progress+=(1+effectBonus(g,'build'))*(.6+fieldSkill(g,r,'construction')*.15)*fieldFactor(g,r,'construction');practice(g,r,'construction',1);}
  if(task.progress>=def.work){d.projects.push(task.key);d.activeProject=null;if(task.key==='boundary'){g.town.expanded=true;g.town.revision++;}if(task.key==='roof')for(const r of home)r.needs.fatigue=Math.max(0,r.needs.fatigue-10);g.records+=2;for(const r of home)memory?.(g,r,`공동체 사업 「${def.name}」를 함께 완성했다.`);log(g,`공동체 사업 완료 · ${def.name}. ${def.text}.`,'story');}}
}
export function validateDevelopment(g){const d=g.development,int=(v,a,b)=>Number.isInteger(v)&&v>=a&&v<=b;if(!d||!Array.isArray(d.research)||!Array.isArray(d.projects)||new Set(d.research).size!==d.research.length||new Set(d.projects).size!==d.projects.length||d.research.some(k=>!Object.hasOwn(researchDefs,k))||d.projects.some(k=>!Object.hasOwn(projectDefs,k))||!d.specializations||Object.keys(d.specializations).length!==Object.keys(specializationDefs).length)return false;
 for(const [kind,def] of Object.entries(specializationDefs)){const selected=d.specializations[kind];if(selected!==null&&(!Object.hasOwn(def.options,selected)||!d.research.includes(def.research)||g.facilities[kind]===0))return false;}
 for(const [type,defs,done] of [['activeResearch',researchDefs,d.research],['activeProject',projectDefs,d.projects]]){const task=d[type];if(task!==null&&(!task||!Object.hasOwn(defs,task.key)||done.includes(task.key)||!Number.isFinite(task.progress)||task.progress<0||task.progress>=defs[task.key].work))return false;}
 if(d.activeProject&&(!int(d.activeProject.proposedBy,0,g.residents.length-1)))return false;
 return typeof g.town.expanded==='boolean'&&(!g.town.expanded||d.projects.includes('boundary'));
}
