export const TERRAIN_VERSION=1,COLS=28,ROWS=16;
const kinds=['grass','water','rock','grove','ruin'];
export function seedFromText(text){const s=String(text).trim();if(/^\d{1,10}$/.test(s)&&Number(s)<=4294967295)return Number(s)>>>0;let h=2166136261;for(const c of s)h=Math.imul(h^c.codePointAt(0),16777619);return h>>>0;}
function protectedTile(x,y){return x>=8&&x<=22&&y>=6&&y<=13||x>=3&&x<=8&&y>=1&&y<=7||x>=17&&x<=22&&y>=1&&y<=6;}
export function generateTerrain(seed){let state=seed>>>0;const rng=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;},tiles=Array(COLS*ROWS).fill('grass');
 for(let patch=0;patch<17;patch++){const kind=patch<3?'water':patch<6?'rock':patch<13?'grove':'ruin',cx=1+Math.floor(rng()*26),cy=1+Math.floor(rng()*14),rx=1+Math.floor(rng()*(kind==='water'?3:2)),ry=1+Math.floor(rng()*2);
  for(let y=Math.max(0,cy-ry);y<=Math.min(15,cy+ry);y++)for(let x=Math.max(0,cx-rx);x<=Math.min(27,cx+rx);x++){if(((x-cx)/rx)**2+((y-cy)/ry)**2>1.3||protectedTile(x,y))continue;tiles[y*COLS+x]=kind;}}
 // Known nearby supplies remain walkable and provide a safe early economy.
 tiles[5*28+4]='grove';tiles[8*28+7]='ruin';
 const occupied=new Set();for(const [bx,by,w,h] of [[14,8,1,1],[12,6,3,1],[8,7,2,1],[9,11,3,2],[16,11,3,2]])for(let y=by;y<by+h;y++)for(let x=bx;x<bx+w;x++)occupied.add(x+','+y);
 const within=(x,y)=>x>=1&&x<=26&&y>=1&&y<=14&&!occupied.has(x+','+y),walk=(x,y)=>within(x,y)&&!['water','rock'].includes(tiles[y*28+x]);
 const flood=()=>{const seen=new Set(['14,9']),open=[[14,9]];for(let i=0;i<open.length;i++){const [x,y]=open[i];for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,b=y+dy,k=a+','+b;if(walk(a,b)&&!seen.has(k)){seen.add(k);open.push([a,b]);}}}return seen;};
 let seen=flood();for(let y=1;y<=14;y++)for(let x=1;x<=26;x++)if(walk(x,y)&&!seen.has(x+','+y)){
  const open=[[x,y]],previous=new Map([[x+','+y,null]]);let found=null;
  for(let i=0;i<open.length&&!found;i++){const [a,b]=open[i];if(seen.has(a+','+b)){found=a+','+b;break;}for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=a+dx,ny=b+dy,k=nx+','+ny;if(within(nx,ny)&&!previous.has(k)){previous.set(k,a+','+b);open.push([nx,ny]);}}}
  for(let k=found;k!==null;k=previous.get(k)){const [a,b]=k.split(',').map(Number);if(['water','rock'].includes(tiles[b*28+a]))tiles[b*28+a]='grass';}seen=flood();
 }
 return {version:TERRAIN_VERSION,seed:seed>>>0,cols:COLS,rows:ROWS,tiles};
}
export function validTerrain(t){return !!t&&t.version===1&&Number.isInteger(t.seed)&&t.seed>=0&&t.seed<=4294967295&&t.cols===COLS&&t.rows===ROWS&&Array.isArray(t.tiles)&&t.tiles.length===448&&t.tiles.every(k=>kinds.includes(k))&&t.tiles[9*28+14]==='grass';}
export function terrainAt(town,x,y){return town.terrain?.tiles[y*28+x]||'grass';}
export function passable(town,x,y){if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||x>=28||y<0||y>=16)return false;if(!town.terrain)return (town.expanded||x>=1&&x<27&&y>=1&&y<15)&&!(x>=23&&y>=2&&y<=6);return (town.expanded||x>=1&&x<27&&y>=1&&y<15)&&!['water','rock'].includes(terrainAt(town,x,y));}
export function terrainSummary(t){return Object.fromEntries(kinds.map(k=>[k,t.tiles.filter(v=>v===k).length]));}
