import {icon} from './ui-art.js';
import {crisisTypes,preparationTypes,endingTypes,crisisReadiness,canConfront,crisisWait,journeyFrozen} from './journey.js';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const costText=cost=>Object.entries(cost).map(([key,n])=>`${{food:'식량',wood:'자재',medicine:'의약품',records:'기록'}[key]} ${n}`).join(' · ');
export function crisisStrip(g){
  const c=g.crisis,def=crisisTypes[c.kind],left=Math.max(0,c.deadline-g.time),r=crisisReadiness(g);
  if(g.ending)return `<section class="campaign-strip resolved"><div><strong>${endingTypes[g.ending.kind].title}</strong><small>${c.sandbox?'이 터전에서 계속 살아갑니다. 위기는 재발하지 않습니다.':'이번 여정의 결말이 기록되었습니다.'}</small></div><button data-action="ending">여정의 결말</button></section>`;
  return `<section class="campaign-strip ${c.warned?'warning':''}"><div class="campaign-heading">${icon('shield')}<div><strong>${g.campaign?.mode==='settlement'?g.campaign.season+'번째 계절 · ':''}${def.name}</strong><small>도래까지 ${Math.floor(left/60)}분 ${left%60}초 · 게임 시간</small></div></div><div class="campaign-score"><strong>${r.score} / ${r.required}</strong><small>공동체 대응 점수</small><div class="bar"><i style="width:${Math.min(100,r.score/r.required*100)}%"></i></div></div><button data-action="crisis">위기 대비</button></section>`;
}
export function crisisContents(g){
  const c=g.crisis,def=crisisTypes[c.kind],r=crisisReadiness(g),ready=c.ready,enough=r.score>=r.required;
  return `<small>${ready?'최종 결정 · 자동으로 진행되지 않습니다':'남은 시간을 어떻게 쓸 것인가'}</small><h2>${def.name}</h2><p>${def.description}</p>${g.campaign?.mode==='settlement'?'<p class="description">이번 위기는 회차의 끝이 아닙니다. 대응 후 같은 주민·마을에서 회복하고 다음 계절을 준비합니다. 대피는 식량 최대 20·자재 최대 15를 포기하고 마을로 복귀합니다.</p>':''}
    <div class="readiness ${enough?'enough':''}"><strong>${r.score} / ${r.required}</strong><div><b>${enough?'방어 준비 완료':'대응 준비가 더 필요합니다'}</b><small>${enough?'방어를 선택하면 위기를 견딥니다.':'지금 방어하면 터전을 잃고 전원 체력 -15 · 스트레스 +20 · 부상 +1. 대피는 피해 없이 이어갑니다.'}</small></div></div>
    <div class="preparation-grid">${Object.entries(preparationTypes).filter(([id])=>def.weights[id]>0).map(([id,p])=>{
      const can=!journeyFrozen(g)&&!g.event&&!c.resolved&&c.preparations[id]<3&&Object.entries(p.cost).every(([k,n])=>g[k]>=n);
      return `<article><h3>${p.name} <small>${c.preparations[id]}/3</small></h3><p>1회당 대응 +${def.weights[id]}</p><button data-prepare="${id}" ${can?'':'disabled'}>투입 · ${costText(p.cost)}</button></article>`;
    }).join('')}</div><p class="description">투입한 물자는 대비용으로 소비되며 돌려받지 않습니다. 창고 잔액은 점수에 포함되지 않습니다. 시설 개선·전체 확장·성소 공략도 대응에 반영됩니다.</p>
    <div class="readiness-checks">${r.checks.map(c=>`<span>${c.label}<b>+${c.points}</b></span>`).join('')}</div>
    ${ready?`<button data-resolution="defend" class="${enough?'primary':''}">${enough?'준비한 방비로 공동체를 지킨다':'부족한 준비로 방어를 시도한다'}</button><button data-resolution="evacuate">${g.campaign?.mode==='settlement'?'긴급 대피 후 복귀 · 식량 최대 20·자재 최대 15 소모':'사람과 기록을 챙겨 대피한다 · 승리 보너스 없음'}</button><small>${g.campaign?.mode==='settlement'?'방어·대피 뒤에도 같은 주민과 마을에서 계속합니다. 부족한 방어의 피해는 위기 종류에 따라 다릅니다. 아래 선택의 실제 변화 미리 보기를 확인하세요.':'방어·대피를 정하면 이번 회차의 결말이 확정됩니다. 성공하면 이곳에 남아 자유롭게 생활할 수도 있습니다.'}</small>`:`<button data-action="confront" class="primary" ${canConfront(g)?'':'disabled'}>준비를 마치고 지금 위기를 맞는다</button><small>${crisisWait(g)?`조기 대응까지 ${Math.ceil(crisisWait(g)/60)}분 · 1배속 기준. 그동안 생활·회복·다음 세대를 준비하세요.`:'조기 대응 가능 시기입니다.'} 터전에서 10분이 지난 뒤 성소 완료 또는 물자 2회 이상 투입하면 대응할 수 있습니다. 원정과 진행 중 사건을 먼저 마쳐 주세요.</small><button data-action="close-modal">준비를 계속한다</button>`}`;
}
export function endingContents(g){
  const e=g.ending,def=endingTypes[e.kind],s=e.snapshot;
  return `<small>${g.cycle}번째 여정 · ${Math.floor(e.at/60)+1}일째 남긴 결말</small><h2>${def.title}</h2><p>${def.description}</p>${g.campaign?.mode==='settlement'?'<p class="description">이번 위기는 회차의 끝이 아닙니다. 대응 후 같은 주민·마을에서 회복하고 다음 계절을 준비합니다. 대피는 식량 최대 20·자재 최대 15를 포기하고 마을로 복귀합니다.</p>':''}
    <div class="ending-stats"><div><b>${s.population}</b><small>결말 당시 생존</small></div><div><b>${s.children}</b><small>자라는 아이</small></div><div><b>${s.expeditions}</b><small>원정</small></div><div><b>${s.goals}</b><small>이룬 개인 목표</small></div></div>
    <p class="description">대응 ${e.score}/${e.required} · 추모 ${s.memorials}명<br>${esc(def.gift)}${e.success&&e.kind!=='pilgrimage'?' · 생산 계승 +5%':''}<br>아래 기록은 결말이 확정된 시점의 삶입니다.</p>
    <div class="ending-stories">${s.stories.map(r=>`<button data-ending-person="${r.id}"><strong>${esc(r.name)} · ${r.age}세 · ${r.generation}세대${r.alive?'':' · 추모'}</strong><small>${esc(r.memory)}</small></button>`).join('')}</div>
    ${g.campaign?.mode==='classic'&&!g.gameOver?'<button data-action="enable-settlement">기존 마을로 장기 정착 이어가기</button>':''}<button data-action="legacy" class="primary">사람과 기록을 다음 피난처로</button>
    ${e.success&&!g.gameOver?(g.crisis.sandbox?'<button data-action="close-modal">지금의 삶으로 돌아가기</button>':'<button data-action="continue-home">이 터전에서 다음 세대와 계속 살기</button>'):''}`;
}
